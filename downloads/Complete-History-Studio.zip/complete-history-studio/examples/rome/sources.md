# Sources: The ENTIRE History of Rome (preview)

| Claim | Source | Note |
|---|---|---|
| Constantine XI died defending Constantinople, 29 May 1453 | Encyclopaedia Britannica, "Constantine XI Palaeologus"; Runciman, The Fall of Constantinople 1453 (1965) | Exact manner of death uncertain; contemporary accounts agree he died in the final assault |
| Rome existed for more than 2,000 years (753 BC to AD 1453) | Traditional founding date (Varro) to the fall of Constantinople | "Existed" counts the Eastern Roman (Byzantine) Empire as Roman, as its people did |
| Founding on 21 April 753 BC by Romulus, raised by a she-wolf | Livy, Ab Urbe Condita 1.4–1.7; date by Varro | LEGEND: traditional date and story |
| Early huts on the Palatine Hill above the Tiber marshes | Archaeological remains of Iron Age huts on the Palatine (8th century BC); Cornell, The Beginnings of Rome (1995) | EVIDENCE |
| Kings ruled for about 250 years; seven kings by tradition | Livy book 1; Cornell (1995) | Number and dates of kings are traditional |
| Tarquin the Proud expelled 509 BC; Romans swore never to have a king | Livy 2.1; Cornell (1995) | Traditional date |
| Two consuls elected yearly; Senate advises | Polybius, Histories 6; Lintott, The Constitution of the Roman Republic (1999) | |
| Dictator: one man with full power in an emergency, for up to six months | Lintott (1999); Livy 2.18 | Caesar's dictatorship for life (44 BC) broke the limit |

Images (all public domain, via Wikimedia Commons): Jean Le Tavernier, The Siege of Constantinople (after 1455) · portrait of Constantine XI, Mutinensis gr. 122 (15th century) · Peter Paul Rubens, Romulus and Remus (c. 1615) · the Capitoline Wolf, Musei Capitolini (twins added in the 15th century) · The Expulsion of Tarquinius Superbus, 15th-century illumination · the Capitoline Brutus, Musei Capitolini · Cesare Maccari, Cicero Denounces Catiline (1889) · Juan Antonio Ribera, Cincinnatus Leaves the Plough (1806) · Vincenzo Camuccini, The Death of Caesar (c. 1805).
Maps: Natural Earth (public domain); borders from historical-basemaps by A. Ourednik (GPL-3.0), approximate.
