# Upload kit: The ENTIRE History of Rome

## Titles
1. The ENTIRE History of Rome (753 BC to 1453)
2. The Entire History of Rome, Explained With Maps
3. How a Village Became Rome (And How It Fell Twice)

## Description
In 1453 the last Roman emperor died on the walls of Constantinople. Rome had lasted more than two thousand years. This is the whole story: the kings, the Republic, the Caesars, the fall of the West, and the thousand-year East.

Chapters
0:00 1453
0:27 Part One: The Kings
1:05 Part Two: The Republic

Art (all public domain, via Wikimedia Commons): Jean Le Tavernier, The Siege of Constantinople (after 1455); portrait of Constantine XI (15th-century manuscript); Peter Paul Rubens, Romulus and Remus (c. 1615); the Capitoline Wolf; The Expulsion of Tarquinius Superbus (15th-century illumination); the Capitoline Brutus; Cesare Maccari, Cicero Denounces Catiline (1889); Juan Antonio Ribera, Cincinnatus Leaves the Plough (1806); Vincenzo Camuccini, The Death of Caesar (c. 1805).
Maps: Natural Earth. Borders: historical-basemaps by A. Ourednik (GPL-3.0); borders are approximate.
Sources: Livy, Ab Urbe Condita; Polybius, Histories; T. J. Cornell, The Beginnings of Rome; A. Lintott, The Constitution of the Roman Republic; S. Runciman, The Fall of Constantinople 1453.

## Tags
history of rome, roman empire, entire history of rome, ancient rome, roman republic, fall of rome, byzantine empire, history documentary, history explained, history with maps

## Thumbnail ideas
1. The empire map in red over a dark sea, "2,000 YEARS" in Cinzel, a small "753 BC → 1453" line.
2. The Le Tavernier siege painting cropped on the walls, "THE LAST EMPEROR", a red year stamp "1453".
3. The Capitoline Wolf on black, "IT STARTED HERE", a LEGEND tag.
