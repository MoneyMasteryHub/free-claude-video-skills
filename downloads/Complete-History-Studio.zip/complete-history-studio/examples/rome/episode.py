"""The ENTIRE History of Rome: 90-second preview in the documentary look (v2)."""
import sys, os
ENGINE = os.environ.get('CHS_ENGINE', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'engine'))
sys.path.insert(0, ENGINE)
from doc import *

film = Film(__file__, vo='vo.wav', words='words.json', mood='epic')
T = film.cue
D = os.path.dirname(os.path.abspath(__file__)); has = lambda f: os.path.exists(os.path.join(D, 'media', f))

MED = ParchmentMap(-12, 24, 46, 56)                         # the Mediterranean
doc = Doc(film, chapter_map=(MED, 13, 42, .32), chapter_subs={'THE KINGS': '753 – 509 BC', 'THE REPUBLIC': '509 – 27 BC'})

# ---------------------------------------------------------------- cold open: 1453
doc.art(0, 'media/siege.jpg', frm=(.62, .42, 1.0), to=(.6, .34, 1.28))
doc.art(T('Roman Emperor') - .3, 'media/constantine.jpg', frm=(.5, .5, 1.0), to=(.5, .5, 1.05), portrait=.3)
WIDE = [(T('By then') - .4, 17, 40.5, .215), (T('This is'), 17, 40.5, .225)]
doc.map(T('By then') - .4, MED, WIDE, layers=[MED.place('Constantinopolis', 28.98, 41.01, T('By then'), T('It started')),
                                               MED.place('Roma', 12.48, 41.89, T('more than'), T('It started'))])
doc.scene(T('It started') - .2, palatine_huts)

# ---------------------------------------------------------------- the promise: a village becomes an empire, and falls twice
grow = MED.empire([(T('a village') - .3, -500, ['Rome']), (T('became') - .2, -300, ['Roman Republic']), (T('empire') - .1, -200, ['Rome']),
                   (T('roads') - .3, 100, ['Roman Empire']), (T('fell') - .2, 500, ['Eastern Roman Empire']), (T('twice') - .1, 1400, ['Byzantine Empire'])])
doc.map(T('This is') - .3, MED, [(T('This is') - .3, 17, 40.5, .225), (T('roads'), 15, 41, .26), (T('fell'), 20, 40, .25), (T('twice') + 2, 22, 40, .25)],
        layers=[grow, MED.place('Roma', 12.48, 41.89, T('a village') - .2, T('twice') + .2),
                MED.place('Constantinopolis', 28.98, 41.01, T('fell'), None),
                MED.label('Mare Nostrum', 18.5, 35.4, T('roads'), T('fell'), 46, '#4E6660', ITALIC, 10)])

# ---------------------------------------------------------------- part one: the kings
doc.art(film.chapter_at('THE KINGS') + 1.4, 'media/rubens.jpg', frm=(.42, .5, 1.0), to=(.5, .62, 1.22), depth=True)
doc.art(T('raised by a wolf') - .2, 'media/wolf.jpg', frm=(.5, .5, 1.0), to=(.45, .46, 1.14))
doc.scene(T('What archaeologists') - .2, palatine_huts)
doc.map(T('For about two') - .3, MED, [(T('For about two') - .3, 12.6, 42.2, 1.0), (T('The last one'), 12.5, 42.0, 1.15)],
        layers=[MED.empire([(T('For about two') - .3, -500, ['Rome'])]), MED.place('Roma', 12.48, 41.89, T('For about two'), None, size=40),
                MED.label('Latium', 13.1, 41.55, T('For about two') + .4, None, 44, SEPIA, CINZEL, 14),
                MED.label('Etruria', 11.6, 43.1, T('For about two') + .8, None, 40, SEPIA, CINZEL, 14),
                MED.label('Mare Tyrrhenum', 11.2, 40.4, T('For about two') + .8, None, 40, '#4E6660', ITALIC, 8)])
doc.art(T('The last one') + .1, 'media/expulsion.jpg', frm=(.5, .45, 1.0), to=(.45, .42, 1.15))
doc.art(T('swore never') - .2, 'media/brutus.jpg', frm=(.5, .2, 1.0), to=(.5, .17, 1.08))

# ---------------------------------------------------------------- part two: the republic
doc.art(film.chapter_at('THE REPUBLIC') + 1.4, 'media/cicero.jpg', frm=(.5, .5, 1.0), to=(.5, .48, 1.1), depth=True)
doc.scene(T('Two leaders') - .2, two_consuls)
doc.art(T('A senate') - .2, 'media/cicero.jpg', frm=(.78, .45, 1.7), to=(.74, .45, 1.9))
doc.art(T('one rule') - .3, 'media/cincinnatus.jpg', frm=(.55, .5, 1.0), to=(.64, .42, 1.22), depth=True)
doc.art(T('That rule') - .2, 'media/camuccini.jpg', frm=(.4, .5, 1.35), to=(.4, .52, 1.55), depth=True)


@doc.screen
def words(c, t):
    caption(c, t, .8, T('Roman Emperor') - .6, 'The fall of Constantinople', 'Jean Le Tavernier, after 1455', '29 May 1453')
    name_card(c, t, T('Roman Emperor') + .2, T('By then') - .7, 'Constantine XI', 'Palaiologos', 'The last Roman emperor', 'Manuscript portrait, 15th century', x=1000)
    year_title(c, t, T('By then'), T('It started') - .5, roll([(T('By then') + .2, 1453), (T('years') + .4, -753)]), 'Two thousand years earlier')
    timeline(c, t, T('existed'), T('It started') - .5, [(-753, -509, 'Kings'), (-509, -27, 'Republic'), (-27, 476, 'Empire'), (476, 1453, 'Byzantium')], -800, 1500,
             now=roll([(T('By then') + .2, 1453), (T('years') + .4, -753)]))
    title_card(c, t, T('This is') + .1, T('a village') - .2, 'The entire history of', 'ROME')
    year_title(c, t, T('a village'), T('fell') - .4, roll([(T('a village'), -500), (T('roads'), 117)]), 'From a village to an empire')
    for i, (w, ph) in enumerate((('Roads', 'roads'), ('Laws', 'laws'), ('Alphabet', 'alphabet'))):
        a = fade(t, T(ph), T('fell') - .4)
        if a > 0: text(c, w, 600 + i * 360, H - 110, 72, ITALIC, INK, 'center', 255 * a, wght=500)
    year_title(c, t, T('fell') - .1, T('twice') - .3, 476, 'The West falls')
    year_title(c, t, T('twice'), film.chapter_at('THE KINGS') + .1, 1453, 'The East falls')
    # part one
    note(c, t, T('The Romans said'), T("That's the legend") + 1.2, 'The legend')
    caption(c, t, T('founded') - .2, T('raised by a wolf') - .4, 'Romulus and Remus, as Rubens imagined them', 'Peter Paul Rubens, c. 1615', '21 April 753 BC · by tradition')
    caption(c, t, T('raised by a wolf') + .3, T('What archaeologists') - .5, 'The Capitoline Wolf', 'Bronze, Rome · the twins were added in the 1400s', 'The legend')
    note(c, t, T('What archaeologists'), T('For about two') - .6, 'What archaeologists found', dark=False)
    caption(c, t, T('Shepherd huts') - .1, T('For about two') - .6, 'Huts on the Palatine Hill', 'Postholes of 8th-century BC huts survive on the hill')
    timeline(c, t, T('For about two'), T('The last one') - .3, [(-753, -509, 'The seven kings'), (-509, -27, 'Republic')], -800, 0,
             now=roll([(T('For about two'), -753), (T('ruled') + .6, -509)]))
    caption(c, t, T('Tarquin') - .2, T('swore never') - .6, 'The Romans drive out their king', 'French manuscript illumination, 15th century', 'Tarquin the Proud · 509 BC')
    name_card(c, t, T('swore never'), film.chapter_at('THE REPUBLIC') - .1, 'Lucius Junius', 'Brutus', 'Led the revolt against the king', 'Bronze bust, 4th–3rd century BC · traditionally identified as Brutus')
    # part two
    caption(c, t, T('So they') - .1, T('Two leaders') - .6, 'Something new: a republic', 'Cesare Maccari, Cicero Denounces Catiline, 1889', '509 BC')
    statement(c, t, T('elected every year') - .1, T('A senate') - .5, 'TWO CONSULS · ONE YEAR', y=H - 120, size=84, dark=False)
    caption(c, t, T('A senate') + .2, T('one rule') - .6, 'The Senate: the old families of Rome', 'Cesare Maccari, 1889 · an imagined scene')
    caption(c, t, T('In an') - .2, T('six months') - .3, 'Cincinnatus is called from his plough to save Rome', 'Juan Antonio Ribera, 1806', '458 BC · by tradition')
    statement(c, t, T('six months') - .1, T('That rule') - .4, 'ONE MAN · SIX MONTHS', sub='then he must give the power back')
    caption(c, t, T('end the') - .3, None, 'The Ides of March', 'Vincenzo Camuccini, The Death of Caesar, c. 1805', '44 BC')


film.music = dict(calm=[(0, T('This is'))], pulse=[(T('a village'), T('fell') - .3)], hits=[T('twice') + .1, T('end the') + .2],
                  drops=[(T('In an') - .2, T('six months') + 1.0)])
doc.render(6)
film.main()
