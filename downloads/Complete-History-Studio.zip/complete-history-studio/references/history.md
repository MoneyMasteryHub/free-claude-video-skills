# The history look (engine/history.py)

Read `board.md` first (worlds, items, camera, world changes). This file adds what "The ENTIRE History of X" films need.
Start every film from `examples/rome/episode.py`.

```python
from board import *
from history import *          # chapter cards become Cinzel + gold, animated scenes get the warm antique grade
film = Film(__file__, vo='vo.wav', words='words.json', mood='epic')
```

## The three worlds of a history film
1. **The table** (`World(film, 'parchment')`): paintings, statues, manuscripts and coins in white frames, animated scenes, papers. The cold open usually starts dived into one painting full screen.
2. **The atlas** (`Atlas(lon0, lat0, lon1, lat1)` + `World(film, atlas_map.surface)`): a real map you fly over. The empire's borders grow and shrink with the story. Return to it at every era change: it is the spine of the film.
3. **Back to a table** for each era's people and evidence.
Move between them seamlessly: a `portal(world)` scene item on the table ("a framed map") that the camera dives into, and on the map a small `portal(next_world)` item sitting exactly on a city, which the camera dives into during a chapter card.

## Maps
```python
atlas_map = Atlas(-12, 24, 46, 56)            # lon/lat box: the Mediterranean (Europe: -12, 34, 45, 62; Middle East: 25, 12, 65, 42)
atlas = World(film, atlas_map.surface)
atlas.under(atlas_map.empire([(t1, -500, ['Rome']), (t2, -100, ['Roman Republic']), (t3, 100, ['Roman Empire'])], color='#A3241F'))
RX, RY = atlas_map.xy(12.48, 41.89)           # world position of a place, for camera keys and items
@atlas.layer
def marks(c, t):
    atlas_map.city(c, t, T('a village'), 'Rome', 12.48, 41.89, size=120)      # size in world px: ~120 at the wide view, ~30 zoomed in
    atlas_map.route(c, t, T('marched'), [(12.5, 41.9), (15, 38), (10.3, 36.9)], dur=2)   # armies, roads, trade
    atlas_map.region_label(c, t, T('the sea'), 'MARE NOSTRUM', 18, 35.5, size=150)
```
- Borders come from historical-basemaps snapshots: 123000, 10000, 8000, 5000, 4000, 3000, 2000, 1500, 1000, 700, 500, 400, 323, 300, 200, 100, 1 BC and AD 100, 200 ... 1000, 1100, 1200, 1279, 1300, 1400, 1492, 1500, 1530, 1600, 1650, 1700, 1715, 1783, 1800, 1815, 1878, 1880, 1900, 1914, 1920, 1930, 1938, 1945, 1960, 1994, 2000, 2010. A year picks the snapshot at or before it. Files download once.
- Names differ between snapshots ('Rome', 'Roman Republic', 'Roman Empire', 'Western Roman Empire', 'Eastern Roman Empire', 'Byzantine Empire'). List them with `python3 scripts/borders.py 100 rom` before writing keys.
- Borders are approximate. Credit `BORDERS_CREDIT` on the map item and in the description (GPL-3.0 requires the credit).
- The wide view of a 9000 px atlas is zoom ~0.21; a country fills the screen around 0.8 to 1.5; a city around 4 to 8.

## Type
- `year_tag(c, t, t0, -753, sub='THE FOUNDING')` big year top right; pass `year_counter([(t1, 1453), (t2, -753)])` to roll the years.
- `timeline(c, t, t0, -800, 1500, marks=[(-753, 'Rome'), ...], eras=[(-753, -509, 'THE KINGS', '#7A5A3A')], now=...)` bottom bar.
- `label(c, t, t0, 'LEGEND', x, y)` purple · `'EVIDENCE'` green · `'HISTORIANS DISAGREE'` ochre · `'RECONSTRUCTION'` blue · any other text red (e.g. 'PAINTED IN 1889'). Use LEGEND/EVIDENCE every time the script says "the Romans said" / "archaeologists found".
- `quote(c, t, t0, 'I found Rome a city of bricks...', 'Augustus, in Suetonius, Life of Augustus 28')` for real quotes only.
- From board.py: `place_tag` (place + date, lower left), `name_tag` (named people), `big` (with `font=CINZEL` for statements, `MONO` for small lines).
- Fonts: `CINZEL` (Roman capitals: titles, chapters, years), `MONO`, `PLAYFAIR` (quotes). Colours: `GOLD`, `PURPLE`, `BONE`, `BLOOD`, `PAPER`.

## Ancient sets and puppets
Sets (draw inside a `scene` on the 1920x1080 frame): `hills_village(c, t)` first settlement, `temple_row(c, ruin=0..1)` temples and forums (ruins later), `senate_hall(c)` councils and assemblies, `city_walls(c, t, fire=0..1)` sieges and sacks. Light them with `light(c, 'dusk', pools)`.
Puppets: `CITIZEN`, `SENATOR`, `EMPEROR`, `LEGIONARY`, `KING`, `MATRON`, `BARBARIAN` (dicts for `draw_char3`; change colours with `dict(SENATOR, toga='#5E2A78')`). Costume keys: `toga`, `toga_stripe`, `armour`, hats `laurel`, `galea` (+`crest`), `crown`, `veil`. Other eras: change cloth colours and hats; keep faces simple (`eyes='half'`, `mouth='flat'`).

## Pacing
- The voice is slower after the first chapter (see script.md). Let the camera match: glides of 1.3 to 2 s, holds of 3 to 5 s on paintings with a slow push (`drift`).
- Land each big map move inside a chapter pause or a paragraph pause.
- Something new appears with every sentence: a border change, a city, a year, a label, a painting, a puppet.
- Centuries passing: `year_counter` + the empire shrinking or growing. One day mattering: dive into a painting or scene and hold.

## Sound (mood 'epic')
Generated, no claims: low strings and a wordless choir over a slow minor progression, a sub drone. `film.music = dict(calm=[...], drums=[...], pulse=[...], horns=[...], hits=[...], drops=[...])`: `calm` softens the cold open, `drums` for marches, battles and expansion, `pulse` for tension, `horns` swell on big moments (chapter cards get one automatically), `hits` for the 2 or 3 biggest reveals, `drops` let the music fall away for a key line.
A real track: drop one MP3 into the project's `music/` folder (from a source the user can use on YouTube, see legal.md). It replaces the score, loops with a crossfade and is ducked under the voice the same way.
