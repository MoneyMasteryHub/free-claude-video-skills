# Finding topics people want

1. **Look at what is working now.** Search YouTube (web search, or the user's browser if connected) for "entire history of", "complete history of", "history of X explained", "rise and fall of", "every year of", "timeline" and note videos from the last 12 months that beat their channel's size (a channel with 20K subscribers getting 500K+ views). Note the subject, the length and the title shape.
2. **Strong subjects** have a clear start and end, a famous fall, and lots of free images: empires (Rome, Byzantium, the Mongols, the Ottomans, the Aztecs, Persia, the British Empire), civilisations (Egypt, Mesopotamia, the Maya, the Vikings), countries (Japan, Korea, Ethiopia, Mexico), cities (Constantinople, London, Jerusalem), dynasties (the Tudors, the Romanovs, the Habsburgs), institutions (the Knights Templar, the East India Company, the papacy).
3. **Angles that lift a familiar subject:** "in 20 minutes", "every year", "explained with maps", "the parts school skipped", "why it fell", "the other half" (Byzantium as the Roman Empire that didn't fall).
4. **For every idea give:** the title (bold, true), the one-line hook (the cold-open moment), the demand proof you actually saw (title, channel size, views, age), how many free images and maps exist for it, how sensitive it is (low / medium / skip), and the suggested length.
5. **Prefer** subjects with a dramatic opening moment, many turning points with dates, and named people. **Be careful** with recent and still-contested history (living memory, ongoing conflicts): neutral, sourced, or skip.

Never make up view counts, trends or search volumes. If you couldn't check, say "unverified".
