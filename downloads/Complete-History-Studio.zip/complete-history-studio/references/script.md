# Script formula: "The ENTIRE History of X"

One subject, start to finish (a civilisation, an empire, a country, a city, a dynasty, a religion, a company). The viewer clicked for the whole story, so they must always feel how much ground is covered and where they are on the road. The format works on YouTube because the title promises completeness and the timeline gives a reason to keep watching: "what happens next" is literally the next century.

## Shape of a full film (15 to 40 minutes, ~145 words a minute)
1. **Cold open: the end, or the strangest single fact (20 to 45 s).** Start inside one vivid moment, usually the last one ("In 1453, the last Roman emperor died on the walls of Constantinople, sword in hand."). Then the scale of the whole story in one line ("By then, Rome had existed for more than two thousand years.") and the humble start ("It started as a few huts on a hill.").
2. **The promise (one short paragraph).** Name the video ("This is the entire history of Rome.") and the arc in one sentence: how it rose, what it left us, how it fell. A twist word at the end ("And how it fell. Twice.").
3. **Eras as chapters.** One chapter per era, in time order: `[CHAPTER: PART ONE | THE KINGS]`. Each era: the problem it starts with, two or three turning points with dates, the person who mattered most, how it ends, and the hook into the next era (the last line of every chapter points forward: "That rule would end the Republic.").
4. **Legend vs evidence.** When the sources are myths (founding stories, ancient numbers), say so in the line and show it on screen: "The Romans said..." + the LEGEND tag, then "What archaeologists actually found..." + the EVIDENCE tag. This is the single biggest trust builder in history content.
5. **People, not just dates.** Each era gets one or two named people with one human detail (what they were called, what they feared, what they said in a real source).
6. **Scale and pace changes.** Centuries can pass in one sentence ("For the next two hundred years, almost nothing changed.") and one day can take a minute (an assassination, a battle, a sack). Mix them: zoom out across centuries, then zoom in on one day.
7. **Callbacks.** Plant something early (a rule, a road, a word) and pay it off later without announcing it. In the Rome script: the six-month dictator rule planted in the Republic chapter pays off with Caesar.
8. **What survived.** Near the end: what is still with us (laws, words, roads, calendar), concretely and briefly.
9. **Ending: back to the cold open.** Return to the opening moment, now understood, and close in a few short fragments.

## Timing map for 20 minutes (Rome example)
0:00 cold open (1453) · 0:35 promise · 0:50 PART ONE the kings · 2:30 PART TWO the Republic · 5:00 PART THREE the wars with Carthage · 7:30 PART FOUR the civil wars and Caesar · 10:00 PART FIVE the emperors · 13:00 PART SIX the crisis · 15:00 PART SEVEN the fall in the West · 17:00 PART EIGHT the thousand-year East · 19:00 what survived · 19:40 back to 1453.
A preview (60 to 90 s) is the cold open, the promise and the first one or two chapters.

## Chapter cards (a pause in the voice)
Put each marker on its own line between paragraphs:

    [CHAPTER: PART ONE | THE KINGS]

The free voice makes it a 2.2-second silence and saves its time in `chapters.json`; the film shows the card in that silence over a horn swell. Nothing is said over a chapter card.
- Titles: the era's name, 1 to 3 words ("THE KINGS", "THE REPUBLIC", "CAESAR", "THE FALL").
- One every 2 to 3 minutes. A 20-minute film has 7 or 8.
- Own voice (ElevenLabs): add a 2-second pause at each marker (`<break time="2s" />`).

## Pacing (built into the voice)
The cold open (everything before the first chapter marker) is read at normal pace. From the first chapter on, the narrator slows slightly and breathes longer between sentences and paragraphs: a calm documentary, never rushed, never dragging. So write the cold open tight and punchy, and the chapters with a little more room. Keep paragraphs to 2 to 4 sentences: each paragraph break becomes a longer pause, which is where the camera makes its biggest moves.

## Lines
- Dates the way they are spoken: "in 509 BC", "April 21st, 753 BC", "in the year 476". Use BC/AD consistently (or BCE/CE if the user prefers; never mix).
- Numbers with a scale: "about a million people, more than any city on Earth until London in the 1800s".
- Say the source in the line for anything surprising ("according to Livy, writing five hundred years later").
- Uncertainty out loud: "probably", "historians still argue about", "the Romans said". Never present a legend, a speech written by a later historian, or an ancient army size as fact.
- Quotes only from real sources with the work named (Suetonius, Life of Augustus 28). Put them in the notes for the on-screen quote card.
- Short spoken sentences, fragments are fine. One light, dry joke every 2 or 3 minutes ("He was called Tarquin the Proud. It wasn't a compliment.").
- No em dashes, no "not just X but Y", no "let's dive in", no "little did they know". Run the humanizer.
- Call to action: one line after the first chapter's payoff ("If you like long history, like the video so YouTube shows you more of it"), never at the very end.

## Visual notes in the script
After writing, add a visual plan per paragraph (not read aloud) in a separate file `shots.txt`: which map and year, which painting or photo, which scene with which puppets, which labels (LEGEND / EVIDENCE), which quote card. The episode file follows it.
