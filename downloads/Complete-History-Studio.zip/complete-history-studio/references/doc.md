# The documentary look (engine/doc.py)

This is the house style of the skill. It is light, it fills the screen, and it uses real art and real maps. There are no frames on a table, no cartoon puppets and no stamps. Start every film from `examples/rome/episode.py`.

```python
from doc import *
film = Film(__file__, vo='vo.wav', words='words.json', mood='epic'); T = film.cue
MED = ParchmentMap(-12, 24, 46, 56)                     # lon/lat box of the region
doc = Doc(film, chapter_map=(MED, 13, 42, .32), chapter_subs={'THE KINGS': '753 – 509 BC'})
doc.art(0, 'media/siege.jpg', frm=(.62, .42, 1.0), to=(.6, .34, 1.28))      # focus x, focus y (0..1), zoom (1 = fills the screen)
doc.map(T('By then'), MED, cam=[(T('By then'), 17, 40.5, .215), ...], layers=[MED.empire(...), MED.place(...)])
doc.scene(T('huts'), palatine_huts)
@doc.screen
def words(c, t): caption(c, t, T('Romulus'), T('legend') + 1, 'Romulus and Remus, as Rubens imagined them', 'Peter Paul Rubens, c. 1615', 'The legend')
doc.render(6); film.main()
```

Shots follow each other in time order. Each one lasts until the next starts, with a soft 0.8-second crossfade between them. Chapter cards draw themselves in the narrator's chapter pauses: light paper over a faint map, with the era's dates from `chapter_subs`.

## Shots
- **`doc.art(t, src, frm, to, depth=False, portrait=None)`**: a painting, statue, manuscript or photo, with a slow push from `frm` to `to`.
  - **depth.** `depth=True` cuts the figures from the background (rembg, free and offline) and pushes them a little faster, which gives a layered, parallax effect. Use it on paintings with clear figures. Look at the stills: if a cut-out looks wrong, turn it off for that painting.
  - **Tall pictures.** `portrait=.3` shows a tall picture (a portrait, a bust or a full statue) complete, at that x position, over a blurred copy of itself. Put the `name_card` on the other side.
- **`doc.map(t, MAP, cam, layers)`**: the parchment atlas. `cam` is a list of `(t, lon, lat, zoom)` keys, and zoom moves smoothly between them.
  - Wide Mediterranean: about 0.22.
  - Italy: about 0.9 to 1.2.
  - Layers:
    - `MAP.empire([(t, year, ['Rome']), ...])`: borders that spread like ink, one snapshot fading into the next.
    - `MAP.place('Roma', lon, lat, t0, until)`: a city.
    - `MAP.label('Latium', lon, lat, t0, until, size, colour, font, tracking)`: a region or sea name (Latin names suit the ancient world).
    - `MAP.route([(lon, lat), ...], t0, dur)`: a campaign arrow.
    - `MAP.army('HANNIBAL', lon, lat, t0, until, colour, move=(t1, lon1, lat1, dur))`: army blocks.
- **`doc.scene(t, fn)`**: an ink-and-wash drawing, `fn(c, t, u)` on the 1920x1080 frame. Built in:
  - `palatine_huts`: a first settlement on a hill.
  - `two_consuls`: the fasces drawn in by hand.
  - New ones are written with `sketch` (inked lines), `wash` (watercolour areas) and `hatch` (shading).

  Draw places and objects only, never people.

## Type (all screen space; t0/t1 are when it appears and goes)
- `caption(c, t, t0, t1, line, sub, kind)`: lower left. `kind` is small gold capitals (a date, "The legend"), `line` is the italic title, and `sub` is the source of the image. Every painting gets a caption with its artist and date.
- `name_card(c, t, t0, t1, first, last, role, note, x=1240)`: a person's name beside their portrait or bust.
- `year_title(c, t, t0, t1, year_or_fn, sub)`: a big year, top left. Pass `roll([(t1, 1453), (t2, -753)])` for a counter.
- `timeline(c, t, t0, t1, eras, start, end, now)`: an engraved timeline on a paper strip at the bottom.
- `statement(c, t, t0, t1, 'ONE MAN · SIX MONTHS', sub=...)`: the key idea of a beat, centred.
- `note(c, t, t0, t1, 'The legend')`: a small label top left. Use "The legend" when the script says "the Romans said", and "What archaeologists found" for evidence.
- `title_card(c, t, t0, t1, 'The entire history of', 'ROME')`: right after the cold open.

## Where pictures come from (all free)
1. **People and big moments: real art.** Search with `scripts/photos.py`. Old paintings, statues, busts, coins and manuscripts are public domain. Tell a big moment like a film: the wide painting, then 2 or 3 details of the same painting (the weapon, the face, the crowd), then the aftermath. Each detail is a separate `doc.art` with a different `frm`/`to`.
2. **Places and things with no art: ink-and-wash drawings** (`doc.scene`).
3. **Wars and expansion: the map.** Empire keys, armies and routes.
4. **Never** film stills, game art, AI images, or modern illustrations from books or websites. Never draw people in code; they look crude.

Be honest about a painting's date: "as Rubens imagined them", "an imagined scene, 1889".

## Pacing
- Change the picture with almost every sentence, and let key images hold for 3 to 5 seconds while the push continues.
- The cold open moves fast: a painting, a portrait, the map, the first image of the story. After the first chapter card, shots get longer, matching the slower narration.
- Map moves land on paragraph breaks or chapter pauses.

## Sound
Mood `'epic'` (see history.md): strings, choir pad, horn swells on chapter cards, `pulse` for growth and tension, `hits` on the 2 or 3 biggest lines, `drops` for a key rule or quote. A free track dropped into `music/` replaces the score.
