# Writing the episode file (engine/board.py)

Start from `examples/rome/episode.py`. A film is a **Reel of Worlds**. Each World is a big flat place (about 9000 x 6000) with a surface and items on it; the camera travels through it.

```python
import sys, os; sys.path.insert(0, '/path/to/heist-dark-history-studio/engine')
from board import *
D = os.path.dirname(os.path.abspath(__file__)); P = lambda *a: os.path.join(D, *a)
film = Film(__file__, vo='vo.wav', words='words.json', mood='noir')
T, E = film.cue, film.end                  # T('phrase') = when it is said; T('x', 2) = 2nd time

desk = World(film, 'desk'); plan = World(film, 'blueprint'); case = World(film, 'board')

desk.item(0, 'clip', 'truck', 1000, 900, 1280, 720, src=P('clips/truck.mp4'), speed=.75, credit='FBI film · National Archives')
desk.item(0, 'paper', 'paper', 2900, 1100, 1500, 1900, draw=paper_draw)            # draw(c, t, w, h), centred on 0,0
desk.item(0, 'scene', 'street', 2900, 1050, 1360, 765, draw=street_scene, frame=False)   # draw(c, t) on a 1920x1080 frame, noir grade
desk.item(T('one cap'), 'photo', 'cap', 4650, 1450, 1000, 562, src=P('media/cap.jpg'), credit='Photo: FBI (public domain)')
desk.item(T('They had keys'), 'scene', 'plan_mini', 2920, 3520, 192, 108, draw=portal(plan), noir=False, vig=False, frame=False, shadow=False)

@desk.layer          # world-space drawing over the items (strings, big text on the board)
def pins(c, t): ...
@plan.under          # world-space drawing under the items (the floor plan itself)
def floorplan(c, t): ...
@desk.screen         # screen-space overlays that stay put (place/time, numbers, name tags, chapter cards)
def overlays(c, t):
    place_tag(c, t, .5, 'BOSTON, MASSACHUSETTS', 'JANUARY 17, 1950  ·  7:30 PM', until=T('seven men'))

desk.dive(0, 'truck')                                   # fill the screen with an item
desk.dive(T('seven men') + .1, 'street', move=1.3)      # glide into the next one as the words are said
desk.cam(T('Behind them') + .9, 4650, 1050, .56, move=1.6)   # x, y, zoom
desk.frame_box(T('one cap') + 1, 'cap', pad=1.2)         # frame an item with a little desk around it
desk.dive(T('For months') + .45, 'plan_mini', move=1.4)  # through the map pin...
SW1 = T('For months') + .5
plan.cam(0, 1500, 1000, 1.0); plan.cam(SW1, 1500, 1000, 1.0)   # ...into the blueprint world (same view = no seam)

film.music = dict(pulse=[(a, b)], ticks=[(a, b)], hits=[t1, t2], drops=[(a, b)])
Reel(film, [(0, desk), (SW1, plan), (SW2, case), (SW3, desk)]).render_chunks(8)
film.main()
```

## Items
- `clip`: archive footage. `src`, `t_play` (when it starts playing), `speed` (.5 to .75 stretches short clips; the last frame holds), `fx`/`fy` crop centre, `tone` warm/cold. White frame + credit line.
- `photo`: `src`, `kb` slow zoom, credit. White frame.
- `scene`: `draw(c, t)` on the 1920x1080 frame. Noir grade and vignette by default (`noir=False`, `vig=False` to switch off). White frame by default.
- `paper`: `draw(c, t, w, h)` on cream paper (`bg=`), no frame. Newspapers, maps, ledgers, calendars, charts, suspect cards, timelines.
- Common options: `rot`, `pop` (scale-in when it appears; `pop=False` if the camera arrives on it), `pin=True`, `title=`, `credit=`, `until=`.

## Worlds and world changes
Surfaces: `'desk'` (dark wood), `'blueprint'` (blue grid), `'board'` (cork board with old papers), or your own `fn(c, view)`.
A world change must be invisible: at the switch time the camera of the old world is dived (zoom exactly to fill, `over=1.0`) into an item that shows exactly what the new world shows at that moment:
- the same `clip` (same `src`, `t_play`, `speed`) or the same `scene` function in both worlds, with the new world starting `dive`d into it; or
- a `portal(world)` scene item, which draws the other world live through its own camera (used for zooming through a map pin into the blueprint).
Screen overlays belong to a world: let them fade out before a switch.

## Chapter cards
They come from the script (`[CHAPTER: PART ONE | THE PLAN]` lines become 2.2 s pauses in the voice) and the Reel draws them by itself in those pauses. Get the time with `CH1 = film.chapter_at('THE PLAN')` and use the pause: finish a dive or a world change at `CH1 + .3`, or start a slow pull-back under the card. Don't call `chapter()` yourself.

## Type helpers (board.py)
`place_tag(c, t, t0, line1, line2, until)` typed place/time lower left · `chapter(c, t, t0, 'PART ONE', 'THE PLAN')` · `big(c, t, t0, '$2,775,395', x, y, size, colour, until=)` Oswald numbers · `name_tag(c, t, t0, NAME, role, until=)` · `type_on(...)` typewriter · `stamp2(c, t, t0, 'LIFE', x, y)` stencil stamp (verdicts only) · `strike(...)` cross a line out · `clock_line(c, t, a, b, 10, 30)` heist clock bar · `string(...)` red string with pins · `txt(...)` plain text.
Fonts: `BEBAS` chapter titles · `MONO` place/time, labels, credits · `OSWALD` numbers, name tags · `ELITE` typewritten · `COURIER` official headings · `STENCIL` stamps · `PLAYFAIR` quotes, mastheads. Colours: `BONE`, `AMBER`, `BLOOD`, `ASH`.

## Noir puppets
`draw_char3(c, x, y, s, spec, ...)` (see shots.md). Criminals: `NOIR_GANG`, `NOIR_GANG2` (caps, rubber masks, dark coats, no faces). Named people: muted skin and suits, `eyes='half'`, `mouth='flat'`, a `name_tag`. Light every scene with `light(c, 'dark', pools)`: one or two pools, the rest in shadow.

## The four looks (use all four in every film, and in every preview)
1. **Real footage full screen**: dive into a `clip` for the cold open and the crime itself.
2. **Footage and photos in white frames** on the desk or board.
3. **Text on screen**: place/time, numbers, ruled-out lines struck through, stamps, chapter cards.
4. **Animated noir scenes**: how the trick worked, the people involved, the confession, the verdict.

## Pacing: one connected camera (house style)
- Inside a world the camera never jumps: it glides from item to item and dives into footage and scenes. Something new appears with every sentence, so the glide always lands on news.
- World changes are seamless (see above).
- Arrive as the words are spoken: key time = the phrase + 0.1 to 0.6 s, glide 1.0 to 1.6 s. Long glides get a small pull-back (`dip`). Don't let two moves overlap: the next key's start (its time minus `move`) comes after the previous arrival.
- Let the strongest images breathe: the key evidence, the headline, the big reveal, the verdict, the last image. Hold 2 to 4 s with a slow push (`drift`).
- End with a pull-back over the whole desk, then a push into the one object the story is about.
- Hard cuts (`cut`, `cut_to`, `cut_dive`) exist but are not the house style; use them only if the user asks for a cut-heavy edit.

## Sound (mood 'noir' in the crime skill; history films use mood 'epic', see history.md)
Generated, so no claims. `film.music`: `pulse` ranges (low string ostinato, use for the plan and the deadline), `ticks` (clock, use for the crime itself), `hits` (riser into a deep impact on the 2 or 3 biggest reveals), `drops` (music falls away: "Nothing.", the confession). Effects are quiet and ducked under the voice: soft air on glides, typewriter on typed lines, projector rattle when footage appears, a soft thump for stamps. The mix prints the levels; the voice must lead.
