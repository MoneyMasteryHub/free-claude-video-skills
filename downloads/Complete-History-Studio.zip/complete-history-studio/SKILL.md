---
name: complete-history-studio
description: Makes faceless "The ENTIRE History of X" documentary videos (an empire, civilisation, country, city or dynasty, start to finish) in a light, premium history-documentary look: finds subjects people are searching for, researches and fact-checks the timeline, writes the script in era chapters with legend-vs-evidence honesty, voices it with the channel's house narrator (free, documentary pacing), tells it with public-domain paintings, statues and manuscripts full screen (slow push, layered depth), a parchment atlas where real borders spread and shrink through the centuries, ink-and-wash drawings, elegant captions and chapter cards, adds an epic generated score, and renders the MP4. Everything is free. Use for "entire history of", "complete history of", "history of Rome/Egypt/the Mongols...", "rise and fall of", "history documentary", "history explained with maps", or when someone asks for this skill by name.
---

# Complete History Studio

Turns a whole history into a finished documentary (2 to 40 minutes) that looks like a streaming-service history film:
- **Real art full screen**: paintings, statues, busts, manuscripts and coins (public domain, credited), each with a slow push; paintings with clear figures get a layered depth effect. Big moments are told like film shots: the wide painting, then its details, then the aftermath.
- **A parchment atlas**: Natural Earth coastlines, old-atlas mountain symbols, Latin names, and the state's real borders spreading and shrinking through time (historical-basemaps, about 50 snapshots from prehistory to 2010), cities, campaign arrows, army blocks.
- **Ink-and-wash drawings** for places and things with no surviving art (the first huts, the fasces).
- **Documentary type**: Cinzel and Cormorant Garamond; italic captions with the artist and date of every image, name cards beside portraits, big year titles, an engraved timeline, light paper chapter cards over a faint map.
- **Sound**: the house narrator, slowing to a calm documentary pace after the cold open; an epic generated score (strings, choir, war drums, horn swells) that never gets a copyright claim, or the user's own free track.

The reference film is `examples/rome/` (The ENTIRE History of Rome, 90-second preview). Copy its `episode.py` for every new film. No paid tools, no AI images: everything is free for the user and their viewers.

Folder map:
- `engine/doc.py` the documentary look: art shots, the parchment atlas, ink-and-wash drawings, captions, chapter cards (start here) · `engine/history.py` borders data and the older board look · `engine/board.py` worlds and camera (older look) · `engine/core.py` puppets · `engine/world.py` more sets and props · `engine/film.py` cues, render · `engine/audio.py` score (mood `epic`) and effects.
- `scripts/voice.py` house narrator with documentary pacing · `scripts/timestamps.py` word timings · `scripts/photos.py` free paintings and photos with credits · `scripts/borders.py` state names per period · `scripts/footage.py` archive film (20th-century topics).
- `references/legal.md` (read before research) · `references/script.md` (read before writing) · `references/doc.md` (read before the episode file) · `references/shots.md` (puppets, props) · `references/research.md` (topic finding) · `references/music.md` (free music and sound-effect sources).

## Credits rule (always)
Before writing or rendering anything long, **ask how many minutes the video should be.** Always render a **60 to 90 second preview first** (cold open + the first one or two chapters, showing the map with moving borders, real art with captions, an ink-and-wash drawing and a chapter card), and render the full film only after the user approves it.

## 0. Setup (do it yourself; the user never types commands)
Tell the user in one line: "Setting the studio up now. The first time takes a few minutes." Then run `bash setup.sh` (macOS/Linux) or `powershell -ExecutionPolicy Bypass -File setup.ps1` (Windows) from this folder. It installs the Python packages and ffmpeg and draws `selftest.png`; look at it.
- If Python is missing, give the user the one link the script prints, wait, run it again.
- Make the project folder yourself: `~/HistoryStudio/<subject>/` with `media/` and `music/`. Copy `examples/rome/episode.py` there and set `ENGINE` to this skill's `engine` folder (or the env var `CHS_ENGINE`).

## 1. Subject
Ask once whether they have a subject. If not, follow `references/research.md`: 10 ideas built on what people are watching now, each with title, cold-open moment, demand proof (real numbers you saw), how many free images and maps exist, sensitivity, suggested length. Never invent view counts.

## 2. Research and sources
Follow `references/legal.md`. Build `sources.md`: every date, number, name and quote with its source; mark traditional dates and legends as such; note where historians disagree (those notes become HISTORIANS DISAGREE tags).

## 3. Script
Follow `references/script.md`: cold open on the end or the strangest fact, the promise, one chapter per era with `[CHAPTER: PART ONE | THE KINGS]` markers, legend vs evidence, a callback ending. About 145 words a minute. Run it through the humanizer skill. Show the script and wait for the user's OK. Then write `shots.txt`: per paragraph, the map/year, the painting or photo, the scene and puppets, the labels.

## 4. Voice: the house narrator
One narrator for every film so the channel always sounds the same: **Kokoro `am_michael`, full model** (deep, calm; free and offline).
`python3 scripts/voice.py script.txt vo.wav`. The cold open is read at speed 0.95 with short gaps; from the first chapter on it slows to 0.9 with longer breaths between sentences and paragraphs (documentary pace). These are the defaults; change them only if the user asks (`--speed`, `--doc-speed`, `--flat`).
If the voice can't be installed, ask for an MP3 (`vo.mp3`) with a 2-second pause at each chapter marker (`<break time="2s" />` in ElevenLabs). Then `python3 scripts/timestamps.py vo.wav words.json`.

## 5. Art, maps, music
- Art: `python3 scripts/photos.py search "Rubens Romulus Remus"`, `get "File:..." media/` (free licences only; credit saved). Prefer famous paintings of the events, statues and busts of the people, manuscripts, coins, and photos of the real places and ruins. Label late paintings honestly ("PAINTED IN 1889").
- Maps: `python3 scripts/borders.py <year> <name>` to find the state's name in each period; the engine downloads the borders itself.
- Music: the generated epic score is the default. If the user wants a real track, they save one MP3 from a free source (`references/music.md`) into `music/`; credit it in the description if its licence asks.

## 6. Episode file
Read `references/doc.md`, then write `episode.py` from the Rome example:
1. A shot list from `shots.txt`: for each sentence, a painting/statue (`doc.art`, with the part of the picture to push into), a map moment (`doc.map` with empire keys, cities, arrows) or an ink-and-wash drawing (`doc.scene`, places and things only).
2. Big moments as film shots: the same painting several times with different crops (wide, details, aftermath).
3. Cue everything on the voiceover's words (`T('phrase')`); a new picture with almost every sentence.
4. Type: a caption with artist and date on every painting, name cards for people, year titles and the timeline at era changes, "The legend" / "What archaeologists found" notes. Chapter cards appear by themselves in the chapter pauses (`chapter_subs` gives their dates).

## 7. Check, render, deliver
1. `python3 episode.py info`, then `python3 episode.py stills 2 6 12 ...` and look at every sheet: overlapping text, empty frames, wrong dates, borders that don't match the year said.
2. Preview first. `python3 episode.py all 3` renders, mixes and writes `<episode>_final.mp4` at -14 LUFS (90 seconds take about 10 to 15 minutes; tell the user before starting).
3. The mix prints the levels: the voice leads, effects 20 dB under, music about 8 to 10 dB under. Pull frames from the final MP4 around every world change before sending.

Deliver: the MP4, `sources.md`, `upload.md` (3 titles in the "The ENTIRE History of X" family, a description with chapters/timestamps, art credits, the borders credit and a short sources line, tags, 3 thumbnail ideas: one striking painting or map, 2 to 4 words, a year).

## Extending
New era look: puppet colours and hats in `history.py`, a new set function. New region: an `Atlas` with its lon/lat box. New score mood: a branch in `engine/audio.py`.
