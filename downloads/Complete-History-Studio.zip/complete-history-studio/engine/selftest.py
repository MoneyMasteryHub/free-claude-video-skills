"""Setup check: draws one documentary frame (parchment map with borders, a caption, a year title) and saves selftest.png
next to this folder. Needs the internet once (the borders for AD 100 download into ~/.hds/borders)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import skia
from doc import ParchmentMap, year_title, caption, grain, W, H, OXBLOOD
m = ParchmentMap(-12, 24, 46, 56); surf = skia.Surface(W, H); c = surf.getCanvas()
cx, cy = m.xy(17, 40.5); z = .215
c.save(); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-cx, -cy)
m.draw_base(c, z); m.empire([(0, 100, ['Roman Empire'])])(c, 5, z); m.draw_top(c, z); c.restore()
proj = lambda lo, la: ((m.xy(lo, la)[0] - cx) * z + W / 2, (m.xy(lo, la)[1] - cy) * z + H / 2)
m.place('Roma', 12.48, 41.89, 0)(c, 5, proj); grain(c, 5)
year_title(c, 5, 0, None, 117, 'Setup check: it works'); caption(c, 5, 0, None, 'The studio is ready', 'Complete History Studio', 'Setup')
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'selftest.png'); surf.makeImageSnapshot().save(out); print('ok', os.path.abspath(out))
