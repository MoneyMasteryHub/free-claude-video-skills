"""Which states exist in a historical-basemaps snapshot, so you can write empire keys with the right names.

  python3 scripts/borders.py 100            every state in the AD 100 snapshot
  python3 scripts/borders.py -200 carth     only names containing 'carth' in the 200 BC snapshot
  python3 scripts/borders.py years          the snapshot years

Files download once into ~/.hds/borders. Data: historical-basemaps by A. Ourednik (GPL-3.0); credit it in the description."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'engine'))
from history import border_names, border_file, _BYEARS, fmt_year

if len(sys.argv) < 2: print(__doc__); sys.exit()
if sys.argv[1] == 'years': print(', '.join(fmt_year(y) for y in _BYEARS)); sys.exit()
year = int(sys.argv[1]); q = sys.argv[2].lower() if len(sys.argv) > 2 else ''
print('snapshot:', os.path.basename(border_file(year)))
for n in border_names(year):
    if q in n.lower(): print(' ', n)
