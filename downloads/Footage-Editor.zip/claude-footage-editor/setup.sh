#!/usr/bin/env bash
# One-step setup for macOS / Linux. Claude runs this; the user should not have to.
set -e
cd "$(dirname "$0")"
say() { printf '\n▸ %s\n' "$1"; }
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3.10+ is needed. Install it from https://www.python.org/downloads/, then run this again."; exit 1; fi
pipi() { python3 -m pip install --quiet --disable-pip-version-check "$@" 2>/dev/null || python3 -m pip install --quiet --disable-pip-version-check --user "$@" 2>/dev/null || python3 -m pip install --quiet --disable-pip-version-check --break-system-packages "$@" 2>/dev/null; }
say "Python packages (cutting, captions, faces). The first time takes a few minutes."
for p in numpy soundfile pillow imageio-ffmpeg opencv-python-headless; do pipi "$p" || echo "  (could not install $p)"; done
say "Speech-to-text (faster-whisper)"
if ! pipi "faster-whisper>=1.0"; then
  echo "  installing faster-whisper without onnxruntime"
  pipi ctranslate2 tokenizers huggingface_hub tqdm && pipi --no-deps "faster-whisper>=1.0" || echo "  (speech-to-text could not be installed; see SKILL.md)"
fi
say "ffmpeg (a recent build with caption support)"
mkdir -p bin
ln -sf "$(python3 -c 'import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())')" bin/ffmpeg && echo "ffmpeg ready in ./bin"
say "Self-check"
python3 engine/selftest.py
