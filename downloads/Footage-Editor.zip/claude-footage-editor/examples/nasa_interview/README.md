# Example: a space station interview

Source footage: "Space Station Crew Talks with The Associated Press", May 1, 2024 (NASA video, public domain), images.nasa.gov, the first 8 minutes, saved as `raw/iss_interview.mp4`.

- `edit.json` is a 1:20 highlight video. It opens on the strongest line ("That's our home... we really have to take care of our planet"), then the question, the answer, and two more moments. It uses auto punch-ins, long captions and music ducking. Run `tighten` on it first: 87.8 s of chosen moments become 79.8 s.
- `short1.json` is a 28-second vertical Short with big captions and a hook title.
