---
name: claude-footage-editor
description: Edits the user's own raw footage into finished videos (talking clips, interviews, podcasts, vlogs, B-roll, and screen recordings for faceless tutorials): transcribes every clip, fast-forwards the waiting in screen recordings and syncs them to a voiceover, picks the best moments, cuts silences, "umms" and retakes, orders the story for retention, adds punch-in zooms, word-by-word captions, background music that ducks under the voice, titles and privacy blurs, levels the sound to YouTube loudness, and exports a 16:9 YouTube video plus vertical Shorts/Reels/TikToks that follow the speaker's face. Free and offline. Use for "edit my video", "cut this footage", "make a YouTube video from these clips", "remove the silences", "add captions", "turn this into Shorts", "make reels from my recording", "edit my podcast/interview/vlog/tutorial", or when someone asks for this skill by name.
---

# Claude Footage Editor

The user gives Claude raw clips: a talking-head recording, a podcast, an interview, a screen recording with voice, a vlog, or B-roll from a shoot. Claude edits them like a YouTube editor would and hands back finished files. Everything runs on the user's computer, for free:
- faster-whisper for the transcript
- ffmpeg for cutting and mixing
- OpenCV for finding faces.

What Claude does that a plain "silence remover" can't is **choose**. It reads everything that was said, finds the hook, drops the waffle and the retakes, and puts the best parts in an order that keeps people watching.

Folder map:
- `engine/fe.py`: the tools (scan, tighten, retakes, beats, render, sheet).
- `references/edit.md`: the edit file format and how to plan an edit. **Read it before the first edit.**
- `assets/`: fonts (Poppins, Anton, SIL OFL) and the face model.

## 0. Setup (do it yourself; the user never types commands)
Tell the user in one line: "Setting the editor up now. The first time takes a few minutes." Then run `bash setup.sh` (macOS/Linux) or `powershell -ExecutionPolicy Bypass -File setup.ps1` (Windows) from this folder. It installs the Python packages and a recent ffmpeg (with caption support), then checks itself.
- If Python is missing, give the user the one link the script prints, wait, then run it again.
- The first transcription downloads the speech model (~500 MB, once).

## 1. Project
Make the folder yourself: `~/FootageEditor/<project>/raw/` and copy or move the user's clips into `raw/`. Put any music the user gives you in `music/`.
If they have no music, suggest a free track from the YouTube Audio Library or Pixabay Music, saved into `music/`, or edit without music.

Ask, in one round only what you can't guess:
- **What to make:** a YouTube video, Shorts, or both. Say how many Shorts.
- **Length:** for the long video, ask how long. Default to "as short as it can be while keeping everything that matters".
- **Look:** caption style or a brand colour, and anything to hide (names, emails, faces, screens).

## 2. Scan
`python3 engine/fe.py scan <project>` probes every clip, transcribes speech with word timings, and finds shot changes. It writes `<project>/transcript.md`.
Long footage takes a while (about a quarter of real time on a normal laptop), so tell the user. Read the whole transcript. Run `retakes` too.

## 3. Plan and write the edit
Follow `references/edit.md`:
1. Find the hook.
2. Order for retention.
3. Cut tangents and retakes.
4. Write `edit.json`.

For B-roll montages with no speech:
- Run `python3 engine/fe.py beats music/track.mp3`.
- Cut clips on the beats: 2, 4 or 8 beats per clip, with the best shot on a strong beat.
- Mark the clips `"broll": true, "mute": true`.

For screen recordings (tutorials, app walkthroughs), with or without a voiceover:
- Set `"screen": true`. Run `peek` on each clip and read its activity lines in `transcript.md`.
- Choose the steps that matter. Fast-forward the waiting (`"idle": "speed"`) and zoom on the part of the screen being used (`"zoom": "auto"`, or a fixed zoom with `fx`/`fy`).
- With a voiceover (`"voiceover": {"file": ...}`), pin each step to the sentence that describes it (`"at"`). The skill fits the footage to the voice and pauses the voice where the picture needs time.

Then run `python3 engine/fe.py tighten <project> edit.json` to remove silences and fillers inside the chosen segments.

## 4. Render and check
- **Render:** `python3 engine/fe.py render <project> edit.tight.json` writes `<project>/out/<name>.mp4`.
- **Check:**
  - Run `python3 engine/fe.py sheet <project>/out/<name>.mp4` and look at the sheet.
  - Captions are readable and correct. Fix misheard names in the transcript JSON under `work/transcripts/` and render again.
  - Faces aren't cut off in vertical crops (set `fx` on a segment if needed).
  - Nothing private is visible.
  - The cut points don't clip words.
- Render each Short the same way, from its own edit file with `"format": "9:16"`.

## 5. Deliver
Tell the user where the files are and what each one is, in one line each (the YouTube video and its length, Short 1 and the line it opens with, and so on), plus how much was cut ("38 minutes of raw footage into 9 minutes"). Offer a title, description and chapters made from the transcript.

Rules:
- Never invent words or change what someone said. Cutting changes length, not meaning; don't splice sentences so they say something the person didn't.
- Keep the user's originals untouched; everything new goes in `work/` and `out/`.
- Music must be something the user has the right to use.
