# The edit file (edit.json)

Claude writes one edit file per output: the long YouTube version, and one per Short. All times are in seconds, inside each clip (`transcript.md` shows them as mm:ss.ss; 01:38.68 = 98.68).

```json
{
  "name": "my_video",
  "format": "16:9",
  "punch_in": "auto",
  "captions": {"preset": "long", "highlight": "#FFD21F"},
  "music": {"file": "music/track.mp3", "volume_db": -16},
  "texts": [{"t0": 0.2, "t1": 3.0, "text": "THE HOOK LINE"}],
  "blur": [{"t0": 12.0, "t1": 18.5, "x": 0.62, "y": 0.1, "w": 0.3, "h": 0.12}],
  "segments": [
    {"clip": "talk.mp4", "in": 292.64, "out": 301.40},
    {"clip": "talk.mp4", "in": 237.79, "out": 248.10, "zoom": 1.15},
    {"clip": "broll_03.mp4", "in": 4.0, "out": 7.5, "broll": true, "mute": true}
  ]
}
```

## Top-level options
- **`format`**: `"16:9"` (1920x1080) or `"9:16"` (1080x1920, Shorts/Reels/TikTok). Vertical crops follow the main face automatically. To choose who to follow, set `"fx"` (0 to 1 across the frame) on a segment.
- **`punch_in`**: `"auto"` alternates normal and 1.12x zoom on talking segments, which hides jump cuts like a YouTube editor would. `"off"` keeps every cut at 1.0. A segment's own `"zoom"` always wins.
- **`captions`**: word-by-word, with the spoken word highlighted. Set it to `null` for no captions.
  - Presets:
    - `"long"`: bottom, mixed case, Poppins ExtraBold.
    - `"short"`: big Anton capitals at the lower third, 3 words at a time.
    - `"clean"`: smaller, 8 words.
  - Overrides: `highlight`, `color`, `size`, `y` (margin from the bottom in px), `maxw` (words per line), `upper`.
- **`music`**: a file inside the project. It loops if it's too short, fades in and out, and is ducked automatically under the voice (sidechain). `volume_db` -14 to -20 suits talking videos; use -6 to -10 for a montage with no voice.
- **`texts`**: big titles (hook lines, chapter names) at the top of the frame, in output seconds.
- **`blur`**: boxes to hide names, emails, faces, plates or screens, in output seconds and 0 to 1 frame coordinates. Check a frame first with `sheet`.
- **`fps`**: 30 by default.

## Screen recordings and voiceovers
- `"screen": true` (top level) turns off the punch-in zooms and uses screen-friendly defaults.
- **`"voiceover": {"file": "vo.mp3"}`.** The voiceover becomes the soundtrack and drives the timing:
  - Each segment with `"at": "phrase from the voiceover"` starts when that phrase is spoken. The footage until the next `at` is fitted to that stretch of the voice.
  - Waiting is squeezed first (up to 60x).
  - Readable parts speed up to 3x at most (`max_speed`, per segment or in `voiceover`).
  - If the footage still needs more time, the voice pauses there automatically.
  - Captions come from the voiceover.
- **Segment `"idle": "speed"`** fast-forwards the stretches where nothing moves (loading, generating, a still mouse), using the `idle_speed` multiplier (default 8x). **`"idle": "cut"`** removes them. `scan` lists the activity and idle stretches of every screen clip in `transcript.md`.
- **Segment `"zoom": "auto"`** zooms into where the screen is changing, easing in and out. Use a number with `fx`/`fy` to hold a fixed zoom on a part of the screen, such as the chat column of an app.
- **Segment `"play": true`** keeps a moment at normal speed (a result, a reveal, a page the viewer must read).
- `python3 engine/fe.py peek <project> <clip>` makes a contact sheet of a raw clip with timestamps, so you can see what happens when before choosing moments.

## Segment options
- **`clip`, `in`, `out`**: the moment to use.
- **`zoom`**: 1.0 to 1.4.
- **`fx`, `fy`**: centre of the crop (0 to 1).
- **`broll`**: true means no captions, and `tighten` won't cut it.
- **`mute`**: true replaces the clip's sound with silence (for B-roll under the voice or music).
- **`gain`**: dB for one quiet or loud segment.
- **`speed`**: e.g. 2 for a timelapse (video only; use with `mute`).
- **`keep_as_is`**: true means `tighten` leaves it alone (for a pause that matters, or laughter).

## How Claude plans an edit
1. **Read `transcript.md` in full.** Note:
   - the strongest line (it becomes the hook in the first 3 seconds)
   - the parts that answer the viewer's question
   - the repeats (run `retakes`)
   - the dead air and off-topic tangents
2. **Order for retention, not for recording order:**
   - the hook
   - the promise (what they'll get)
   - the content in a clear order
   - a payoff and a short ending
   - cut intros like "so, um, today I want to talk about".
3. **Write the segments.** Then run `tighten` to remove pauses and fillers inside them, and render the `.tight.json`.
4. **Check before sending:**
   - `sheet` on the output.
   - Look at frames around a few cuts. Are the captions readable? Is a face cut off in the vertical crop? Is anything private visible?
   - Listen to the first 20 seconds of the mix.
   - Fix and render again.
5. **Shorts.** Take 3 to 5 self-contained moments of 20 to 50 seconds. Each starts on its strongest sentence, with no setup. Add a `texts` hook for the first 2.5 seconds.
