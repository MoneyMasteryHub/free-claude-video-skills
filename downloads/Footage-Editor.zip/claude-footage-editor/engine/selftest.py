"""Setup check: makes a 4-second test clip, captions it and cuts it, using the same tools as a real edit."""
import os, sys, json, tempfile, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fe
d = tempfile.mkdtemp(); os.makedirs(os.path.join(d, 'raw')); os.makedirs(os.path.join(d, 'work', 'transcripts'))
src = os.path.join(d, 'raw', 'test.mp4')
fe.run(['-f', 'lavfi', '-i', 'testsrc2=s=1280x720:r=30:d=4', '-f', 'lavfi', '-i', 'sine=f=220:d=4', '-shortest', '-c:v', 'libx264', '-c:a', 'aac', src])
json.dump([dict(fe.probe(src), file='test.mp4', words=0, speech_seconds=0, long_pauses=0, scenes=[])], open(os.path.join(d, 'work', 'clips.json'), 'w'))
json.dump(dict(words=[dict(w='The', s=.2, e=.5), dict(w='editor', s=.5, e=1.0), dict(w='works.', s=1.0, e=1.6)], sentences=[]), open(os.path.join(d, 'work', 'transcripts', 'test.mp4.json'), 'w'))
e = os.path.join(d, 'edit.json'); json.dump(dict(name='selftest', segments=[dict(clip='test.mp4', **{'in': 0.0, 'out': 2.0}), dict(clip='test.mp4', **{'in': 2.5, 'out': 4.0})]), open(e, 'w'))
out = fe.render(d, e)
import faster_whisper, cv2  # noqa: F401  (both installed)
print('✓ Setup complete: the editor works (test video:', out, ')')
