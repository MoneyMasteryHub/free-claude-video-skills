# One-step setup for Windows (PowerShell). Run: powershell -ExecutionPolicy Bypass -File setup.ps1
$ErrorActionPreference = "Continue"; Set-Location $PSScriptRoot
$py = if (Get-Command python -ErrorAction SilentlyContinue) { "python" } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { Write-Host "Python 3.10+ is needed: https://www.python.org/downloads/ (tick 'Add to PATH'). Then run this again."; exit 1 }
Write-Host "Python packages (cutting, captions, facecam finder, downloader). The first time takes a few minutes."
foreach ($p in @("numpy","soundfile","pillow","imageio-ffmpeg","opencv-python-headless","yt-dlp")) { & $py -m pip install --quiet $p }
& $py -m pip install --quiet "faster-whisper>=1.0"; if ($LASTEXITCODE -ne 0) { & $py -m pip install --quiet ctranslate2 tokenizers huggingface_hub tqdm; & $py -m pip install --quiet --no-deps "faster-whisper>=1.0" }
New-Item -ItemType Directory -Force bin | Out-Null
$ff = & $py -c "import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())"; Copy-Item $ff bin\ffmpeg.exe -Force
& $py engine/selftest.py
