"""Streamer Brain: Clipper Pro's memory of each streamer. Every stream it watches teaches it more:
  - what this streamer's normal looks like (so a calm streamer's small spike counts as much as a loud streamer's big one)
  - the words and emotes this streamer's chat spams when something really happens
  - which signals (laughing, screaming, chat, facecam, game) actually line up with the moments viewers clip and rewatch
It learns from real viewer behaviour: the clips viewers made on Twitch, YouTube's "most replayed" graph, the clips you
keep or reject, and the views your posted clips get. Brains live in ~/.clipper/brains/<streamer>.json.

  python3 brain.py show <streamer>        what the brain knows
  python3 brain.py list                   every streamer studied
  python3 brain.py forget <streamer>      start that streamer over"""
import os, sys, json, re, math, time, datetime
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(HERE, '..', 'assets', 'models')
HOME = os.environ.get('CLIPPER_HOME') or os.path.join(os.path.expanduser('~'), '.clipper')
BRAINS = os.path.join(HOME, 'brains')
GQL = 'https://gql.twitch.tv/gql'; CID = {'Client-ID': 'kimne78kx3ncx6brgo4mv6wki5h1ko'}

FEATS = ['loud', 'cam', 'game', 'chat', 'laugh', 'scream', 'cheer', 'chat_laugh', 'chat_hype', 'chat_shock', 'chat_words', 'cut']
# starting weights before a brain has learned anything (features are 0..2: how far above normal, capped)
PRIOR = dict(loud=.9, cam=.5, game=.25, chat=1.0, laugh=1.1, scream=.6, cheer=.4, chat_laugh=.8, chat_hype=.6, chat_shock=.4,
             chat_words=.5, cut=.15)
PRIOR_B = -4.0
LEVELS = [(0, 'new'), (10, 'learning'), (40, 'getting good'), (120, 'experienced'), (300, 'expert')]


# ------------------------------------------------------------------ audio events (laughing, screaming, cheering)
_Y = {}
def _yamnet():
    if 'm' not in _Y:
        import onnxruntime as ort
        o = ort.SessionOptions(); o.log_severity_level = 3; o.intra_op_num_threads = max(1, (os.cpu_count() or 2) - 1)
        _Y['m'] = ort.InferenceSession(os.path.join(MODELS, 'yamnet.onnx'), o, providers=['CPUExecutionProvider'])
        names = [l.split(',', 2)[2].strip().strip('"') for l in open(os.path.join(MODELS, 'yamnet_class_map.csv'), encoding='utf-8').read().splitlines()[1:]]
        pick = lambda *ws: [i for i, n in enumerate(names) if any(w.lower() == n.lower() for w in ws)]
        _Y['laugh'] = pick('Laughter', 'Baby laughter', 'Giggle', 'Snicker', 'Belly laugh', 'Chuckle, chortle')
        _Y['scream'] = pick('Shout', 'Yell', 'Screaming', 'Children shouting', 'Battle cry')
        _Y['cheer'] = pick('Cheering', 'Applause', 'Crowd', 'Whoop')
        _Y['speech'] = pick('Speech', 'Conversation', 'Narration, monologue')
        _Y['music'] = pick('Music', 'Singing', 'Musical instrument', 'Electronic music', 'Hip hop music', 'Pop music', 'Background music', 'Theme music')
    return _Y

def audio_events(audio, sr=16000):
    """per-second probability of laughing, screaming, cheering, talking and music in 16 kHz mono audio (YAMNet, runs in seconds)"""
    n = max(1, int(math.ceil(len(audio) / sr))); out = {k: np.zeros(n, np.float32) for k in ('laugh', 'scream', 'cheer', 'speech', 'music')}
    if _Y.get('failed'): return out
    try: Y = _yamnet()
    except Exception as e:
        _Y['failed'] = True; print(f'(sound-event model not available: {type(e).__name__}; using loudness only)'); return out
    chunk = 600 * sr
    for st in range(0, len(audio), chunk):
        a = np.asarray(audio[st:st + chunk + int(.96 * sr)], np.float32)
        if len(a) < int(.96 * sr): a = np.pad(a, (0, int(.96 * sr) - len(a)))
        sc = Y['m'].run(None, {'waveform': a})[0]                      # (frames, 521), one frame every 0.48 s
        for k in out:
            p = sc[:, Y[k]].max(1) if Y[k] else np.zeros(len(sc))
            for f, v in enumerate(p):
                i = int((st / sr) + f * .48 + .48)
                if 0 <= i < n: out[k][i] = max(out[k][i], float(v))
    return out


# ------------------------------------------------------------------ chat moods
LAUGH = re.compile(r"(lmao|lmfao|lol|kek|omegalul|lul|haha|hahah|jaja|ahah|xd\b|icant|💀|😂|🤣|😭|☠)", re.I)
HYPE = re.compile(r"(\bw+\b|pog|lets ?go+|sheesh|goat|clip|insane|crazy|holy|🔥|🐐|!!+|^[A-Z0-9 !?]{6,}$)", re.I)
SHOCK = re.compile(r"(no way|wtf|omg|oh my god|what\b|bro what|actually|nah+|😳|😱|🤯|wait)", re.I)

def tokens(msg):
    msg = re.sub(r'(.)\1{2,}', r'\1\1', msg.lower())                 # lmaoooooo -> lmaoo
    ts = re.findall(r"[a-z0-9']{2,}|[\U0001F300-\U0001FAFF☀-➿]", msg)
    return set(t.strip("'") for t in ts if t.strip("'"))

def chat_features(msgs, n, brain=None, ahead=(1, 8)):
    """per-second chat features from [{t, m}] (times in seconds): how much chat there is in the seconds after each
    moment, and what share of it is laughing, hyped, shocked, or the words this streamer's chat uses for big moments"""
    lift = learned_words(brain) if brain else {}
    cnt = np.zeros(n + 12); mood = {k: np.zeros(n + 12) for k in ('chat_laugh', 'chat_hype', 'chat_shock', 'chat_words')}
    for m in msgs:
        k = int(m['t'])
        if not 0 <= k < n + 12: continue
        tx = m.get('m', ''); cnt[k] += 1
        mood['chat_laugh'][k] += bool(LAUGH.search(tx)); mood['chat_hype'][k] += bool(HYPE.search(tx)); mood['chat_shock'][k] += bool(SHOCK.search(tx))
        if lift: mood['chat_words'][k] += min(3.0, sum(lift.get(t, 0) for t in tokens(tx)))
    a, b = ahead; win = lambda v: np.array([v[i + a:i + b].sum() for i in range(n)])
    total = win(cnt); F = dict(chat=total)
    for k, v in mood.items(): F[k] = win(v) / np.maximum(total, 3)            # a share, so slow and fast chats compare
    return F


# ------------------------------------------------------------------ turning raw signals into comparable features
def _rz(x, win=301):
    """how far above this stream's normal (rolling median, robust spread)"""
    x = np.asarray(x, float)
    if len(x) < 5: return np.zeros(len(x))
    pad = min(win // 2, len(x) - 1); xp = np.pad(x, pad, mode='edge')
    from numpy.lib.stride_tricks import sliding_window_view
    base = np.median(sliding_window_view(xp, 2 * pad + 1), axis=1)[:len(x)]
    r = x - base; mad = np.median(np.abs(r - np.median(r))) * 1.4826
    if mad < 1e-6: mad = np.std(r) + 1e-6
    return r / mad

def features(raw, brain=None):
    """raw: dict of per-second arrays -> X (seconds x FEATS), each 0..2, smoothed so a moment counts for a few seconds"""
    n = len(next(iter(raw.values()))); X = np.zeros((n, len(FEATS)))
    for j, f in enumerate(FEATS):
        v = np.asarray(raw.get(f, np.zeros(n)), float)[:n]
        if len(v) < n: v = np.pad(v, (0, n - len(v)))
        if not v.any(): continue
        if f in ('laugh', 'scream', 'cheer'): z = v * 4 + np.clip(_rz(v), 0, 4) * .25        # probabilities: absolute + relative
        elif f == 'cut': z = v * 4
        else: z = _rz(v)
        X[:, j] = np.clip(z, 0, 8) / 4
    from numpy.lib.stride_tricks import sliding_window_view
    Xp = np.pad(X, ((2, 2), (0, 0)), mode='edge')
    return sliding_window_view(Xp, 5, axis=0).max(-1)


# ------------------------------------------------------------------ the brain file
def slug(name): return re.sub(r'[^a-z0-9_-]+', '-', (name or 'unknown').lower()).strip('-') or 'unknown'
def path(name): return os.path.join(BRAINS, slug(name) + '.json')

def load(name):
    p = path(name)
    if os.path.exists(p):
        try: return json.load(open(p, encoding='utf-8'))
        except Exception: pass
    base = None
    if slug(name) != '_all' and os.path.exists(path('_all')):
        try: base = json.load(open(path('_all'), encoding='utf-8'))
        except Exception: base = None
    return dict(name=name, slug=slug(name), created=time.time(), streams=[], seconds=0, positives=0, viewer_clips=0, feedback=[],
                w=dict((base or {}).get('w') or PRIOR), b=(base or {}).get('b', PRIOR_B), X=[], y=[], sw=[],
                words={}, msgs=[0, 0], hist={}, hits=[])

def save(b):
    os.makedirs(BRAINS, exist_ok=True); p = path(b['name']); tmp = p + '.tmp'
    json.dump(b, open(tmp, 'w', encoding='utf-8')); os.replace(tmp, p)

def level(b):
    lv = LEVELS[0][1]
    for k, n in LEVELS:
        if b.get('positives', 0) >= k: lv = n
    return lv

def learned_words(b, top=300):
    """chat words this streamer's chat uses far more during real moments than normally -> log-lift"""
    pos, tot = b.get('msgs', [0, 0]); out = {}
    if pos < 50: return out
    for t, e in b.get('words', {}).items():
        p, a = e[0], e[1]
        if p < 4 or (e[2] if len(e) > 2 else 0) < 3: continue        # must show up in 3+ different big moments, not one story
        lift = (p / pos) / max(1e-9, a / max(1, tot))
        if lift > 1.8: out[t] = round(math.log(lift), 3)
    return dict(sorted(out.items(), key=lambda kv: -kv[1])[:top])

def predict(b, X):
    """how likely each second is a moment viewers would clip (0..1), from what the brain has learned"""
    w = np.array([b['w'].get(f, PRIOR[f]) for f in FEATS]); z = X @ w + b.get('b', PRIOR_B)
    return 1 / (1 + np.exp(-np.clip(z, -30, 30)))

def _fit(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def learn(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def _runs(mask):
    r, st = [], None
    for i, v in enumerate(list(mask) + [False]):
        if v and st is None: st = i
        if not v and st is not None: r.append((st, i)); st = None
    return r

def record_hits(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def summary(b):
    words = list(learned_words(b, 12))
    hr = [h for h in b.get('hits', [])[-10:] if h['picks']]
    rate = round(100 * sum(h['hits'] for h in hr) / max(1, sum(h['picks'] for h in hr))) if hr else None
    w = b.get('w', PRIOR); top = sorted(FEATS, key=lambda f: -w.get(f, 0))[:3]
    nice = dict(loud='loudness', cam='facecam reactions', game='game action', chat='chat speed', laugh='laughing', scream='screaming',
                cheer='cheering', chat_laugh='chat laughing', chat_hype='chat hype', chat_shock='chat shock', chat_words='their chat\'s own words', cut='screen changes')
    return dict(streamer=b['name'], level=level(b), streams=len(b.get('streams', [])), hours=round(b.get('seconds', 0) / 3600, 1),
                moments_learned=b.get('positives', 0), hit_rate=rate, chat_words=words, trusts=[nice[f] for f in top])


# ------------------------------------------------------------------ viewer votes: clips viewers made, YouTube "most replayed"
def _gql(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def _ts(s): return datetime.datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()

def twitch_vod(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

CLIP_Q = '''query($l:String!){ user(login:$l){ %s } }'''
def _user_clips(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def twitch_vod_clips(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def strong(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def twitch_live_clips(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def youtube_replayed(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')

def mask_from(*a, **k):
    raise SystemExit('This is a Clipper Pro feature (viewer clips and the Streamer Brain).')


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    if a[0] == 'list':
        if not os.path.isdir(BRAINS): print('no streamers studied yet'); sys.exit()
        for f in sorted(os.listdir(BRAINS)):
            if f.endswith('.json') and not f.startswith('_'):
                s = summary(json.load(open(os.path.join(BRAINS, f), encoding='utf-8')))
                print(f"{s['streamer']:<20} {s['level']:<13} {s['streams']} streams, {s['hours']} h watched, {s['moments_learned']} moments learned"
                      + (f", hit rate {s['hit_rate']}%" if s['hit_rate'] is not None else ''))
    elif a[0] == 'show' and len(a) > 1: print(json.dumps(summary(load(a[1])), indent=1, ensure_ascii=False))
    elif a[0] == 'forget' and len(a) > 1:
        if os.path.exists(path(a[1])): os.remove(path(a[1])); print('forgot', a[1])
    else: print(__doc__)


def show_start(speech, need=8, win=30):
    """the second the real show starts: the first 30 s with 8+ seconds of talking. Before that it's a "starting soon" /
    waiting screen (music, a countdown, chat spamming), which must never be clipped. None = nobody talks at all."""
    sp = np.asarray(speech) > .5
    c = np.convolve(sp.astype(float), np.ones(win), 'full')[:len(sp)]
    hit = np.where(c >= need)[0]
    return int(max(0, hit[0] - win + 1)) if len(hit) else None

def talk_near(speech, before=20, after=5):
    """is anyone talking around each second (BRB screens, ads and waiting screens have nobody talking)"""
    sp = np.asarray(speech, float); n = len(sp); out = np.zeros(n)
    for i in range(n): out[i] = sp[max(0, i - before):i + after + 1].max() if n else 0
    return out

