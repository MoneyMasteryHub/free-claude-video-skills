"""Clipper's moment detectors, shared by Clipper and Clipper Pro: laughing / screaming / talking / music in the audio
(YAMNet, a small sound model), chat mood, the per-second features, and spotting "starting soon" / waiting screens."""
import os, sys, json, re, math, time, datetime
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(HERE, '..', 'assets', 'models')
HOME = os.environ.get('CLIPPER_HOME') or os.path.join(os.path.expanduser('~'), '.clipper')

FEATS = ['loud', 'cam', 'game', 'chat', 'laugh', 'scream', 'cheer', 'chat_laugh', 'chat_hype', 'chat_shock', 'chat_words', 'cut']
# starting weights before a brain has learned anything (features are 0..2: how far above normal, capped)
PRIOR = dict(loud=.9, cam=.5, game=.25, chat=1.0, laugh=1.1, scream=.6, cheer=.4, chat_laugh=.8, chat_hype=.6, chat_shock=.4,
             chat_words=.5, cut=.15)
PRIOR_B = -4.0


# ------------------------------------------------------------------ audio events (laughing, screaming, cheering)
_Y = {}
def _yamnet():
    if 'm' not in _Y:
        import onnxruntime as ort
        o = ort.SessionOptions(); o.log_severity_level = 3; o.intra_op_num_threads = max(1, (os.cpu_count() or 2) - 1)
        _Y['m'] = ort.InferenceSession(os.path.join(MODELS, 'yamnet.onnx'), o, providers=['CPUExecutionProvider'])
        names = [l.split(',', 2)[2].strip().strip('"') for l in open(os.path.join(MODELS, 'yamnet_class_map.csv'), encoding='utf-8').read().splitlines()[1:]]
        pick = lambda *ws: [i for i, n in enumerate(names) if any(w.lower() == n.lower() for w in ws)]
        _Y['laugh'] = pick('Laughter', 'Baby laughter', 'Giggle', 'Snicker', 'Belly laugh', 'Chuckle, chortle')
        _Y['scream'] = pick('Shout', 'Yell', 'Screaming', 'Children shouting', 'Battle cry')
        _Y['cheer'] = pick('Cheering', 'Applause', 'Crowd', 'Whoop')
        _Y['speech'] = pick('Speech', 'Conversation', 'Narration, monologue')
        _Y['music'] = pick('Music', 'Singing', 'Musical instrument', 'Electronic music', 'Hip hop music', 'Pop music', 'Background music', 'Theme music')
    return _Y

def audio_events(audio, sr=16000):
    """per-second probability of laughing, screaming, cheering, talking and music in 16 kHz mono audio (YAMNet, runs in seconds)"""
    n = max(1, int(math.ceil(len(audio) / sr))); out = {k: np.zeros(n, np.float32) for k in ('laugh', 'scream', 'cheer', 'speech', 'music')}
    if _Y.get('failed'): return out
    try: Y = _yamnet()
    except Exception as e:
        _Y['failed'] = True; print(f'(sound-event model not available: {type(e).__name__}; using loudness only)'); return out
    chunk = 600 * sr
    for st in range(0, len(audio), chunk):
        a = np.asarray(audio[st:st + chunk + int(.96 * sr)], np.float32)
        if len(a) < int(.96 * sr): a = np.pad(a, (0, int(.96 * sr) - len(a)))
        sc = Y['m'].run(None, {'waveform': a})[0]                      # (frames, 521), one frame every 0.48 s
        for k in out:
            p = sc[:, Y[k]].max(1) if Y[k] else np.zeros(len(sc))
            for f, v in enumerate(p):
                i = int((st / sr) + f * .48 + .48)
                if 0 <= i < n: out[k][i] = max(out[k][i], float(v))
    return out


# ------------------------------------------------------------------ chat moods
LAUGH = re.compile(r"(lmao|lmfao|lol|kek|omegalul|lul|haha|hahah|jaja|ahah|xd\b|icant|💀|😂|🤣|😭|☠)", re.I)
HYPE = re.compile(r"(\bw+\b|pog|lets ?go+|sheesh|goat|clip|insane|crazy|holy|🔥|🐐|!!+|^[A-Z0-9 !?]{6,}$)", re.I)
SHOCK = re.compile(r"(no way|wtf|omg|oh my god|what\b|bro what|actually|nah+|😳|😱|🤯|wait)", re.I)

def tokens(msg):
    msg = re.sub(r'(.)\1{2,}', r'\1\1', msg.lower())                 # lmaoooooo -> lmaoo
    ts = re.findall(r"[a-z0-9']{2,}|[\U0001F300-\U0001FAFF☀-➿]", msg)
    return set(t.strip("'") for t in ts if t.strip("'"))

def chat_features(msgs, n, lift=None, ahead=(1, 8)):
    """per-second chat features from [{t, m}] (times in seconds): how much chat there is in the seconds after each
    moment, and what share of it is laughing, hyped, shocked, or the words this streamer's chat uses for big moments"""
    lift = lift or {}
    cnt = np.zeros(n + 12); mood = {k: np.zeros(n + 12) for k in ('chat_laugh', 'chat_hype', 'chat_shock', 'chat_words')}
    for m in msgs:
        k = int(m['t'])
        if not 0 <= k < n + 12: continue
        tx = m.get('m', ''); cnt[k] += 1
        mood['chat_laugh'][k] += bool(LAUGH.search(tx)); mood['chat_hype'][k] += bool(HYPE.search(tx)); mood['chat_shock'][k] += bool(SHOCK.search(tx))
        if lift: mood['chat_words'][k] += min(3.0, sum(lift.get(t, 0) for t in tokens(tx)))
    a, b = ahead; win = lambda v: np.array([v[i + a:i + b].sum() for i in range(n)])
    total = win(cnt); F = dict(chat=total)
    for k, v in mood.items(): F[k] = win(v) / np.maximum(total, 3)            # a share, so slow and fast chats compare
    return F


# ------------------------------------------------------------------ turning raw signals into comparable features
def _rz(x, win=301):
    """how far above this stream's normal (rolling median, robust spread)"""
    x = np.asarray(x, float)
    if len(x) < 5: return np.zeros(len(x))
    pad = min(win // 2, len(x) - 1); xp = np.pad(x, pad, mode='edge')
    from numpy.lib.stride_tricks import sliding_window_view
    base = np.median(sliding_window_view(xp, 2 * pad + 1), axis=1)[:len(x)]
    r = x - base; mad = np.median(np.abs(r - np.median(r))) * 1.4826
    if mad < 1e-6: mad = np.std(r) + 1e-6
    return r / mad

def features(raw):
    """raw: dict of per-second arrays -> X (seconds x FEATS), each 0..2, smoothed so a moment counts for a few seconds"""
    n = len(next(iter(raw.values()))); X = np.zeros((n, len(FEATS)))
    for j, f in enumerate(FEATS):
        v = np.asarray(raw.get(f, np.zeros(n)), float)[:n]
        if len(v) < n: v = np.pad(v, (0, n - len(v)))
        if not v.any(): continue
        if f in ('laugh', 'scream', 'cheer'): z = v * 4 + np.clip(_rz(v), 0, 4) * .25        # probabilities: absolute + relative
        elif f == 'cut': z = v * 4
        else: z = _rz(v)
        X[:, j] = np.clip(z, 0, 8) / 4
    from numpy.lib.stride_tricks import sliding_window_view
    Xp = np.pad(X, ((2, 2), (0, 0)), mode='edge')
    return sliding_window_view(Xp, 5, axis=0).max(-1)



def predict(b, X):
    """how likely each second is a moment worth clipping (0..1) for weights b = {'w': {...}, 'b': bias}"""
    w = np.array([b['w'].get(f, PRIOR[f]) for f in FEATS]); z = X @ w + b.get('b', PRIOR_B)
    return 1 / (1 + np.exp(-np.clip(z, -30, 30)))


def show_start(speech, need=8, win=30):
    """the second the real show starts: the first 30 s with 8+ seconds of talking. Before that it's a "starting soon" /
    waiting screen (music, a countdown, chat spamming), which must never be clipped. None = nobody talks at all."""
    sp = np.asarray(speech) > .5
    c = np.convolve(sp.astype(float), np.ones(win), 'full')[:len(sp)]
    hit = np.where(c >= need)[0]
    if not len(hit): return None
    i = hit[0]; return int(max(0, i - win + 1) + np.argmax(sp[max(0, i - win + 1):i + 1]))     # the first talking second

def talk_near(speech, before=20, after=5):
    """is anyone talking around each second (BRB screens, ads and waiting screens have nobody talking)"""
    sp = np.asarray(speech, float); n = len(sp); out = np.zeros(n)
    for i in range(n): out[i] = sp[max(0, i - before):i + after + 1].max() if n else 0
    return out
