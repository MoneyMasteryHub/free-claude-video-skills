"""Setup check: makes a 12-second fake stream (game + a facecam box), finds its loud moment and renders a vertical clip
with the facecam on top and a hook line, using the same tools as a real run."""
import os, sys, json, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fe, sc
d = tempfile.mkdtemp(); os.makedirs(os.path.join(d, 'raw'))
src = os.path.join(d, 'raw', 'stream.mp4')
fe.run(['-f', 'lavfi', '-i', 'testsrc2=s=1280x720:r=30:d=12', '-f', 'lavfi', '-i', 'color=c=0x445566:s=300x220:d=12',
        '-f', 'lavfi', '-i', "aevalsrc='0.05*sin(2*PI*220*t)*if(between(t,6,8),12,1)':d=12:s=48000",
        '-filter_complex', '[0:v][1:v]overlay=10:490[v]', '-map', '[v]', '-map', '2:a', '-c:v', 'libx264', '-c:a', 'aac', src])
import numpy as np
sc.face_finder()(np.zeros((360, 640, 3), np.uint8))          # the face finder loads and runs on this OpenCV
sc.find_cam(d, [0.008, 0.68, 0.234, 0.306])
S = sc.signals(d); peak = max(range(len(S['score'])), key=lambda i: S['score'][i])
assert 5 <= peak <= 9, f'loud moment found at {peak}s, expected about 6-8s'
c = os.path.join(d, 'clips.json')
json.dump(dict(captions=None, clips=[dict(name='selftest', **{'in': 4.0, 'out': 10.0}, hook='Setup works',
                                         judge=dict(hook=7, payoff=7, standalone=7, emotion=7, share=7))]), open(c, 'w'))
out = sc.render(d, c)
import faster_whisper, cv2  # noqa: F401  (both installed)
print('✓ Setup complete: the clipper works (test clip:', out[0], ')')
