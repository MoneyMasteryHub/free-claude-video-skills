"""Claude Footage Editor: the tools Claude uses to edit a person's own footage.

  python3 fe.py scan   <project>                      probe + transcribe every clip in <project>/raw, write transcript.md and clips.json
  python3 fe.py tighten <project> <edit.json>          cut silences, "um"s and gaps inside the chosen segments (writes edit.tight.json)
  python3 fe.py retakes <project>                      list sentences said more than once (keep the last take)
  python3 fe.py beats  <music.mp3>                     beat times of a music track (for montages)
  python3 fe.py render <project> <edit.json>           cut, zoom, caption, music, blur, level -> <project>/out/<name>.mp4
  python3 fe.py peek   <project> <clip> [n]            contact sheet of a raw clip with timestamps (see what happens when)
  python3 fe.py sheet  <video.mp4> [n]                 contact sheet of n frames, to check an edit
Edit files are JSON (see references/edit.md). Claude reads transcript.md, chooses the moments, writes the edit file, renders, checks."""
import os, sys, json, re, subprocess, shutil, math, glob, tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
FONTS = os.path.join(ROOT, 'assets', 'fonts')
VIDEO_EXT = ('.mp4', '.mov', '.mkv', '.m4v', '.avi', '.webm', '.mts', '.3gp')
AUDIO_EXT = ('.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg')
FILLERS = {'um', 'uh', 'erm', 'er', 'ah', 'uhm', 'hmm', 'mm', 'umm', 'uhh', 'eh'}


def ffmpeg():
    local = os.path.join(ROOT, 'bin', 'ffmpeg.exe' if os.name == 'nt' else 'ffmpeg')
    if os.path.exists(local): return local
    try:
        import imageio_ffmpeg; return imageio_ffmpeg.get_ffmpeg_exe()      # a recent build with libass (captions)
    except Exception: return shutil.which('ffmpeg') or 'ffmpeg'
FF = ffmpeg()

def run(args, quiet=True):
    r = subprocess.run([FF, '-hide_banner', '-y'] + (['-v', 'error'] if quiet else []) + args, capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit('ffmpeg failed:\n' + r.stderr[-3000:])
    return r

def probe(path):
    """duration, width, height, fps, rotation, has_audio (from ffmpeg's own output, so no ffprobe is needed)"""
    r = subprocess.run([FF, '-hide_banner', '-i', path], capture_output=True, text=True).stderr
    d = re.search(r'Duration: (\d+):(\d+):([\d.]+)', r); dur = int(d[1]) * 3600 + int(d[2]) * 60 + float(d[3]) if d else 0
    v = re.search(r'Video:.*?(\d{2,5})x(\d{2,5})', r); w, h = (int(v[1]), int(v[2])) if v else (0, 0)
    f = re.search(r'([\d.]+) fps', r); fps = float(f[1]) if f else 30.0
    rot = re.search(r'rotate\s*:\s*(-?\d+)', r) or re.search(r'rotation of (-?[\d.]+)', r)
    if rot and abs(float(rot[1])) % 180 == 90: w, h = h, w
    return dict(duration=round(dur, 3), width=w, height=h, fps=fps, audio='Audio:' in r, video=bool(v))

def tc(t):
    t = max(0, t); return f'{int(t // 60):02d}:{t % 60:05.2f}'


# ------------------------------------------------------------------ scan: probe + transcribe
def transcribe(path, model_name='small', language=None):
    from faster_whisper import WhisperModel
    m = WhisperModel(model_name, device='cpu', compute_type='int8')
    # decode with ffmpeg ourselves (16 kHz mono): works with any video format and avoids PyAV version problems
    raw = subprocess.run([FF, '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True).stdout
    audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    segs, info = m.transcribe(audio, word_timestamps=True, vad_filter=True, language=language, beam_size=3)
    words, sents = [], []
    for s in segs:
        ws = [dict(w=w.word.strip(), s=round(w.start, 3), e=round(w.end, 3)) for w in (s.words or []) if w.word.strip()]
        words += ws
        if ws: sents.append(dict(s=ws[0]['s'], e=ws[-1]['e'], text=s.text.strip()))
    return dict(language=info.language, words=words, sentences=sents)

def scan(project, model='small', language=None):
    raw = os.path.join(project, 'raw'); cache = os.path.join(project, 'work', 'transcripts'); os.makedirs(cache, exist_ok=True)
    files = sorted(f for f in os.listdir(raw) if f.lower().endswith(VIDEO_EXT + AUDIO_EXT))
    if not files: raise SystemExit(f'no video or audio files in {raw}')
    clips, md = [], ['# Transcript\n', 'Times are mm:ss.ss inside each clip. Pick moments by clip name and times.\n']
    for f in files:
        p = os.path.join(raw, f); info = probe(p); info['file'] = f
        jp = os.path.join(cache, f + '.json')
        if info['audio']:
            if not os.path.exists(jp):
                print(f'transcribing {f} ({tc(info["duration"])}) ...', flush=True); json.dump(transcribe(p, model, language), open(jp, 'w'))
            tr = json.load(open(jp))
        else: tr = dict(words=[], sentences=[])
        words = tr['words']; speech = sum(w['e'] - w['s'] for w in words)
        gaps = [(a['e'], b['s']) for a, b in zip(words, words[1:]) if b['s'] - a['e'] > 1.0]
        info.update(words=len(words), speech_seconds=round(speech, 1), long_pauses=len(gaps), scenes=scenes(p, info))
        clips.append(info)
        md.append(f'\n## {f}  ·  {tc(info["duration"])}  ·  {info["width"]}x{info["height"]}  ·  {"speech" if words else "no speech (b-roll)"}\n')
        if info['scenes']: md.append('Shot changes at: ' + ', '.join(tc(s) for s in info['scenes'][:40]) + '\n')
        for s in tr['sentences']: md.append(f'- [{tc(s["s"])} - {tc(s["e"])}] {s["text"]}')
        if info['video'] and (not words or info['width'] >= 1600):         # screen recordings and silent clips: what moves when
            md.append('Activity (screen changes):'); md += activity_summary(activity(project, f), info['duration'])
    json.dump(clips, open(os.path.join(project, 'work', 'clips.json'), 'w'), indent=1)
    open(os.path.join(project, 'transcript.md'), 'w', encoding='utf-8').write('\n'.join(md) + '\n')
    print(f'{len(clips)} clips scanned -> {os.path.join(project, "transcript.md")}')

def scenes(path, info, thr=.32):
    """shot changes (for b-roll and multi-shot clips); fast: low-res, 5 fps"""
    if not info['video'] or info['duration'] > 3600: return []
    r = subprocess.run([FF, '-hide_banner', '-v', 'info', '-i', path, '-an', '-vf', f"fps=5,scale=160:-2,select='gt(scene,{thr})',showinfo", '-f', 'null', '-'],
                       capture_output=True, text=True).stderr
    return [round(float(m), 2) for m in re.findall(r'pts_time:([\d.]+)', r)]


# ------------------------------------------------------------------ helpers Claude uses while planning
def load_words(project, clip):
    return json.load(open(os.path.join(project, 'work', 'transcripts', clip + '.json')))['words']

def tighten(project, edit_path, max_gap=.35, pad_in=.06, pad_out=.14, drop_fillers=True):
    """split every speech segment at pauses longer than max_gap and drop filler words; keeps the words, removes the air"""
    E = json.load(open(edit_path)); out = []
    for seg in E['segments']:
        if seg.get('keep_as_is') or seg.get('broll'): out.append(seg); continue
        try: words = load_words(project, seg['clip'])
        except FileNotFoundError: out.append(seg); continue
        ws = [w for w in words if w['s'] >= seg['in'] - .05 and w['e'] <= seg['out'] + .05]
        if drop_fillers: ws = [w for w in ws if re.sub(r'[^a-z]', '', w['w'].lower()) not in FILLERS]
        if not ws: continue
        runs = [[ws[0]]]
        for a, b in zip(ws, ws[1:]):
            if b['s'] - a['e'] > max_gap: runs.append([b])
            else: runs[-1].append(b)
        for r in runs:
            s = dict(seg); s['in'] = round(max(seg['in'], r[0]['s'] - pad_in), 3); s['out'] = round(min(seg['out'], r[-1]['e'] + pad_out), 3)
            if s['out'] - s['in'] > .25: out.append(s)
    before = sum(s['out'] - s['in'] for s in E['segments']); after = sum(s['out'] - s['in'] for s in out)
    E['segments'] = out; p = edit_path.replace('.json', '.tight.json'); json.dump(E, open(p, 'w'), indent=1)
    print(f'{len(out)} segments, {before:.1f}s -> {after:.1f}s ({before - after:.1f}s of silence and fillers removed) -> {p}')

def retakes(project):
    """sentences whose first words repeat within 90 s: usually a retake; the last one is normally the keeper"""
    clips = json.load(open(os.path.join(project, 'work', 'clips.json')))
    for c in clips:
        try: tr = json.load(open(os.path.join(project, 'work', 'transcripts', c['file'] + '.json')))
        except FileNotFoundError: continue
        S = tr['sentences']; key = lambda s: ' '.join(re.sub(r'[^a-z ]', '', s['text'].lower()).split()[:4])
        for i, a in enumerate(S):
            for b in S[i + 1:]:
                if b['s'] - a['s'] > 90: break
                if len(key(a).split()) >= 3 and key(a) == key(b):
                    print(f'{c["file"]}: "{a["text"][:60]}" at {tc(a["s"])} and again at {tc(b["s"])} -> keep {tc(b["s"])}')

def beats(path):
    """rough beat times from onset energy (good enough to cut a montage on the music)"""
    tmp = os.path.join(tempfile.gettempdir(), 'fe_beats.wav'); run(['-i', path, '-ac', '1', '-ar', '22050', tmp])
    import soundfile as sf
    x, sr = sf.read(tmp); hop = 512; n = len(x) // hop
    e = np.array([np.sum(x[i * hop:(i + 1) * hop] ** 2) for i in range(n)]); flux = np.maximum(0, np.diff(np.log1p(e * 1000), prepend=0))
    ac = np.correlate(flux - flux.mean(), flux - flux.mean(), 'full')[len(flux) - 1:]
    lo, hi = int(60 / 180 * sr / hop), int(60 / 70 * sr / hop); period = lo + int(np.argmax(ac[lo:hi]))
    phase = int(np.argmax([flux[p::period].sum() for p in range(period)]))
    bt = [round((phase + k * period) * hop / sr, 3) for k in range((n - phase) // period)]
    print(f'tempo ~{60 / (period * hop / sr):.0f} bpm, {len(bt)} beats'); print(json.dumps(bt)); return bt


# ------------------------------------------------------------------ render
def face_x(path, t0, t1, w, h):
    """horizontal centre of the main face over a segment (for vertical crops); falls back to the centre"""
    try:
        import cv2
    except ImportError: return .5
    try:
        cas = cv2.CascadeClassifier(os.path.join(ROOT, 'assets', 'models', 'haarcascade_frontalface_default.xml'))
        if cas.empty(): return .5
    except Exception: return .5
    cap = cv2.VideoCapture(path); xs = []
    for k in range(6):
        cap.set(cv2.CAP_PROP_POS_MSEC, (t0 + (t1 - t0) * (k + .5) / 6) * 1000); ok, fr = cap.read()
        if not ok: continue
        g = cv2.cvtColor(cv2.resize(fr, (640, int(640 * fr.shape[0] / fr.shape[1]))), cv2.COLOR_BGR2GRAY)
        f = cas.detectMultiScale(g, 1.1, 5, minSize=(40, 40))
        if len(f): x, y, fw, fh = max(f, key=lambda r: r[2] * r[3]); xs.append((x + fw / 2) / g.shape[1])
    cap.release(); return float(np.median(xs)) if xs else .5

def seg_filter(seg, info, W, H, zoom, vertical, fx):
    """crop/zoom/scale for one segment to the output frame"""
    sw, sh = info['width'], info['height']; aspect = W / H
    if vertical:
        cw = min(sw, sh * aspect); ch = cw / aspect
    else:
        if sw / sh >= aspect: ch = sh; cw = sh * aspect
        else: cw = sw; ch = sw / aspect
    cw, ch = cw / zoom, ch / zoom
    cx = min(max(fx * sw, cw / 2), sw - cw / 2); cy = min(max(seg.get('fy', .45 if zoom > 1 else .5) * sh, ch / 2), sh - ch / 2)
    return f"crop={int(cw) // 2 * 2}:{int(ch) // 2 * 2}:{int(cx - cw / 2)}:{int(cy - ch / 2)},scale={W}:{H}:flags=lanczos,setsar=1"

def ass_time(t): t = max(0, t); return f'{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}'

def captions_ass(words, W, H, style, path, texts=()):
    """word-by-word captions: the phrase on screen, the word being said highlighted"""
    st = dict(long=dict(font='Poppins ExtraBold', size=int(H * .056), y=int(H * .11), maxw=5, upper=False),
              short=dict(font='Anton', size=int(W * .1), y=int(H * .3), maxw=3, upper=True),
              clean=dict(font='Poppins Bold', size=int(H * .045), y=int(H * .08), maxw=8, upper=False),
              stream=dict(font='Montserrat Black', size=int(W * .115), y=int(H * .3), maxw=3, upper=True))[style.get('preset', 'long')]
    st.update({k: v for k, v in style.items() if k in ('size', 'y', 'maxw', 'upper', 'font')})
    ol = style.get('outline', max(3, st['size'] // 14)); sh_ = style.get('shadow', max(1, st['size'] // 30)); grow = style.get('grow', 108)
    at = f"{{\\an5\\pos({W // 2},{int(style['pos_y'])})}}" if style.get('pos_y') else ''     # centre the captions on a line
    ty = int(style.get('title_y', H * .1)); tsize = int(style.get('title_size', st['size'] * 1.15))
    hi = style.get('highlight', '#FFD21F'); base = style.get('color', '#FFFFFF')
    bgr = lambda h: '&H00' + h[5:7] + h[3:5] + h[1:3]
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{st['font']},{st['size']},{bgr(base)},{bgr(base)},&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,{ol},{sh_},2,60,60,{st['y']},1
Style: Title,{st['font']},{tsize},{bgr(style.get('title_color', base))},{bgr(base)},&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,{max(3, tsize // 12)},2,8,70,70,{ty},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    if style.get('off'): words = []                                # titles only, no captions
    phrases, cur = [], []
    for w in words:
        if cur and (len(cur) >= st['maxw'] or w.get('brk') or w['s'] - cur[-1]['e'] > .45 or re.search(r'[.?!,]$', cur[-1]['w'])): phrases.append(cur); cur = []
        cur.append(w)
    if cur: phrases.append(cur)
    for n_, p in enumerate(phrases):
        nxt = phrases[n_ + 1][0]['s'] if n_ + 1 < len(phrases) else 1e9
        for i, w in enumerate(p):
            t0 = w['s']; t1 = p[i + 1]['s'] if i + 1 < len(p) else min(p[-1]['e'] + .25, nxt)
            parts = []
            for j, x in enumerate(p):
                tx = x['w'].upper() if st['upper'] else x['w']
                tx = tx.replace('{', '(').replace('}', ')')
                parts.append(('{\\c' + bgr(hi) + f'&\\fscx{grow}\\fscy{grow}}}' + tx + '{\\c' + bgr(base) + '&\\fscx100\\fscy100}') if j == i else tx)
            pop = '{\\fad(40,0)}' if i == 0 else ''
            ev.append(f'Dialogue: 0,{ass_time(t0)},{ass_time(t1)},Cap,,0,0,0,,{at}{pop}{" ".join(parts)}')
    for x in texts:
        ev.append(f"Dialogue: 1,{ass_time(x['t0'])},{ass_time(x['t1'])},Title,,0,0,0,,{{\\fad(200,200)}}{x['text']}")
    open(path, 'w', encoding='utf-8').write(head + '\n'.join(ev) + '\n')

# ------------------------------------------------------------------ screen recordings: activity, idle time, where the action is
def activity(project, clip, fps=4):
    """per 1/fps s: how much of the screen changed, and the box around the change (0..1). Cached."""
    cp = os.path.join(project, 'work', 'activity', clip + '.json')
    if os.path.exists(cp): return json.load(open(cp))
    os.makedirs(os.path.dirname(cp), exist_ok=True); src = os.path.join(project, 'raw', clip)
    raw = subprocess.run([FF, '-v', 'error', '-i', src, '-an', '-vf', f'fps={fps},scale=320:180,format=gray', '-f', 'rawvideo', '-'], capture_output=True).stdout
    fr = np.frombuffer(raw, np.uint8).reshape(-1, 180, 320).astype(np.int16)
    m, box = [0.0], [None]
    for i in range(1, len(fr)):
        d = np.abs(fr[i] - fr[i - 1]) > 18; d[:6] = False                 # ignore the menu-bar clock
        frac = float(d.mean()); m.append(round(frac, 5))
        if frac > .0006:
            ys, xs = np.nonzero(d); box.append([round(float(np.percentile(xs, 2)) / 320, 3), round(float(np.percentile(ys, 2)) / 180, 3),
                                                round(float(np.percentile(xs, 98)) / 320, 3), round(float(np.percentile(ys, 98)) / 180, 3)])
        else: box.append(None)
    A = dict(fps=fps, motion=m, box=box); json.dump(A, open(cp, 'w')); return A

def idle_spans(A, t0, t1, thr=.0015, min_len=1.2, bridge=.6):
    """[(a, b)] stretches inside t0..t1 where nothing meaningful moves (waiting, reading, a still mouse).
    Tiny blips shorter than `bridge` s (a blinking cursor, a spinner) don't break a still stretch."""
    fps = A['fps']; k0, k1 = int(t0 * fps), min(len(A['motion']) - 1, int(t1 * fps))
    still = [A['motion'][k] < thr for k in range(k0, k1 + 1)]
    gap = int(bridge * fps); i = 0
    while i < len(still):                                     # bridge short moving runs between still runs
        if not still[i]:
            j = i
            while j < len(still) and not still[j]: j += 1
            if j - i <= gap and i > 0 and j < len(still): still[i:j] = [True] * (j - i)
            i = j
        else: i += 1
    out, start = [], None
    for idx, st in enumerate(still + [False]):
        if st and start is None: start = idx
        if not st and start is not None:
            if (idx - start) / fps >= min_len: out.append((max(t0, (k0 + start) / fps), min(t1, (k0 + idx) / fps)))
            start = None
    return out

def action_box(A, t0, t1):
    """union of where the screen changed between t0 and t1 (0..1 coords), or None"""
    fps = A['fps']; bs = [b for b in A['box'][int(t0 * fps):int(t1 * fps) + 1] if b]
    if not bs: return None
    arr = np.array(bs); return [float(np.percentile(arr[:, 0], 10)), float(np.percentile(arr[:, 1], 10)), float(np.percentile(arr[:, 2], 90)), float(np.percentile(arr[:, 3], 90))]

def activity_summary(A, dur):
    lines, t = [], 0.0
    idle = idle_spans(A, 0, dur, min_len=2.0)
    for a, b in idle + [(dur, dur)]:
        if a - t > .5:
            bx = action_box(A, t, a); where = ''
            if bx: where = f' · action around x {bx[0]:.2f}-{bx[2]:.2f}, y {bx[1]:.2f}-{bx[3]:.2f}'
            lines.append(f'- [{tc(t)} - {tc(a)}] activity{where}')
        if b > a: lines.append(f'- [{tc(a)} - {tc(b)}] idle ({b - a:.0f} s: waiting / nothing moving)')
        t = b
    return lines

def peek(project, clip, n=16):
    """contact sheet of a raw clip with timestamps, so Claude can see what happens when"""
    from PIL import Image, ImageDraw
    src = os.path.join(project, 'raw', clip); d = probe(src)['duration']; tmpd = tempfile.mkdtemp(); ims = []
    for k in range(n):
        t = d * (k + .5) / n; p = os.path.join(tmpd, f'{k}.jpg'); run(['-ss', str(t), '-i', src, '-frames:v', '1', '-vf', 'scale=640:-2', p])
        im = Image.open(p); dr = ImageDraw.Draw(im); dr.rectangle((0, 0, 92, 26), fill='black'); dr.text((6, 6), tc(t), fill='yellow'); ims.append(im)
    cols = 4; w, h = ims[0].size; S = Image.new('RGB', (w * cols, h * math.ceil(n / cols)))
    for k, im in enumerate(ims): S.paste(im, ((k % cols) * w, (k // cols) * h))
    out = os.path.join(project, 'work', f'peek_{clip}.jpg'); S.save(out, quality=85); print(out); return out


def vo_words(project, vo):
    cp = os.path.join(project, 'work', 'transcripts', '__voiceover__' + os.path.basename(vo) + '.json')
    if not os.path.exists(cp):
        os.makedirs(os.path.dirname(cp), exist_ok=True); print('transcribing the voiceover ...', flush=True); json.dump(transcribe(vo), open(cp, 'w'))
    return json.load(open(cp))['words']

def find_phrase(words, phrase, after=0.0):
    norm = lambda x: re.sub(r'[^a-z0-9]', '', x.lower())
    target = [norm(x) for x in phrase.split() if norm(x)]
    ws = [norm(w['w']) for w in words]
    for i in range(len(ws)):
        if words[i]['s'] + .01 < after: continue
        if ws[i:i + len(target)] == target: return words[i]['s']
    joined = ''.join(target)                                    # tolerate split/merged words ("safe cracker")
    for i in range(len(ws)):
        if words[i]['s'] + .01 < after: continue
        acc = ''
        for j in range(i, min(len(ws), i + len(target) + 3)):
            acc += ws[j]
            if acc == joined: return words[i]['s']
            if not joined.startswith(acc): break
    raise SystemExit(f'phrase not found in the voiceover: "{phrase}"')

def expand(project, segs, clips):
    """turn segments into pieces: idle stretches inside a segment are sped up (idle: "speed") or removed (idle: "cut")"""
    pieces = []
    for i, seg in enumerate(segs):
        base = dict(seg, _seg=i, speed=seg.get('speed', 1.0))
        mode = seg.get('idle')
        if not mode:
            pieces.append(base); continue
        A = activity(project, seg['clip']); spans = idle_spans(A, seg['in'], seg['out'], min_len=seg.get('idle_min', 1.2)); t = seg['in']
        for a, b in spans + [(seg['out'], seg['out'])]:
            if a - t > .25: pieces.append(dict(base, **{'in': round(t, 3), 'out': round(a, 3)}))
            if b - a > .05 and mode == 'speed': pieces.append(dict(base, **{'in': round(a, 3), 'out': round(b, 3), 'speed': base['speed'] * seg.get('idle_speed', 8), 'zoom': seg['zoom'] if isinstance(seg.get('zoom'), (int, float)) else 1.0, '_idle': True}))
            t = b
    return pieces

def zoom_filter(Z, zx, zy, D, W, H):
    """ease into a zoom of Z on (zx, zy) (0..1 of the frame) and back out before the piece ends"""
    if Z <= 1.01: return ''
    e = f"(1-pow(1-min(min(t/0.7,1),max((({D:.3f})-t)/0.6,0)),3))"
    zf = f"(1+{Z - 1:.3f}*{e})"
    return (f",scale=w='trunc({W}*{zf}/2)*2':h='trunc({H}*{zf}/2)*2':eval=frame,"
            f"crop={W}:{H}:x='max(0,min(iw-{W},{zx:.3f}*iw-{W}/2))':y='max(0,min(ih-{H},{zy:.3f}*ih-{H}/2))'")


def assemble_vo(project, vo, gaps, work):
    """insert silences into the voiceover at the given times, so the picture gets the time it needs"""
    out = os.path.join(work, 'voiceover_paced.wav'); gaps = sorted(gaps); n = len(gaps) + 1
    fc = [f"[0:a]aresample=48000,aformat=channel_layouts=stereo,asplit={n}" + ''.join(f'[i{k}]' for k in range(n))]
    labels, t = [], 0.0
    for k, (gt, g) in enumerate(gaps):
        fc.append(f'[i{k}]atrim={t:.3f}:{gt:.3f},asetpts=PTS-STARTPTS[a{k}]'); fc.append(f'anullsrc=r=48000:cl=stereo,atrim=0:{g:.3f}[s{k}]')
        labels += [f'[a{k}]', f'[s{k}]']; t = gt
    fc.append(f'[i{n - 1}]atrim=start={t:.3f},asetpts=PTS-STARTPTS[a{n - 1}]'); labels.append(f'[a{n - 1}]')
    run(['-i', vo, '-filter_complex', ';'.join(fc) + ';' + ''.join(labels) + f'concat=n={len(labels)}:v=0:a=1[o]', '-map', '[o]', out]); return out


def render(project, edit_path):
    E = json.load(open(edit_path)); name = E.get('name', os.path.splitext(os.path.basename(edit_path))[0].replace('.tight', ''))
    clips = {c['file']: c for c in json.load(open(os.path.join(project, 'work', 'clips.json')))}
    vertical = E.get('format', '16:9') == '9:16'; W, H = (1080, 1920) if vertical else (1920, 1080); fps = E.get('fps', 30)
    work = os.path.join(project, 'work', 'render_' + name); os.makedirs(work, exist_ok=True)
    for f in glob.glob(os.path.join(work, 'seg_*.mp4')): os.remove(f)
    punch = E.get('punch_in', 'auto'); words_out, t_out, parts = [], 0.0, []
    segs = E['segments']; pieces = expand(project, segs, clips)
    for p in pieces: p['_dur'] = (p['out'] - p['in']) / p['speed']
    # ---- voiceover mode: every segment with "at" starts when that phrase is said; the footage until the next "at" is
    #      sped up or slowed down to fill exactly that stretch of the voiceover
    VO = E.get('voiceover'); vo_path = None
    if VO:
        vo_path = VO['file'] if os.path.isabs(VO['file']) else os.path.join(project, VO['file'])
        vw = vo_words(project, vo_path); vo_len = probe(vo_path)['duration']
        ats, last = [], 0.0
        for i, seg in enumerate(segs):
            if i == 0: ats.append((0, 0.0)); continue
            if 'at' in seg:
                t = seg['at'] if isinstance(seg['at'], (int, float)) else find_phrase(vw, seg['at'], last) - VO.get('lead', .25)
                ats.append((i, max(last, t))); last = t
        bounds = ats + [(len(segs), vo_len + VO.get('tail', .6))]
        gaps = []                                              # (vo time, seconds of silence to insert there)
        for (si, t0), (sj, t1) in zip(bounds, bounds[1:]):
            group = [p for p in pieces if si <= p['_seg'] < sj]
            if not group: continue
            T = max(.3, t1 - t0); nat = lambda ps: sum(p['_dur'] for p in ps)
            lock = [p for p in group if segs[p['_seg']].get('play')]               # plays at normal speed (a reveal, a result)
            idle = [p for p in group if p.get('_idle') and p not in lock]
            busy = [p for p in group if p not in lock and p not in idle]
            excess = nat(group) - T
            if excess < 0:                                      # footage shorter than the voice: slow the busy parts a little, then hold
                for p in busy:
                    k = max(.6, nat(busy) / max(.01, nat(busy) - excess)) if busy else 1
                    p['speed'] *= k; p['_dur'] /= k
                if nat(group) < T - .05 and group: group[-1]['_hold'] = T - nat(group)
                continue
            # 1) squeeze the waiting (up to 60x)
            ni = nat(idle); cap_i = sum(p['out'] - p['in'] for p in idle) / 60
            if ni > 0:
                new_ni = max(cap_i, ni - excess); g = ni / new_ni
                for p in idle: p['speed'] *= g; p['_dur'] /= g
                excess -= ni - new_ni
            # 2) speed up the readable parts, but only up to max_speed (default 3x)
            if excess > .02 and busy:
                nb = nat(busy); maxs = VO.get('max_speed', 3.0)
                cap_b = sum((p['out'] - p['in']) / max(maxs, segs[p['_seg']].get('max_speed', maxs)) for p in busy)
                new_nb = max(cap_b, nb - excess); g = nb / new_nb
                for p in busy: p['speed'] *= g; p['_dur'] /= g
                excess -= nb - new_nb
            # 3) whatever is still too long: the voice pauses at the end of this stretch
            if excess > .05: gaps.append((t1 - VO.get('tail', .6) if sj == len(segs) else t1, round(excess, 3)))
        vo_path = assemble_vo(project, vo_path, gaps, work) if gaps else vo_path
        shift = lambda t: t + sum(g for (gt, g) in gaps if t >= gt - .01)
        vw = [dict(w, s=round(shift(w['s']), 3), e=round(shift(w['e']), 3)) for w in vw]
        if gaps: print('voice pauses added:', ', '.join(f'{g:.1f}s at {tc(t)}' for t, g in gaps))
        words_out = [dict(w) for w in vw]
    for i, p in enumerate(pieces):
        seg = p; info = clips[seg['clip']]; src = os.path.join(project, 'raw', seg['clip'])
        dur = round(seg['out'] - seg['in'], 3); speed = max(.05, seg['speed']); odur = round(dur / speed, 3)
        if odur <= .04 and not seg.get('_hold'): continue
        screen = E.get('screen') or seg.get('screen')
        z = seg.get('zoom', (1.0 if seg['_seg'] % 2 == 0 else 1.12) if punch == 'auto' and not seg.get('broll') and not screen else 1.0)
        Z, zx, zy = 1.0, .5, .5
        if z == 'auto':                                         # zoom into where the action is
            bx = action_box(activity(project, seg['clip']), seg['in'], seg['out']); z = 1.0
            if bx and not seg.get('_idle'):
                bw, bh = max(.05, bx[2] - bx[0]), max(.05, bx[3] - bx[1])
                Z = max(1.0, min(seg.get('max_zoom', 2.0), .8 / max(bw, bh * (W / H) / (16 / 9))))
                zx, zy = (bx[0] + bx[2]) / 2, (bx[1] + bx[3]) / 2
                if Z < 1.15: Z = 1.0
        fx = seg.get('fx') or (face_x(src, seg['in'], seg['out'], info['width'], info['height']) if vertical else .5)
        hold = seg.get('_hold', 0)
        vf = seg_filter(seg, info, W, H, z, vertical, fx) + f',setpts=(PTS-STARTPTS)/{speed:.4f}' + zoom_filter(Z, zx, zy, odur, W, H) + f',fps={fps},format=yuv420p'
        if hold > .02: vf += f',tpad=stop_mode=clone:stop_duration={hold:.3f}'; odur = round(odur + hold, 3)
        out = os.path.join(work, f'seg_{i:04d}.mp4')
        silent = VO or not info['audio'] or seg.get('mute') or abs(speed - 1) > .01
        a_in = ['-f', 'lavfi', '-t', str(odur), '-i', 'anullsrc=r=48000:cl=stereo'] if silent else []
        af = f'aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.02,afade=t=out:st={max(0, dur - .03):.3f}:d=0.03'
        if seg.get('gain'): af += f",volume={seg['gain']}dB"
        args = ['-ss', str(seg['in']), '-t', str(dur), '-i', src] + a_in + ['-vf', vf]
        args += (['-map', '0:v', '-map', '1:a'] if a_in else ['-af', af])
        args += ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', str(odur), out]
        run(args); parts.append(out)
        if not VO and not seg.get('broll') and not silent:
            try:
                first = True
                for w in load_words(project, seg['clip']):
                    if w['s'] >= seg['in'] - .02 and w['e'] <= seg['out'] + .05:
                        words_out.append(dict(w=w['w'], s=round(t_out + max(0, w['s'] - seg['in']), 3), e=round(t_out + w['e'] - seg['in'], 3), brk=first)); first = False
            except FileNotFoundError: pass
        t_out += odur
        print(f'  piece {i + 1}/{len(pieces)}  {seg["clip"]} {tc(seg["in"])}-{tc(seg["out"])}  x{speed:.2f}' + (f'  zoom {Z:.2f}' if Z > 1 else ''), flush=True)
    lst = os.path.join(work, 'list.txt'); open(lst, 'w').write(''.join(f"file '{p}'\n" for p in parts))
    base = os.path.join(work, 'base.mp4'); run(['-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', base])
    total = probe(base)['duration']
    # ---- final pass: blur, captions, titles, music with ducking, loudness
    vf, inputs, fc = [], ['-i', base], []
    v = '[0:v]'
    for k, b in enumerate(E.get('blur', [])):         # blur boxes: x, y, w, h in 0..1 of the frame, t0/t1 in output seconds
        x, y, w, h = int(b['x'] * W), int(b['y'] * H), int(b['w'] * W), int(b['h'] * H)
        fc.append(f"{v}split[bm{k}][bb{k}];[bb{k}]crop={w}:{h}:{x}:{y},boxblur=24:4[bl{k}];[bm{k}][bl{k}]overlay={x}:{y}:enable='between(t,{b.get('t0', 0)},{b.get('t1', 1e6)})'[bv{k}]")
        v = f'[bv{k}]'
    cap = E.get('captions', {'preset': 'short' if vertical else 'long'})
    if cap or E.get('texts'):
        ass = os.path.join(work, 'captions.ass'); captions_ass(words_out if cap else [], W, H, cap or {}, ass, E.get('texts', []))
        esc = (lambda x: x.replace('\\', '/').replace(':', '\\:')) if os.name == 'nt' else (lambda x: x)   # Windows drive letters
        fc.append(f"{v}ass='{esc(ass)}':fontsdir='{esc(FONTS)}'[vc]"); v = '[vc]'
    a = '[0:a]'; nin = 1
    if VO:
        inputs += ['-i', vo_path]; fc.append(f"[{nin}:a]aresample=48000,aformat=channel_layouts=stereo,apad,atrim=0:{total}[vo]"); a = '[vo]'; nin += 1
    mus = E.get('music')
    if mus:
        mp = mus['file'] if os.path.isabs(mus['file']) else os.path.join(project, mus['file'])
        inputs += ['-stream_loop', '-1', '-i', mp]
        vol = mus.get('volume_db', -16)
        fc.append(f"[{nin}:a]aresample=48000,aformat=channel_layouts=stereo,volume={vol}dB,atrim=0:{total},afade=t=in:d=1.5,afade=t=out:st={max(0, total - 3):.2f}:d=3[mraw]")
        fc.append(f"{a}asplit[voice][key];[mraw][key]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=350[mduck];[voice][mduck]amix=inputs=2:duration=first:normalize=0[amix]")
        a = '[amix]'
    # loudness: measure, then apply (two-pass) so the result sits at -14 LUFS like YouTube expects
    tmp = os.path.join(work, 'premix.mkv')
    run(inputs + (['-filter_complex', ';'.join(fc)] if fc else []) + ['-map', v if v != '[0:v]' else '0:v', '-map', a if a != '[0:a]' else '0:a',
        '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'pcm_s16le', tmp])
    m = subprocess.run([FF, '-hide_banner', '-i', tmp, '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json', '-f', 'null', '-'], capture_output=True, text=True).stderr
    j = json.loads(m[m.rfind('{'):m.rfind('}') + 1])
    ln = f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true"
    os.makedirs(os.path.join(project, 'out'), exist_ok=True); final = os.path.join(project, 'out', name + '.mp4')
    run(['-i', tmp, '-af', ln + ',aresample=48000', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', final])
    os.remove(tmp)
    json.dump(words_out, open(os.path.join(work, 'words_out.json'), 'w'))
    raw_len = sum(s_['out'] - s_['in'] for s_ in segs)
    print(f'wrote {final}  ({tc(total)} from {tc(raw_len)} of chosen footage, {len(parts)} pieces)')
    return final

def sheet(video, n=12):
    from PIL import Image, ImageDraw
    d = probe(video)['duration']; tmpd = tempfile.mkdtemp(); ims = []
    for k in range(n):
        t = d * (k + .5) / n; p = os.path.join(tmpd, f'{k}.jpg'); run(['-ss', str(t), '-i', video, '-frames:v', '1', '-vf', 'scale=480:-2', p])
        im = Image.open(p); ImageDraw.Draw(im).text((8, 8), tc(t), fill='yellow'); ims.append(im)
    cols = 4; w, h = ims[0].size; S = Image.new('RGB', (w * cols, h * math.ceil(n / cols)))
    for k, im in enumerate(ims): S.paste(im, ((k % cols) * w, (k // cols) * h))
    out = os.path.splitext(video)[0] + '_sheet.jpg'; S.save(out, quality=85); print(out); return out


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    cmd = a[0]
    a = [a[0]] + [os.path.abspath(x) if os.path.exists(x) else x for x in a[1:]]
    if cmd == 'scan': scan(a[1], *(a[2:3] or []))
    elif cmd == 'tighten': tighten(a[1], a[2], *[float(x) for x in a[3:4]])
    elif cmd == 'retakes': retakes(a[1])
    elif cmd == 'beats': beats(a[1])
    elif cmd == 'render': render(a[1], a[2])
    elif cmd == 'peek': peek(a[1], a[2], int(a[3]) if len(a) > 3 else 16)
    elif cmd == 'sheet': sheet(a[1], int(a[2]) if len(a) > 2 else 12)
    else: print(__doc__)
