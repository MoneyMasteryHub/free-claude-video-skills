"""Clipper: finds the best moments in a long stream or gameplay video and turns them into vertical clips
with the facecam on top, the game underneath, word-by-word captions, a hook line and a viral score.
Built on the Footage Editor engine (fe.py), which does the captions, cutting and loudness.

  python3 sc.py fetch   <project> <url> [from-to]       download a stream or VOD (or only part: "1:02:00-1:20:00") at 720p + its chat
                                                        replay. Works on streams that are still live. [--1080] [--no-chat]
  python3 sc.py cleanup <project>                       delete the downloaded stream after the clips are done (frees GBs)
  python3 sc.py cam     <project> [x y w h]             find the facecam box (or set it by hand, 0..1 of the frame) + a check image
  python3 sc.py signals <project>                       loudness, facecam reactions and game action over the whole stream
  python3 sc.py moments <project> [n] [--full]          rank the top moments, transcribe them, write moments.md + a frame strip each
  python3 sc.py peek    <project> <from> <to> [n]       frames of any stretch with timestamps (seconds or h:mm:ss)
  python3 sc.py render  <project> <clips.json> [name]   lay out, caption, level and score every clip (or one) -> <project>/out/
  python3 sc.py score   <project> <clips.json>          the viral score report alone (out/scores.md)
  python3 sc.py captions best|light                     Best = most accurate captions (1.6 GB model, once); Light = no extra download
Times in clips.json are seconds in the stream (moments.md prints both h:mm:ss and seconds)."""
import os, sys, json, re, math, glob, shutil, subprocess, tempfile, time
os.environ.setdefault('OPENCV_LOG_LEVEL', 'ERROR')
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fe, detect

FF = fe.FF
W, H = 1080, 1920
CAM_H = 690                       # stack layout: facecam panel height; the game fills the rest
HYPE = {'no', 'way', 'what', 'bro', 'bruh', 'yo', 'yoo', 'yooo', 'oh', 'god', 'lets', "let's", 'go', 'wtf', 'holy', 'dude', 'nah',
        'help', 'run', 'chat', 'clip', 'insane', 'crazy', 'wasted', 'busted', 'cops', 'police', 'wanted', 'stars', 'ha', 'haha',
        'hahaha', 'lol', 'omg', 'wait', 'stop', 'why', 'how', 'yes', 'dead', 'die', 'jump', 'crash', 'boom', 'damn', 'sheesh'}
EXCLAIM = re.compile(r"(no way|oh my god|oh my gosh|let'?s go+|clip (it|that)|what the|bro what|are you serious|ha ?ha|laugh)", re.I)


def T(t):
    """seconds -> h:mm:ss.s"""
    t = round(max(0, t), 1); return f'{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:04.1f}'

def secs(x):
    if isinstance(x, (int, float)): return float(x)
    p = [float(v) for v in str(x).split(':')]; s = 0.0
    for v in p: s = s * 60 + v
    return s

def stream(project):
    raw = os.path.join(project, 'raw')
    fs = [f for f in os.listdir(raw) if f.lower().endswith(fe.VIDEO_EXT)] if os.path.isdir(raw) else []
    if not fs: raise SystemExit(f'no video in {raw}: put the stream file there first')
    return max(fs, key=lambda f: os.path.getsize(os.path.join(raw, f)))     # the longest file is the stream

def W_(project, *p): return os.path.join(project, 'work', *p)

def info_of(project, clip):
    cp = W_(project, 'info.json'); d = json.load(open(cp)) if os.path.exists(cp) else {}
    if clip not in d:
        d[clip] = fe.probe(os.path.join(project, 'raw', clip)); os.makedirs(os.path.dirname(cp), exist_ok=True); json.dump(d, open(cp, 'w'))
    return d[clip]


# ------------------------------------------------------------------ fetch (only streams you have permission to clip)
def _ytdlp_json(url, extra=()):
    r = subprocess.run([sys.executable, '-m', 'yt_dlp', '-J', '--no-warnings', '--no-playlist', *extra, url], capture_output=True, text=True, timeout=120)
    return json.loads(r.stdout) if r.returncode == 0 and r.stdout.strip() else None

def resolve(url):
    """the downloadable address for a link. A Twitch channel link (live or not) becomes its newest saved broadcast;
    Twitch saves a broadcast WHILE it's live, so any past part of a live stream can be downloaded right away."""
    m = re.match(r'https?://(www\.|m\.)?twitch\.tv/([A-Za-z0-9_]+)/?(\?.*)?$', url.strip())
    if m and m.group(2).lower() not in ('videos', 'directory'):
        r = subprocess.run([sys.executable, '-m', 'yt_dlp', '--no-warnings', '--flat-playlist', '-I', '1', '--print', '%(id)s',
                            f'https://www.twitch.tv/{m.group(2)}/videos?filter=archives&sort=time'], capture_output=True, text=True, timeout=120)
        vid = r.stdout.strip().splitlines()[:1]
        if vid:
            v = vid[0].lstrip('v'); print(f'using the saved broadcast twitch.tv/videos/{v} (includes the live stream so far)')
            return f'https://www.twitch.tv/videos/{v}', 'twitch', v
    m = re.search(r'twitch\.tv/videos/(\d+)', url)
    if m: return url, 'twitch', m.group(1)
    if 'youtube.com' in url or 'youtu.be' in url: return url, 'youtube', None
    return url, 'other', None

def fetch(project, url, section=None, height=720, chat=True):
    """download a stream (or only a part: "1:00:00-1:30:00") at 720p, plus its chat replay when the site keeps one.
    Works on streams that are still live: past parts come from the saved broadcast, not by waiting in real time."""
    raw = os.path.join(project, 'raw'); os.makedirs(raw, exist_ok=True); os.makedirs(W_(project), exist_ok=True)
    src, site, vid = resolve(url)
    args = [sys.executable, '-m', 'yt_dlp', '--no-warnings', '--no-playlist', '-f', f'bv*[height<={height}]+ba/b[height<={height}]/b',
            '--merge-output-format', 'mp4', '--ffmpeg-location', FF, '-o', os.path.join(raw, 'stream.%(ext)s')]
    live = False; info = None
    if site == 'youtube':
        info = _ytdlp_json(src); live = bool(info and info.get('is_live'))
        if live: args += ['--live-from-start']                    # rewind a live YouTube stream instead of waiting
    t0 = 0.0
    if section:
        a, b_ = section.split('-'); t0 = secs(a); args += ['--download-sections', f'*{a}-{b_}']     # cuts on keyframes: fast, no re-encode
    elif live:
        raise SystemExit('This YouTube stream is still live. Give a part to download ("1:00:00-1:30:00") or use live mode in Clipper Pro.')
    print(f'downloading {"part " + section if section else "the whole stream"} at {height}p ...', flush=True)
    before = set(os.listdir(raw))
    r = subprocess.run(args + [src])
    if r.returncode: raise SystemExit('download failed (is the link public? is the part inside the stream?)')
    new = sorted(set(os.listdir(raw)) - before) or ['stream.mp4']
    who, votes, dur = None, [], fe.probe(os.path.join(raw, new[0]))['duration']
    json.dump(dict(url=url, source=src, site=site, section=section, start=t0, files=new, streamer=who), open(W_(project, 'downloaded.json'), 'w'), indent=1)
    print('downloaded:', ', '.join(new))


def cleanup(project):
    """delete the downloaded stream (the clips in out/ are kept); only files this tool downloaded"""
    d = W_(project, 'downloaded.json')
    if not os.path.exists(d): raise SystemExit('nothing was downloaded by Clipper here; the stream file is yours, so it stays')
    freed = 0
    for f in json.load(open(d))['files']:
        pth = os.path.join(project, 'raw', f)
        if os.path.exists(pth): freed += os.path.getsize(pth); os.remove(pth)
    print(f'deleted the downloaded stream ({freed / 1e9:.1f} GB freed). Clips are in {os.path.join(project, "out")}')


# ------------------------------------------------------------------ facecam box
def frames_at(path, times, width=960):
    import cv2
    cap = cv2.VideoCapture(path); out = []
    for t in times:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000); ok, fr = cap.read()
        if ok: out.append(cv2.resize(fr, (width, int(width * fr.shape[0] / fr.shape[1]))))
    cap.release(); return out

def find_cam(project, manual=None):
    """facecam overlay: where a face keeps showing up in the same small spot, grown outwards over the still 'room' pixels
    until it reaches the moving game. Returns [x, y, w, h] in 0..1, or None when there is no facecam."""
    import cv2
    clip = stream(project); src = os.path.join(project, 'raw', clip); d = info_of(project, clip)['duration']
    os.makedirs(W_(project), exist_ok=True); cp = W_(project, 'cam.json')
    if manual:
        box = [float(v) for v in manual]; json.dump(dict(box=box, how='set by hand'), open(cp, 'w')); cam_check(project, box); return box
    times = [d * (.03 + .94 * k / 47) for k in range(48)]
    frs = frames_at(src, times)
    box = cam_from_frames(frs)
    json.dump(dict(box=box, how='auto', frames=len(frs)), open(cp, 'w'))
    cam_check(project, box)
    print('facecam:', box if box else 'none found (the clips will use the game-only layout)', '->', W_(project, 'cam_check.jpg'))
    return box

def face_finder():
    """faces in a BGR frame -> [(x, y, w, h)]. YuNet (OpenCV 4.5.4+ and 5.x), falling back to the Haar cascade (OpenCV 4)"""
    import cv2
    m = os.path.join(fe.ROOT, 'assets', 'models')
    try:
        det = cv2.FaceDetectorYN.create(os.path.join(m, 'face_detection_yunet_2023mar.onnx'), '', (320, 320), .7, .3, 50)
        def find(fr):
            det.setInputSize((fr.shape[1], fr.shape[0])); _, f = det.detect(fr)
            return [tuple(int(v) for v in r[:4]) for r in f] if f is not None else []
        return find
    except Exception:
        cas = cv2.CascadeClassifier(os.path.join(m, 'haarcascade_frontalface_default.xml'))
        return lambda fr: [tuple(r) for r in cas.detectMultiScale(cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY), 1.1, 6, minSize=(28, 28))]

def cam_from_frames(frs):
    import cv2
    find = face_finder()
    fh, fw = frs[0].shape[:2]; faces = []
    for fr in frs:
        faces += [(x + w / 2, y + h / 2, w, h) for x, y, w, h in find(fr) if w >= 20]
    box = None
    if faces:
        F = np.array(faces, float); best, bestn = None, 0
        for c in F:                                            # the spot with the most faces (within ~6% of the frame)
            n = int(np.sum((np.abs(F[:, 0] - c[0]) < fw * .06) & (np.abs(F[:, 1] - c[1]) < fh * .06)))
            if n > bestn: best, bestn = c, n
        sel = F[(np.abs(F[:, 0] - best[0]) < fw * .06) & (np.abs(F[:, 1] - best[1]) < fh * .06)]
        fx, fy, sw, sh = np.median(sel, axis=0)
        if bestn >= len(frs) * .3 and sw < fw * .3:            # a face in a fixed, small spot = a facecam overlay
            G = np.array([cv2.cvtColor(f, cv2.COLOR_BGR2GRAY) for f in frs], np.float32); sd = cv2.blur(G.std(axis=0), (5, 5))
            game = float(np.median(sd)); lim = max(10.0, game * .5)
            still = (sd < lim).astype(np.uint8)
            near = np.zeros_like(still)                          # the streamer's head and body move, so count that area in
            for x_, y_, w_, h_ in sel: cv2.rectangle(near, (int(x_ - w_ * 1.6), int(y_ - h_ * 1.2)), (int(x_ + w_ * 1.6), int(y_ + h_ * 2.5)), 1, -1)
            m = cv2.morphologyEx(np.maximum(still, near), cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
            _, lab = cv2.connectedComponents(m)
            k = lab[int(min(fh - 1, fy)), int(min(fw - 1, fx))]
            comp = (lab == k) if k else near.astype(bool)
            ys, xs = np.nonzero(comp); x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
            def run(fill):                                       # the longest stretch that's mostly cam (trims thin leaks)
                good = fill > .45; best, cur, bs = (0, 0), 0, 0
                for i, g in enumerate(list(good) + [False]):
                    if g: cur += 1
                    else:
                        if cur > best[1] - best[0]: best = (i - cur, i)
                        cur = 0
                return best
            for _ in range(2):
                sub = comp[y0:y1, x0:x1]
                c0, c1 = run(sub.mean(axis=0)); x0, x1 = x0 + c0, x0 + c1
                sub = comp[y0:y1, x0:x1]
                r0, r1 = run(sub.mean(axis=1)); y0, y1 = y0 + r0, y0 + r1
            x0, x1, y0, y1 = float(x0), float(x1), float(y0), float(y1)
            # snap each side to the overlay's border: the strongest straight edge between the face and the box side
            med = np.median(G, axis=0); gx_ = np.abs(cv2.Sobel(med, cv2.CV_32F, 1, 0, ksize=3)); gy_ = np.abs(cv2.Sobel(med, cv2.CV_32F, 0, 1, ksize=3))
            fx0, fx1 = np.min(sel[:, 0] - sel[:, 2] / 2), np.max(sel[:, 0] + sel[:, 2] / 2)
            fy0, fy1 = np.min(sel[:, 1] - sel[:, 3] / 2), np.max(sel[:, 1] + sel[:, 3] / 2)
            def snap_side(lo, hi, horiz, a, b, pad):
                lo, hi = int(max(0, lo - pad)), int(min((fh if horiz else fw) - 1, hi + pad))
                if hi - lo < 3: return None
                if horiz: prof = np.array([gy_[r, int(a):int(b)].mean() for r in range(lo, hi + 1)])
                else: prof = np.array([gx_[int(a):int(b), c].mean() for c in range(lo, hi + 1)])
                k = int(np.argmax(prof))
                return lo + k if prof[k] > 3 * np.median(prof) + 4 else None
            pad = 6
            r = snap_side(fy1 + sh * .3, y1, True, x0, x1, pad); y1 = float(r) if r is not None else y1
            r = snap_side(y0, fy0 - sh * .1, True, x0, x1, pad); y0 = float(r) if r is not None else y0
            r = snap_side(x0, fx0 - sw * .2, False, y0, y1, pad); x0 = float(r) if r is not None else x0
            r = snap_side(fx1 + sw * .2, x1, False, y0, y1, pad); x1 = float(r) if r is not None else x1
            snap = lambda v, m: 0 if v < m * .006 else (m if v > m * .994 else v)      # overlays usually sit flush to an edge
            x0, x1, y0, y1 = snap(x0, fw), snap(x1, fw), snap(y0, fh), snap(y1, fh)
            box = [round(float(x0 / fw), 3), round(float(y0 / fh), 3), round(float((x1 - x0) / fw), 3), round(float((y1 - y0) / fh), 3)]
            if box[2] * box[3] > .45: box = None                  # that's a full-screen camera, not an overlay
    if box and (box[3] > .62 or box[2] * box[3] > .36): return None   # that's the whole picture (IRL / camera-only stream), not a facecam overlay
    return box

def cam_check(project, box):
    """4 frames with the facecam box drawn on, so Claude can check it"""
    import cv2
    clip = stream(project); d = info_of(project, clip)['duration']
    frs = frames_at(os.path.join(project, 'raw', clip), [d * k for k in (.15, .4, .65, .9)], 640)
    for fr in frs:
        if box:
            h, w = fr.shape[:2]; cv2.rectangle(fr, (int(box[0] * w), int(box[1] * h)), (int((box[0] + box[2]) * w), int((box[1] + box[3]) * h)), (0, 255, 255), 3)
    top = np.hstack(frs[:2]); bot = np.hstack(frs[2:4]) if len(frs) >= 4 else np.zeros_like(top)
    cv2.imwrite(W_(project, 'cam_check.jpg'), np.vstack([top, bot]))

def cam_box(project):
    cp = W_(project, 'cam.json')
    if not os.path.exists(cp): return find_cam(project)
    return json.load(open(cp))['box']


# ------------------------------------------------------------------ signals over the whole stream (1 value per second)
def rolling_median(x, win=121):
    pad = win // 2; xp = np.pad(x, pad, mode='edge')
    from numpy.lib.stride_tricks import sliding_window_view
    return np.median(sliding_window_view(xp, win), axis=1)[:len(x)]

def zscore(x, win=121):
    base = rolling_median(x, win); r = x - base; mad = np.median(np.abs(r - np.median(r))) * 1.4826 + 1e-6
    return r / mad

def signals(project):
    clip = stream(project); src = os.path.join(project, 'raw', clip); inf = info_of(project, clip); dur = inf['duration']; n = int(math.ceil(dur))
    box = cam_box(project)
    print(f'reading the sound of {clip} ({T(dur)}) ...', flush=True)
    p = subprocess.Popen([FF, '-v', 'error', '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], stdout=subprocess.PIPE)
    q = 4000; db = []; ev = {k: [] for k in ('laugh', 'scream', 'cheer', 'speech', 'music')}   # 0.25 s loudness blocks; sound events per second
    while True:
        b = p.stdout.read(q * 2 * 240)                           # one minute at a time
        if not b: break
        a = np.frombuffer(b[:len(b) // 2 * 2], np.int16).astype(np.float32) / 32768
        for k in range(0, len(a) - q + 1, q): db.append(20 * math.log10(float(np.sqrt(np.mean(a[k:k + q] ** 2))) + 1e-5))
        e = detect.audio_events(a)
        for k in ev: ev[k] += e[k][:max(1, int(len(a) // 16000))].tolist()
    p.wait(); db = np.array(db + [-100.0] * 4)
    ev = {k: np.pad(np.array(v[:n], float), (0, max(0, n - len(v)))) for k, v in ev.items()}
    print(f'heard laughing in {int((ev["laugh"] > .3).sum())} s, screaming/shouting in {int((ev["scream"] > .3).sum())} s', flush=True)
    loud = np.array([np.percentile(db[i * 4:i * 4 + 4], 90) if i * 4 < len(db) else -100 for i in range(n)])
    fps = 2 if dur < 5400 else 1; gw, gh = 192, 108
    print(f'reading the picture ({fps} frame/s; a long stream takes a while) ...', flush=True)
    p = subprocess.Popen([FF, '-v', 'error', '-i', src, '-an', '-vf', f'fps={fps},scale={gw}:{gh},format=gray', '-f', 'rawvideo', '-'], stdout=subprocess.PIPE)
    camm = np.zeros((gh, gw), bool)
    if box: camm[int(box[1] * gh):int((box[1] + box[3]) * gh), int(box[0] * gw):int((box[0] + box[2]) * gw)] = True
    prev, gm, cm = None, [], []
    while True:
        b = p.stdout.read(gw * gh)
        if len(b) < gw * gh: break
        f = np.frombuffer(b, np.uint8).astype(np.int16)
        f = f.reshape(gh, gw)
        if prev is None: gm.append(0.0); cm.append(0.0)
        else:
            d = np.abs(f - prev) > 16
            gm.append(float(d[~camm].mean())); cm.append(float(d[camm].mean()) if box else 0.0)
        prev = f
    p.wait()
    per = lambda v: np.array([np.mean(v[int(i * fps):int(i * fps) + fps]) if int(i * fps) < len(v) else 0 for i in range(n)])
    game, cam = per(gm), per(cm)
    lz, cz, gz = zscore(loud), (zscore(cam) if box else np.zeros(n)), zscore(game)
    cut = np.r_[0, (np.diff(game) > .35).astype(float)]           # hard scene changes (deaths, cutscenes, menus)
    chat_z = np.zeros(n); cp = W_(project, 'chat.jsonl'); ahead = np.zeros(n); msgs = []
    if os.path.exists(cp):                                       # chat reacts a few seconds after the moment
        HY = re.compile(r"(clip|lmao+|lmfao|lol+|kek|omegalul|lul|💀|😂|🤣|😭|\bw+\b|no way|oh my god|omg|wtf|holy|insane|crazy|!!+|^[A-Z !?]{6,}$)", re.I)
        cnt = np.zeros(n + 10)
        for line in open(cp, encoding='utf-8'):
            m = json.loads(line); msgs.append(m); k = int(m['t'])
            if 0 <= k < n + 10: cnt[k] += 1 + 2 * bool(HY.search(m.get('m', '')))
        ahead = np.array([cnt[i + 1:i + 7].sum() for i in range(n)])
        rp = W_(project, 'chat_rate.json')
        if os.path.exists(rp):                                   # sampled replay: messages/second with hype weighting
            R = json.load(open(rp))
            if len(R) > 5:
                rt = np.interp(np.arange(n + 10), [x['t'] for x in R], [x['r'] * (1 + 2 * x['h']) for x in R])
                ahead = np.array([rt[i + 1:i + 7].mean() for i in range(n)])
        chat_z = zscore(ahead)
        print(f'using chat replay ({int(cnt.sum())} weighted messages)')
    if chat_z.any():
        raw = .35 * np.clip(lz, 0, 8) + (.2 if box else 0) * np.clip(cz, 0, 8) + (.1 if box else .3) * np.clip(gz, 0, 8) + .35 * np.clip(chat_z, 0, 8)
    else:
        raw = .5 * np.clip(lz, 0, 8) + (.3 if box else 0) * np.clip(cz, 0, 8) + (.2 if box else .5) * np.clip(gz, 0, 8)
    old_score = np.convolve(raw, np.ones(3) / 3, 'same')
    who = streamer_of(project); B = dict(w=dict(detect.PRIOR), b=detect.PRIOR_B, positives=0); lift = {}; votes = []
    cf = detect.chat_features(msgs, n, lift) if msgs else {}
    rawf = dict(loud=loud, cam=cam if box else np.zeros(n), game=game, chat=ahead if msgs else np.zeros(n), cut=cut,
                **{k: v for k, v in ev.items() if k in ('laugh', 'scream', 'cheer')},
                **{k: v for k, v in cf.items() if k != 'chat'})
    X = detect.features(rawf); learned = detect.predict(B, X)
    norm = lambda v: v / max(1e-6, np.percentile(v, 99.5))
    alpha = .6 + .3 * min(1, B.get('positives', 0) / 150)               # trust the brain more the more it has learned
    score = (1 - alpha) * norm(old_score) + alpha * norm(np.convolve(learned, np.ones(3) / 3, 'same'))
    # "starting soon" / BRB / ad screens: nobody talking, music or silence, chat spamming. Never a clip.
    st = detect.show_start(ev['speech']) if ev['speech'].any() else 0
    if st is None: st = 0                                         # nobody talks in the whole stream (no-commentary): keep everything
    elif st > 0: print(f'the stream really starts at {T(st)} (before that: a waiting / starting soon screen, skipped)')
    if ev['speech'].any():
        quiet = (detect.talk_near(ev['speech']) < .5) & (detect.talk_near(ev['laugh']) < .4) & (detect.talk_near(ev['scream']) < .4)
        score = np.where(quiet, score * .3, score)
    score[:st] = 0
    S = dict(clip=clip, duration=dur, cam=box, streamer=who, show_start=st, loud_db=np.round(loud, 1).tolist(), loud_z=np.round(lz, 2).tolist(),
             cam_z=np.round(cz, 2).tolist(), game=np.round(game, 4).tolist(), game_z=np.round(gz, 2).tolist(),
             cuts=cut.tolist(), chat_z=np.round(chat_z, 2).tolist(), laugh=np.round(ev['laugh'], 2).tolist(), scream=np.round(ev['scream'], 2).tolist(),
             chat_laugh=np.round(cf.get('chat_laugh', np.zeros(n)), 2).tolist(), signal_score=np.round(score, 3).tolist())
    S['score'] = np.round(score, 3).tolist()
    np.save(W_(project, 'features.npy'), X.astype(np.float32))
    json.dump(S, open(W_(project, 'signals.json'), 'w'))
    print(f'signals ready: {n} seconds, usual loudness {np.median(loud):.0f} dB, peaks in the top 5%: {int(np.sum(score > np.percentile(score, 95)))} s')
    return S

def streamer_of(project):
    for f in ('streamer.txt',):
        p = W_(project, f)
        if os.path.exists(p): return open(p).read().strip() or 'unknown'
    d = W_(project, 'downloaded.json')
    if os.path.exists(d): return json.load(open(d)).get('streamer') or 'unknown'
    return 'unknown'

def load_votes(project, n=None): return []

def load_signals(project):
    p = W_(project, 'signals.json')
    return json.load(open(p)) if os.path.exists(p) else signals(project)


# ------------------------------------------------------------------ transcripts (only the parts that matter, unless --full)
_MODEL = {}
def transcribe_range(project, t0, t1, language=None):
    """transcribe t0..t1 of the stream and merge it into work/transcripts/<stream>.json (absolute times)"""
    clip = stream(project); src = os.path.join(project, 'raw', clip)
    tp = W_(project, 'transcripts', clip + '.json'); os.makedirs(os.path.dirname(tp), exist_ok=True)
    tr = json.load(open(tp)) if os.path.exists(tp) else dict(words=[], sentences=[], done=[])
    todo = [(t0, t1)]
    for a, b in tr.get('done', []):                                # skip what's already transcribed
        nt = []
        for x, y in todo:
            if b <= x or a >= y: nt.append((x, y)); continue
            if a > x: nt.append((x, a))
            if b < y: nt.append((b, y))
        todo = [(x, y) for x, y in nt if y - x > 1]
    if not todo: return tr
    from faster_whisper import WhisperModel
    if 'm' not in _MODEL: _MODEL['m'] = WhisperModel(os.environ.get('SC_MODEL', 'small'), device='cpu', compute_type='int8')
    m = _MODEL['m']
    for x, y in todo:
        raw = subprocess.run([FF, '-v', 'error', '-ss', str(x), '-t', str(y - x), '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True).stdout
        audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
        segs, _ = m.transcribe(audio, word_timestamps=True, vad_filter=True, language=language, beam_size=3)
        for s in segs:
            ws = [dict(w=w.word.strip(), s=round(x + w.start, 3), e=round(x + w.end, 3)) for w in (s.words or []) if w.word.strip()]
            tr['words'] += ws
            if ws: tr['sentences'].append(dict(s=ws[0]['s'], e=ws[-1]['e'], text=s.text.strip()))
        tr['done'].append([x, y])
    tr['words'].sort(key=lambda w: w['s']); tr['sentences'].sort(key=lambda s: s['s'])
    seen, ws = set(), []                                          # drop duplicates where windows overlapped
    for w in tr['words']:
        k = (round(w['s'], 1), w['w'])
        if k not in seen: seen.add(k); ws.append(w)
    tr['words'] = ws; json.dump(tr, open(tp, 'w')); return tr

SWEARS = re.compile(r"^(fuck\w*|shit\w*|bitch\w*|ass(hole)?|dick|cunt|motherfuck\w*|bullshit|damn)$", re.I)
HALLU = re.compile(r"(thanks? for watching|subscribe|like and share|see you in the next|subtitles by|amara\.org)", re.I)

def settings():
    p = os.path.join(detect.HOME, 'settings.json')
    try: return json.load(open(p))
    except Exception: return {}

def caption_model():
    """Best captions: large-v3-turbo (1.6 GB, once). Light: the same small model used for scanning (no extra download).
    Set with: python3 sc.py captions best|light"""
    if os.environ.get('SC_CAPTION_MODEL'): return os.environ['SC_CAPTION_MODEL']
    return 'small' if settings().get('captions', DEFAULT_CAPTIONS) == 'light' else 'large-v3-turbo'

DEFAULT_CAPTIONS = 'light'

def set_captions(mode):
    mode = 'light' if mode.lower().startswith('l') else 'best'
    os.makedirs(detect.HOME, exist_ok=True); d = settings(); d['captions'] = mode
    json.dump(d, open(os.path.join(detect.HOME, 'settings.json'), 'w'), indent=1)
    print('captions:', 'Light (small model, no extra download)' if mode == 'light' else 'Best (accurate model, ~1.6 GB downloaded once)')

def transcribe_exact(project, name, t0, t1, language=None, prompt=None):
    """caption-grade transcript of one clip: the large-v3-turbo model, beam search, no carry-over between sentences
    (that's where Whisper invents text), silence-hallucination guard, and words it isn't sure it heard are dropped."""
    cp = W_(project, 'transcripts_exact', f'{name}_{t0:.2f}_{t1:.2f}_{caption_model().replace("/", "-")}.json')
    if os.path.exists(cp): return json.load(open(cp))
    os.makedirs(os.path.dirname(cp), exist_ok=True)
    from faster_whisper import WhisperModel
    key = 'exact'
    if key not in _MODEL:
        cm = caption_model()
        if cm != 'small': print('loading the accurate caption model (first time downloads ~1.6 GB) ...', flush=True)
        _MODEL[key] = WhisperModel(cm, device='cpu', compute_type='int8')
    src = os.path.join(project, 'raw', stream(project)); pad = 1.0; a = max(0, t0 - pad)
    raw = subprocess.run([FF, '-v', 'error', '-ss', str(a), '-t', str(t1 - a + pad), '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True).stdout
    audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    segs, _ = _MODEL[key].transcribe(audio, word_timestamps=True, vad_filter=True, vad_parameters=dict(min_silence_duration_ms=300),
                                     beam_size=5, condition_on_previous_text=False, language=language,
                                     hallucination_silence_threshold=1.0, no_speech_threshold=.5,
                                     initial_prompt=prompt or 'Gaming livestream. The streamer talks to chat while playing.')
    words, dropped = [], []
    for sg in segs:
        if sg.no_speech_prob > .6 and sg.avg_logprob < -.8: dropped.append(sg.text.strip()); continue
        if HALLU.search(sg.text): dropped.append(sg.text.strip()); continue
        for w in sg.words or []:
            t = w.word.strip()
            if not t: continue
            if w.probability < .3: dropped.append(t); continue                       # not sure it was said: leave it out
            s_, e_ = a + w.start, a + w.end
            if e_ < t0 or s_ > t1: continue
            if words and (t[0] in "'’-" or words[-1]['w'].endswith('-')) and s_ - words[-1]['e'] < .3:   # y'all, low-key
                words[-1]['w'] += t; words[-1]['e'] = round(e_, 3); continue
            words.append(dict(w=t, s=round(s_, 3), e=round(e_, 3), p=round(w.probability, 2)))
    seen = set(); words = [w for w in words if not ((w['s'], w['w']) in seen or seen.add((w['s'], w['w'])))]   # no doubled words
    r = dict(words=words, dropped=dropped); json.dump(r, open(cp, 'w')); return r


def words_in(tr, t0, t1): return [w for w in tr['words'] if w['s'] >= t0 - .02 and w['e'] <= t1 + .05]

def hype_words(ws):
    norm = lambda x: re.sub(r"[^a-z']", '', x.lower())
    text = ' '.join(w['w'] for w in ws)
    return sum(1 for w in ws if norm(w['w']) in HYPE) + 3 * len(EXCLAIM.findall(text)) + text.count('!')


# ------------------------------------------------------------------ moments: the shortlist Claude chooses from
def moments(project, n=15, full=False):
    S = load_signals(project); clip = S['clip']; dur = S['duration']; sc = np.array(S['score']); N = len(sc)
    if full:
        print(f'transcribing the whole stream ({T(dur)}); about a quarter of real time ...', flush=True); transcribe_range(project, 0, dur)
    order = np.argsort(-sc); picked = []
    floor = np.percentile(sc, 70)
    for i in order:
        if len(picked) >= n: break
        if sc[i] < floor: break
        if i < 15 or i > N - 8: continue
        if all(abs(i - j) > 45 for j in picked): picked.append(int(i))
    if full:                                                      # talk-heavy streams: also add the most excited speech
        tr = transcribe_range(project, 0, dur); per = np.zeros(N)
        for w in tr['words']:
            if re.sub(r"[^a-z']", '', w['w'].lower()) in HYPE or '!' in w['w']: per[min(N - 1, int(w['s']))] += 1
        per = np.convolve(per, np.ones(10), 'same')
        for i in np.argsort(-per)[:n]:
            if per[i] >= 3 and all(abs(i - j) > 45 for j in picked): picked.append(int(i))
    picked.sort(); votes = load_votes(project, N)
    os.makedirs(W_(project, 'moments'), exist_ok=True)
    pct = lambda v: float(np.mean(sc <= v))
    md = [f'# Moments in {clip}  ({T(dur)})\n',
          'Each moment: a peak in the signals, the window around it, the words said there, and a strip of frames.',
          'Look at every strip before choosing. Times are h:mm:ss.s (seconds in brackets). Signal = how strong the peak is next to the strongest moment of this stream (100).',
          'Use the peak second of a moment as "peak" in clips.json.']
    md[-1] += '\n'
    out = []
    for k, i in enumerate(picked, 1):
        w0, w1 = max(0, i - 30), min(dur, i + 22)
        print(f'  moment {k}/{len(picked)} at {T(i)}: transcribing ...', flush=True)
        tr = transcribe_range(project, max(0, i - 45), min(dur, i + 30))
        ws = words_in(tr, max(0, i - 45), min(dur, i + 30))
        lz, cz, gz = S['loud_z'][i], S['cam_z'][i], S['game_z'][i]
        why = []
        win = slice(max(0, i - 3), min(N, i + 4))
        dbjump = max(S['loud_db'][win]) - float(np.median(S['loud_db'][max(0, i - 60):i + 1] or [0]))
        if dbjump > 4: why.append(f'sound jumps {dbjump:.0f} dB above the minute before')
        if S['cam'] and max(S['cam_z'][win]) > 3: why.append(f'streamer moves a lot on camera ({max(S["cam_z"][win]):.0f}x the usual movement)')
        if max(S['game_z'][win]) > 3: why.append('fast game action')
        if sum(S['cuts'][win]): why.append('sudden screen change (death, crash, cutscene or menu)')
        if S.get('chat_z') and max(S['chat_z'][win]) > 3: why.append(f'chat explodes ({max(S["chat_z"][win]):.0f}x the usual)')
        if S.get('laugh') and max(S['laugh'][win]) > .35: why.append('laughing')
        if S.get('scream') and max(S['scream'][win]) > .45: why.append('screaming / shouting')
        if S.get('chat_laugh') and max(S['chat_laugh'][win]) > .35: why.append(f'chat is laughing ({round(100 * max(S["chat_laugh"][win]))}% of messages)')
        hw = hype_words(words_in(tr, w0, w1))
        if hw >= 3: why.append(f'excited talk ({hw} hype words or exclamations)')
        strip = strip_img(project, w0, w1, os.path.join('work', 'moments', f'm{k:02d}.jpg'))
        m = dict(id=k, peak=i, w0=round(w0, 1), w1=round(w1, 1), signal=round(100 * sc[i] / max(1e-6, sc.max())), why=why, strip=strip)
        out.append(m)
        md.append(f'\n## Moment {k} · peak {T(i)} ({i}s) · signal {m["signal"]}/100')
        md.append(f'Window {T(w0)} - {T(w1)}  ({w0:.1f} - {w1:.1f})')
        md.append('Why: ' + ('; '.join(why) if why else 'a smaller bump in sound or motion'))
        md.append(f'Frames: {strip}')
        if os.path.exists(W_(project, 'chat.jsonl')):
            said = [json.loads(x) for x in open(W_(project, 'chat.jsonl'), encoding='utf-8')]
            said = [c['m'][:60] for c in said if i - 2 <= c['t'] < i + 10][:15]
            if said: md.append('Chat: ' + ' | '.join(said))
        if ws:
            for s in [s for s in tr['sentences'] if s['e'] >= i - 45 and s['s'] <= i + 30]:
                mark = '  <- peak' if s['s'] <= i <= s['e'] + 1 else ''
                md.append(f'- [{T(s["s"])} - {T(s["e"])}] ({s["s"]:.1f}) {s["text"]}{mark}')
        else: md.append('- (no speech here)')
    json.dump(out, open(W_(project, 'moments.json'), 'w'), indent=1)
    open(os.path.join(project, 'moments.md'), 'w', encoding='utf-8').write('\n'.join(md) + '\n')
    print(f'{len(out)} moments -> {os.path.join(project, "moments.md")}')
    return out

def strip_img(project, t0, t1, rel, n=8, width=360):
    from PIL import Image, ImageDraw
    src = os.path.join(project, 'raw', stream(project)); tmpd = tempfile.mkdtemp(); ims = []
    for k in range(n):
        t = t0 + (t1 - t0) * (k + .5) / n; pth = os.path.join(tmpd, f'{k}.jpg')
        fe.run(['-ss', f'{t:.2f}', '-i', src, '-frames:v', '1', '-vf', f'scale={width}:-2', pth])
        im = Image.open(pth); dr = ImageDraw.Draw(im); dr.rectangle((0, 0, 92, 22), fill='black'); dr.text((5, 5), T(t), fill='yellow'); ims.append(im)
    cols = 4; w, h = ims[0].size; S = Image.new('RGB', (w * cols, h * math.ceil(n / cols)))
    for k, im in enumerate(ims): S.paste(im, ((k % cols) * w, (k // cols) * h))
    out = os.path.join(project, rel); os.makedirs(os.path.dirname(out), exist_ok=True); S.save(out, quality=82); shutil.rmtree(tmpd, True)
    return out


# ------------------------------------------------------------------ layout: facecam on top, game underneath (9:16)
def cam_panel(box, info):
    """facecam panel height: show as much of the cam as fits, between 30% and 42% of the frame"""
    if not box: return CAM_H
    asp = (box[2] * info['width']) / max(1, box[3] * info['height'])
    return int(min(H * .42, max(H * .30, W / asp))) // 2 * 2

def layout_filter(layout, info, box, gx=.5, fit_zoom=1.0, cam_h=CAM_H):
    sw, sh = info['width'], info['height']
    ev = lambda v: int(v) // 2 * 2
    if layout == 'stack':
        cx, cy, cw, ch = box[0] * sw, box[1] * sh, box[2] * sw, box[3] * sh
        ins = .055; cx += cw * ins; cy += ch * ins; cw *= 1 - 2 * ins; ch *= 1 - 2 * ins   # drop the overlay's frame line
        cam_h = cam_panel(box, info)
        a = W / cam_h
        if cw / ch > a: nw = ch * a; cx += (cw - nw) / 2; cw = nw
        else: nh = cw / a; cy += (ch - nh) * .2; ch = nh
        gh = H - cam_h; ga = W / gh; gcw = min(sw, sh * ga); gch = gcw / ga
        gx0 = min(max(gx * sw - gcw / 2, 0), sw - gcw)
        return (f"[0:v]split[c][g];[c]crop={ev(cw)}:{ev(ch)}:{int(cx)}:{int(cy)},scale={W}:{cam_h}:flags=lanczos[top];"
                f"[g]crop={ev(gcw)}:{ev(gch)}:{int(gx0)}:{int((sh - gch) / 2)},scale={W}:{gh}:flags=lanczos[bot];"
                f"[top][bot]vstack,drawbox=x=0:y={cam_h - 3}:w={W}:h=6:color=black:t=fill,setsar=1,fps=30,format=yuv420p[v]")
    if layout == 'fit':
        return (f"[0:v]split[b][f];[b]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=28:3,eq=brightness=-0.18[bg];"
                f"[f]scale={ev(W * fit_zoom)}:-2:flags=lanczos,crop={W}:ih[fg];[bg][fg]overlay=0:(H-h)/2,setsar=1,fps=30,format=yuv420p[v]")
    cw = sh * 9 / 16; x0 = min(max(gx * sw - cw / 2, 0), sw - cw)                     # crop
    return f"[0:v]crop={ev(cw)}:{ev(sh)}:{int(x0)}:0,scale={W}:{H}:flags=lanczos,setsar=1,fps=30,format=yuv420p[v]"

def text_spots(layout, cam_h=CAM_H):
    """caption placement and the title card's centre, per layout"""
    if layout == 'stack': return dict(pos_y=cam_h, card_y=cam_h + 270)          # captions ride the seam between cam and game
    if layout == 'fit':
        band = W * 9 / 16; top = (H - band) / 2
        return dict(pos_y=int(top + band + 110), card_y=int(top - 190))
    return dict(y=int(H * .3), card_y=int(H * .2))


def hook_card(text, out_dir, seconds=2.0, fps=30, accent='#FF2D55'):
    """the opening title card: a white sticker-style card with heavy black type that pops in, tilts a touch and pops out.
    Words wrapped in *stars* are coloured. Writes PNG frames (1080x640 canvas) and returns their pattern."""
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
    font = ImageFont.truetype(os.path.join(fe.FONTS, 'Montserrat-Black.ttf'), 66)
    words = text.upper().split(); lines = wrap_hook(' '.join(words), 16).split('\\N')
    toks = [[(w.strip('*'), w.startswith('*') or w.endswith('*')) for w in ln.split()] for ln in lines]
    sp = font.getlength(' '); lh = 80
    widths = [sum(font.getlength(w) for w, _ in ln) + sp * (len(ln) - 1) for ln in toks]
    cw, ch = int(max(widths) + 84), int(lh * len(toks) + 56)
    card = Image.new('RGBA', (cw + 60, ch + 60), (0, 0, 0, 0))
    sh = Image.new('RGBA', card.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle((34, 40, 30 + cw, 36 + ch), 34, fill=(0, 0, 0, 150))
    card = Image.alpha_composite(card, sh.filter(ImageFilter.GaussianBlur(10)))
    d = ImageDraw.Draw(card); d.rounded_rectangle((30, 30, 30 + cw, 30 + ch), 32, fill=(255, 255, 255, 255))
    y = 30 + 28
    for ln, wd in zip(toks, widths):
        x = 30 + (cw - wd) / 2
        for w, hot in ln:
            d.text((x, y), w, font=font, fill=accent if hot else '#111111'); x += font.getlength(w) + sp
        y += lh
    card = card.rotate(2.5, resample=Image.BICUBIC, expand=True)
    os.makedirs(out_dir, exist_ok=True); CW, CH = W, 640; n = int(seconds * fps)
    def ease_back(t): c = 1.9; return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2
    for k in range(n):
        t = k / fps
        if t < .3: sc_, al = .35 + .65 * ease_back(t / .3), min(1, t / .12)
        elif t > seconds - .22: q = (seconds - t) / .22; sc_, al = .85 + .15 * q, q
        else: sc_, al = 1 + .015 * math.sin((t - .3) * 3), 1          # a slow breathe while it holds
        im = card.resize((max(1, int(card.width * sc_)), max(1, int(card.height * sc_))), Image.LANCZOS)
        if al < 1: im.putalpha(im.getchannel('A').point(lambda v: int(v * al)))
        fr = Image.new('RGBA', (CW, CH), (0, 0, 0, 0)); fr.alpha_composite(im, ((CW - im.width) // 2, (CH - im.height) // 2))
        fr.save(os.path.join(out_dir, f'{k:04d}.png'))
    return os.path.join(out_dir, '%04d.png'), CH


def wrap_hook(text, maxc=18):
    """2-3 balanced lines (no single word left on its own line)"""
    words = text.split()
    if len(text) <= maxc or len(words) < 2: return text
    best = None
    for n in (2, 3):
        if n > len(words): break
        import itertools
        for cut in itertools.combinations(range(1, len(words)), n - 1):
            parts = [' '.join(words[i:j]) for i, j in zip((0,) + cut, cut + (len(words),))]
            cost = max(len(x) for x in parts) + (0 if n == 2 else 4)
            if best is None or cost < best[0]: best = (cost, parts)
        if best and max(len(x) for x in best[1]) <= maxc: break
    return '\\N'.join(best[1])


# ------------------------------------------------------------------ render
def snap_window(words, t0, peak, t1, gap=.55):
    """start where the setup starts and stop just after the punchline: clip edges land on pauses between sentences,
    so a clip never starts mid-word or runs long after the moment. Keeps 12-50 s."""
    ws = [w for w in words if t0 - .05 <= w['s'] and w['e'] <= t1 + .05]
    if len(ws) < 4 or not t0 < peak < t1: return t0, t1
    starts = [ws[0]['s']] + [ws[k]['s'] for k in range(1, len(ws)) if ws[k]['s'] - ws[k - 1]['e'] >= gap]
    ends = [ws[k]['e'] for k in range(len(ws) - 1) if ws[k + 1]['s'] - ws[k]['e'] >= gap] + [ws[-1]['e']]
    st = [x for x in starts if peak - 22 <= x <= peak - 5]
    a = min(st, key=lambda x: abs(x - (peak - 12))) - .25 if st else max(t0, peak - 15)
    en = [x for x in ends if peak + 2.5 <= x <= peak + 14]
    b = (en[0] + .9) if en else min(t1, peak + 8)
    a, b = max(t0, a), min(t1, b)
    if b - a < 12: a = max(t0, b - 12)
    if b - a < 12: b = min(t1, a + 12)
    return round(a, 2), round(b, 2)

def render(project, clips_path, only=None):
    C = json.load(open(clips_path)); clip = stream(project); src = os.path.join(project, 'raw', clip); inf = info_of(project, clip)
    box = C.get('cam') or cam_box(project)
    os.makedirs(os.path.join(project, 'out'), exist_ok=True); done = []
    for c in C['clips']:
        if only and c['name'] != only: continue
        cuts = [[secs(a), secs(b)] for a, b in c.get('cuts', [])] or [[secs(c['in']), secs(c['out'])]]
        t0, t1 = min(a for a, _ in cuts), max(b for _, b in cuts)
        if c.get('peak') is not None and not c.get('cuts') and c.get('snap', C.get('snap', True)):
            tr0 = transcribe_exact(project, c['name'], t0, t1, C.get('language'), C.get('prompt'))
            s0, s1 = snap_window(tr0['words'], t0, secs(c['peak']), t1)
            if (s0, s1) != (t0, t1): print(f'{c["name"]}: tightened to the full sentences around the moment ({s1 - s0:.0f}s)')
            c['_win'] = (t0, t1); cuts = [[s0, s1]]; t0, t1 = s0, s1
            c['_snapped'] = [round(s0, 2), round(s1, 2)]
            sp_ = os.path.join(project, 'out', 'snapped.json'); d_ = json.load(open(sp_)) if os.path.exists(sp_) else {}
            d_[c['name']] = c['_snapped']; json.dump(d_, open(sp_, 'w'))
        layout = c.get('layout', C.get('layout', 'auto'))
        if layout == 'auto': layout = 'stack' if box else 'fit'
        if layout == 'stack' and not box: layout = 'fit'
        cb = c.get('cam') or box
        sub = W_(project, 'clips', c['name']); shutil.rmtree(sub, True); os.makedirs(os.path.join(sub, 'raw'))
        os.makedirs(os.path.join(sub, 'work', 'transcripts'))
        mid = os.path.join(sub, 'raw', c['name'] + '.mp4')
        print(f'{c["name"]}: {T(t0)} - {T(t1)}  ({t1 - t0:.1f}s, {layout} layout)', flush=True)
        fe.run(['-ss', f'{t0:.3f}', '-t', f'{t1 - t0:.3f}', '-i', src, '-filter_complex',
                layout_filter(layout, inf, cb, c.get('gx', C.get('gx', .5)), c.get('fit_zoom', C.get('fit_zoom', 1.0))),
                '-map', '[v]', '-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', mid])
        want = c.get('captions', C.get('captions', {})) is not None
        tr = (transcribe_exact(project, c['name'], *(c.get('_win') or (t0, t1)), C.get('language'), C.get('prompt')) if want else dict(words=[]))
        fixes = {**C.get('fix', {}), **c.get('fix', {})}            # Claude's corrections: {"heard": "said"}
        ws = []
        for w in tr['words']:
            if not any(a_ <= (w['s'] + w['e']) / 2 <= b_ for a_, b_ in cuts): continue
            t = fixes.get(w['w'], w['w'])
            if not t: continue                                       # a fix to "" removes the word
            if c.get('censor', C.get('censor', False)) and SWEARS.match(re.sub(r'[^A-Za-z]', '', t)):
                core = re.sub(r'[^A-Za-z]', '', t); t = t.replace(core, core[0] + '*' * (len(core) - 1))
            ws.append(dict(w=t, s=round(w['s'] - t0, 3), e=round(w['e'] - t0, 3)))
        open(os.path.join(project, 'out', c['name'] + '.captions.txt'), 'w', encoding='utf-8').write(
            ' '.join(w['w'] for w in ws) + ('\n\n(left out, not sure they were said: ' + ', '.join(tr.get('dropped', [])) + ')' if tr.get('dropped') else '') + '\n')
        json.dump(dict(words=ws, sentences=[]), open(os.path.join(sub, 'work', 'transcripts', c['name'] + '.mp4.json'), 'w'))
        json.dump([dict(fe.probe(mid), file=c['name'] + '.mp4')], open(os.path.join(sub, 'work', 'clips.json'), 'w'))
        cap = c.get('captions', C.get('captions', {})); spots = text_spots(layout, cam_panel(cb, inf) if cb else CAM_H)
        card_y = spots.pop('card_y')
        cap = dict(dict(preset='stream', highlight='#FFE600', outline=9, shadow=5, grow=114, **spots), **(cap if cap is not None else {'off': True}))
        hook = c.get('hook'); hl = c.get('hook_seconds', C.get('hook_seconds', 2.0))
        edit = dict(name=c['name'], format='9:16', punch_in='off', captions=cap, fps=30, texts=[],
                    segments=[dict(clip=c['name'] + '.mp4', **{'in': round(a - t0, 3), 'out': round(b - t0, 3)}, fx=.5) for a, b in cuts])
        m = c.get('music', C.get('music'))
        if m:
            mp = m['file'] if os.path.isabs(m['file']) else os.path.join(project, m['file'])
            os.makedirs(os.path.join(sub, 'music'), exist_ok=True); shutil.copy(mp, os.path.join(sub, 'music', os.path.basename(mp)))
            edit['music'] = dict(file='music/' + os.path.basename(mp), volume_db=m.get('volume_db', -20))
        ep = os.path.join(sub, 'edit.json'); json.dump(edit, open(ep, 'w'), indent=1)
        if c.get('tighten'): fe.tighten(sub, ep, max_gap=.6, drop_fillers=True); ep = ep.replace('.json', '.tight.json')
        out = fe.render(sub, ep)
        final = os.path.join(project, 'out', c['name'] + '.mp4')
        if hook:                                                   # title card on top, then the finished clip underneath
            pat, ch_ = hook_card(hook, os.path.join(sub, 'card'), hl, accent=c.get('accent', C.get('accent', '#FF2D55')))
            fe.run(['-i', out, '-framerate', '30', '-i', pat, '-filter_complex', f'[0:v][1:v]overlay=0:{int(card_y - ch_ / 2)}:eof_action=pass,format=yuv420p[v]',
                    '-map', '[v]', '-map', '0:a', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-c:a', 'copy', '-movflags', '+faststart', final])
            os.remove(out)
        else: shutil.move(out, final)
        fe.sheet(final, 8)
        done.append(final)
    score(project, clips_path)
    return done


# ------------------------------------------------------------------ viral score
def score(project, clips_path):
    """0-100: half from what the stream measurably did (signals, words), half from Claude's judgement of the clip"""
    C = json.load(open(clips_path)); S = load_signals(project); sc = np.array(S['score']); N = len(sc)
    tp = W_(project, 'transcripts', S['clip'] + '.json'); tr = json.load(open(tp)) if os.path.exists(tp) else dict(words=[])
    hi = np.percentile(sc, 80); rows, md = [], []
    sp_ = os.path.join(project, 'out', 'snapped.json'); snapped = json.load(open(sp_)) if os.path.exists(sp_) else {}
    votes = load_votes(project, N)
    for c in C['clips']:
        cuts = [[secs(a), secs(b)] for a, b in c.get('cuts', [])] or [snapped.get(c['name']) or [secs(c['in']), secs(c['out'])]]
        t0, t1 = min(a for a, _ in cuts), max(b for _, b in cuts); L = sum(b - a for a, b in cuts)
        idx = np.r_[tuple(np.arange(int(a), min(N, int(math.ceil(b)))) for a, b in cuts)].astype(int)
        seg = sc[idx] if len(idx) else np.zeros(1)
        peak = float(np.mean(sc <= seg.max()))
        ref = np.percentile(sc, 99.5); p_int = 15 * max(0, min(1, (seg.max() / max(1e-6, ref) - .3) / .7))
        ws = [w for w in tr['words'] if any(a - .02 <= w['s'] and w['e'] <= b + .05 for a, b in cuts)]
        first_hype = next((w['s'] - t0 for w in ws), 99)                 # first spoken word: no dead air at the start
        first_big = next((k for k, v in enumerate(seg) if v >= hi), 99)
        hook_t = min(first_hype, first_big)
        p_hook = 15 * max(0, min(1, (5 - hook_t) / 3.8))
        p_len = 10 if 15 <= L <= 45 else 7 if 45 < L <= 60 or 10 <= L < 15 else 4 if L <= 90 else 1
        wps = len(ws) / max(1, L); hw = hype_words(ws)
        p_talk = min(10, 2.0 * wps + .5 * hw)
        auto = p_int + p_hook + p_len + p_talk
        J = c.get('judge', {}); keys = ['hook', 'payoff', 'standalone', 'emotion', 'share']
        judge = sum(max(0, min(10, float(J.get(k, 5)))) for k in keys)
        total = round(auto + judge)
        parts = {'peak intensity': (p_int, 15), 'hook speed': (p_hook, 15), 'length': (p_len, 10), 'reaction/talk': (p_talk, 10)}
        parts.update({f'{k} (Claude)': (float(J.get(k, 5)), 10) for k in keys})
        good = [k for k, (v, m) in parts.items() if v / m >= .8]; weak = [k for k, (v, m) in parts.items() if v / m < .45]
        reasons = []
        if peak >= .99: reasons.append(f'one of the most intense moments of the whole stream (top {max(1, round(100 * (1 - peak)))}%)')
        if hook_t <= 1.2: reasons.append('the action or talking starts straight away')
        elif hook_t > 3: reasons.append(f'{min(hook_t, L):.0f} s of quiet before anything happens: start later or add a stronger hook line')
        if not 15 <= L <= 60: reasons.append(f'{L:.0f} s long: {"too short to build up" if L < 15 else "long for a Short; trim the setup"}')
        if hw >= 4: reasons.append('lots of hype in the voice and words')
        if c.get('why'): reasons.append(c['why'])
        if J.get('standalone', 5) < 5: reasons.append('needs context from earlier in the stream')
        grade = 'very high' if total >= 85 else 'high' if total >= 70 else 'medium' if total >= 55 else 'low'
        rows.append(dict(name=c['name'], score=total, grade=grade, length=round(L, 1), start=T(t0), auto=round(auto), judge=round(judge),
                         strong=good, weak=weak, reasons=reasons, title=c.get('title', ''), caption=c.get('caption', '')))
    rows.sort(key=lambda r: -r['score'])
    md.append(f'# Viral scores · {S["clip"]}\n')
    md.append('Score out of 100: 50 from the stream itself (how intense the peak is, how fast the hook lands, length, reactions) '
              'and 50 from Claude watching the clip (hook, payoff, makes sense alone, emotion, would people share it). '
              'Post the highest first. A score is a guide, not a promise.\n')
    md.append('| Rank | Clip | Score | Length | Starts at |'); md.append('|---|---|---|---|---|')
    for k, r in enumerate(rows, 1): md.append(f'| {k} | {r["name"]} | **{r["score"]}** ({r["grade"]}) | {r["length"]:.0f}s | {r["start"]} |')
    for r in rows:
        md.append(f'\n## {r["name"]}: {r["score"]}/100 ({r["grade"]})')
        if r['title']: md.append(f'**Title:** {r["title"]}')
        if r['caption']: md.append(f'**Caption:** {r["caption"]}')
        md.append(f'Stream signals {r["auto"]}/50 · Claude\'s judgement {r["judge"]}/50')
        if r['strong']: md.append('Strong: ' + ', '.join(r['strong']))
        if r['weak']: md.append('Weak: ' + ', '.join(r['weak']))
        for x in r['reasons']: md.append(f'- {x}')
    os.makedirs(os.path.join(project, 'out'), exist_ok=True)
    open(os.path.join(project, 'out', 'scores.md'), 'w', encoding='utf-8').write('\n'.join(md) + '\n')
    json.dump(rows, open(os.path.join(project, 'out', 'scores.json'), 'w'), indent=1)
    for r in rows: print(f'{r["score"]:3d}/100  {r["name"]}  ({r["length"]:.0f}s)')
    print('->', os.path.join(project, 'out', 'scores.md')); return rows




def peek(project, a, b, n=12):
    return strip_img(project, secs(a), secs(b), os.path.join('work', f'peek_{int(secs(a))}_{int(secs(b))}.jpg'), n)


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    cmd = a[0]; P = os.path.abspath(os.path.expanduser(a[1])) if len(a) > 1 else None
    flags = [x for x in a[2:] if x.startswith('--')]; rest = [x for x in a[2:] if not x.startswith('--')]
    if cmd == 'fetch': fetch(P, rest[0], rest[1] if len(rest) > 1 else None, 1080 if '--1080' in flags else 720, False)
    elif cmd == 'cleanup': cleanup(P)
    elif cmd == 'cam': find_cam(P, rest if len(rest) == 4 else None)
    elif cmd == 'signals': signals(P)
    elif cmd == 'moments': moments(P, int(rest[0]) if rest else 15, '--full' in flags)
    elif cmd == 'peek': print(peek(P, rest[0], rest[1], int(rest[2]) if len(rest) > 2 else 12))
    elif cmd == 'render': render(P, os.path.abspath(rest[0]), rest[1] if len(rest) > 1 else None)
    elif cmd == 'score': score(P, os.path.abspath(rest[0]))
    elif cmd == 'captions': set_captions(a[1] if len(a) > 1 else 'best')
    else: print(__doc__)
