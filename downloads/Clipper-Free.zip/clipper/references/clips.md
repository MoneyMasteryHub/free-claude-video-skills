# The clips file (clips.json)

One file lists every clip to cut from the stream. Times are **seconds in the stream** (`moments.md` prints both h:mm:ss and seconds; "1:02:03.5" also works).

```json
{
  "layout": "auto",
    "clips": [
    {
      "name": "01_cop_chase",
      "in": 3721.5, "out": 3754.0,
      "hook": "He thought he *lost* the cops",
      "title": "He really thought he lost them 💀",
      "caption": "five stars in ten seconds #gta #gta6 #gaming #fyp",
      "judge": {"hook": 8, "payoff": 9, "standalone": 7, "emotion": 9, "share": 8},
      "why": "chase into a crash, huge reaction",
      "peak": 3742
    },
    {
      "name": "02_pier_jump",
      "cuts": [[5120.0, 5131.5], [5140.2, 5158.0]],
      "hook": "Chat made him do it",
      "layout": "fit"
    }
  ]
}
```

## Top-level options (each clip can override them)
- **`layout`**:
  - `"stack"`: facecam on top (1080x690), gameplay underneath. This is the standard streamer clip look.
  - `"fit"`: the full 16:9 game in the middle on a blurred copy of itself, with the hook above and captions below. Use it when the whole screen matters (a wide crash, a map, a race) or when there's no facecam.
  - `"crop"`: the centre of the game fills the whole 9:16 frame. Use it for close action with no facecam.
  - `"auto"` (default): `stack` with a facecam, `fit` without one.
- **`gx`**: where the gameplay crop sits, 0 (left) to 1 (right). Default 0.5. GTA action is usually in the centre (the car or the character).
- **`fit_zoom`**: 1.0 to 1.4, enlarges the game in `fit` (crops its sides).
- **`cam`**: `[x, y, w, h]`, a facecam box in 0 to 1 frame coordinates, if the stream's cam moves or `cam` got it wrong.
- **`captions`**: word-by-word captions in heavy Montserrat Black capitals, 3 words at a time, the spoken word in yellow and slightly bigger. In the `stack` layout they sit right on the line between the facecam and the game; in `fit` they sit under the game. Overrides: `highlight`, `color`, `size`, `maxw` (words at a time), `pos_y` (the caption line's centre, in px from the top). Set `null` for none (for a clip with no talking, or one in another language).
- **`fix`**: corrections for misheard words, `{"heard": "said"}` (`{"Who": ""}` removes one). Use it after reading `out/<name>.captions.txt`.
- **`censor`**: true turns swear words in captions into `f***` (safer for TikTok and brand campaigns; the audio is untouched).
- **`prompt`**: names and words the speech model should expect ("GTA 6, Vice City, Jason, Lucia, Kai Cenat"), so it spells them right.
- **`accent`**: the colour of the starred word in the title card (default `"#FF2D55"`).
- **`music`**: `{"file": "music/track.mp3", "volume_db": -20}`, ducked under the voice. Usually leave it out: the game sound is the soundtrack.
- **`language`**: e.g. `"en"`, if the transcript comes out in the wrong language.

## Clip options
- **`name`**: the file name (`01_...`, `02_...` keeps them in order).
- **`in`, `out`**: the stretch to use. **Or `cuts`**: several stretches joined together, to drop a boring middle (a loading screen, a long drive).
- **`hook`**: the opening title card: 2 to 7 words on a white sticker-style card that pops in at the top of the game, tilts slightly, and pops out after 2.8 s (`hook_seconds` to change). Wrap the one word that carries the punch in stars and it turns red: `"This is where we *die*"`. It tells the viewer why to stay: tension, a question or a promise ("Wait for the *landing*", "He did NOT see that *coming*", "5 stars in *10 seconds*"). Never a fake quote.
- **`title`, `caption`**: suggestions for the post; they go into `scores.md`.
- **`judge`**: Claude's 0-10 ratings after watching the strip and reading the words (see below).
- **`why`**: one line on why this clip works; it shows in `scores.md`.
- **`tighten`**: true removes long silences inside the clip (for talk clips; leave it off for gameplay, where the quiet build-up matters).

## How Claude picks a clip
1. **Start a beat before the cause.** The viewer must see what's about to go wrong: the truck coming, the cop car behind, the jump run-up. 1 to 4 seconds of setup, never 20.
2. **The first 1.5 seconds must already be interesting**: motion, a voice, a question on screen. If the setup is slow, start later and let the hook line carry the context.
3. **End right after the payoff**: the reaction, the punchline, the "bro…". Cut before the streamer moves on or reads chat.
4. **Length**: 15 to 45 s is the sweet spot; up to 60 s only if the story needs it.
5. **One idea per clip.** Two great moments a minute apart are two clips.
6. **Self-contained.** Someone who never saw the stream should get it. If it needs context, put that context in the hook.
7. **Spread them out.** Don't post five near-identical crashes; mix chases, fails, funny lines and wins.

## The viral score (0-100)
Half is measured from the stream, half is Claude's judgement:
- **From the stream (50):**
  - peak intensity, against the rest of this stream (15)
  - hook speed: how soon the action or a hype word lands after the start (15)
  - length fit (10)
  - reaction and talk: words per second and hype words (10).
- **Claude (50)**, 0 to 10 each, honestly:
  - `hook`: would a stranger stop scrolling in the first second?
  - `payoff`: is there a clear climax or punchline?
  - `standalone`: does it make sense without the stream?
  - `emotion`: how strong is the shock, laugh, rage or hype?
  - `share`: would someone send it to a friend or comment on it?

Be strict: a 9 or 10 means one of the best clips you can imagine from this kind of stream. Most good clips land between 60 and 80. If a clip scores under 50, say so and suggest dropping it or recutting it (start later, end sooner, a stronger hook). `scores.md` lists each clip's strong and weak parts so the user knows what to post first.

## Tight edges (`peak`)
Give a clip the `"peak"` second from moments.md and Clipper moves its start to the pause before the setup (about 5 to 22 s before the peak) and its end to the pause right after the punchline (2.5 to 14 s after), so clips never start mid-word or drag on after the moment. It stays between `in` and `out` and keeps 12 to 50 s. Turn it off with `"snap": false` (or set exact `"cuts"`).
