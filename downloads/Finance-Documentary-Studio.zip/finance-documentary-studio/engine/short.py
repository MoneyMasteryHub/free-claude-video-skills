"""Shorts / Reels / TikTok cut of a finished episode (1080x1920, 9:16):  python3 episode.py short [start end] [--hook "..."]

Default: the thriller cold open plus the title slam (a ready-made teaser that sends people to the full film).
Give start and end in seconds, or a chapter title ('THE GOLD RUSH') to cut that chapter instead. Keep Shorts under 90 s.
Layout: the 16:9 film sits in the middle of a near-black frame (the cold open's letterbox bars melt into it); the hook on top; big word-by-word
captions below (the word being spoken turns green); "FULL STORY ON THE CHANNEL" in the last 2 seconds.
Needs <episode>_final.mp4 (run `python3 episode.py all` first). Writes <episode>_short.mp4."""
import os, subprocess, json, re
import skia
from film import FFMPEG
import fin as F

SW, SH = 1080, 1920

def _groups(words, a, b, n=3):
    """caption chunks: up to n words, broken at sentence ends, only words inside [a, b]"""
    out, cur = [], []
    for w in words:
        if w[0] < a - .05 or w[1] > b + .3: continue
        cur.append(w)
        if len(cur) >= n or w[2].endswith(('.', '?', '!', ',')): out.append(cur); cur = []
    if cur: out.append(cur)
    return out

def make(film, args):
    src = os.path.join(film.dir, film.name + '_final.mp4')
    if not os.path.exists(src): raise SystemExit('render the episode first: python3 episode.py all')
    hook = None
    if '--hook' in args: i = args.index('--hook'); hook = args[i + 1]; args = args[:i] + args[i + 2:]
    tt = [c for c in film.chapters if str(c[1]).startswith('TITLE:')]
    if len(args) >= 2: a, b = float(args[0]), float(args[1])
    elif len(args) == 1:
        ch = [c for c in film.chapters if c[2].lower() == args[0].lower()]
        if not ch: raise SystemExit(f'no chapter "{args[0]}"')
        a = ch[0][0]; nxt = [c[0] for c in film.chapters if c[0] > a]; b = min(nxt[0] if nxt else film.end_time, a + 89)
    elif tt: a, b = 0.0, tt[0][0] + tt[0][3] + .5
    else: a, b = 0.0, min(film.end_time, 60.0)
    small = None
    if hook is None:
        if tt: small, hook = tt[0][1][6:], tt[0][2]          # the episode title: small line + big line
        else: hook = film.name.replace('_', ' ')
    dur = b - a
    if dur > 90: print(f'note: this Short is {dur:.0f}s; Shorts do best under 60-90 s')
    groups = _groups(film.words, a, b)
    out = os.path.join(film.dir, film.name + '_short.mp4')
    fy = (SH - 608) // 2 - 40                     # where the 16:9 film sits
    flt = (f'color=c=0x05070A:s={SW}x{SH}:r={F.FPS}:d={dur:.3f}[bg];'
           f'[0:v]scale={SW}:-2,setsar=1[fg];[bg][fg]overlay=0:{fy}:shortest=1[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[v];'
           f'[0:a]afade=t=in:d=0.05,afade=t=out:st={max(0, dur - .5):.2f}:d=0.5[au]')
    p = subprocess.Popen([FFMPEG, '-v', 'error', '-y', '-ss', f'{a:.3f}', '-t', f'{dur:.3f}', '-i', src,
                          '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', f'{SW}x{SH}', '-r', str(F.FPS), '-i', '-',
                          '-filter_complex', flt, '-map', '[v]', '-map', '[au]', '-c:v', 'libx264', '-crf', '19', '-preset', 'veryfast',
                          '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out], stdin=subprocess.PIPE)
    surf = skia.Surface(SW, SH); c = surf.getCanvas()
    hs = 128
    while True:
        hook_lines = F._wrap(hook.upper(), hs, F.BEBAS, SW - 110)
        if len(hook_lines) <= 2 or hs <= 90: break
        hs -= 6
    for f in range(int(round(dur * F.FPS))):
        t = a + f / F.FPS; c.clear(skia.ColorTRANSPARENT)
        # hook on top
        k = F.ease_out(F.K(t, a, .5)); y0 = fy - 80 - (len(hook_lines) - 1) * hs * .95
        if small: F.text(c, small.upper(), SW / 2, y0 - hs * .95 + 10, 50, F.MONO, F.GREEN, 'center', 255 * k, 4)
        for i, ln in enumerate(hook_lines):
            F.text(c, ln, SW / 2, y0 + i * hs * .95 + 30 * (1 - k), hs, F.BEBAS, F.TXT, 'center', 255 * k, 3, shadow=.9)
        c.drawRect(skia.Rect(SW / 2 - 120 * k, fy - 34, SW / 2 + 120 * k, fy - 28), F.fp(F.RED))
        # captions under the film, the spoken word in green
        g = next((g for g in groups if g[0][0] - .05 <= t <= g[-1][1] + .25), None)
        if g:
            size = 92; parts = [w[2].upper() for w in g]
            while F.tw(' '.join(parts), size, F.BEBAS, 2) > SW - 100: size -= 4
            x = SW / 2 - F.tw(' '.join(parts), size, F.BEBAS, 2) / 2; yy = fy + 608 + 190
            pop = 1 + .06 * (1 - F.K(t, g[0][0], .12))
            c.save(); c.translate(SW / 2, yy); c.scale(pop, pop); c.translate(-SW / 2, -yy)
            for w, s_ in zip(g, parts):
                on = w[0] - .02 <= t <= w[1] + .08
                F.text(c, s_, x + 4, yy + 5, size, F.BEBAS, '#000000', a=200, track=2)
                F.text(c, s_, x, yy, size, F.BEBAS, F.GREEN if on else F.TXT, track=2)
                x += F.tw(s_ + ' ', size, F.BEBAS, 2)
            c.restore()
        # end card
        e = F.K(t, b - 2.0, .3)
        if e > 0:
            msg = 'FULL STORY ON THE CHANNEL'; w_ = F.tw(msg, 54, F.BEBAS, 4) + 60; yy = SH - 250
            c.drawRoundRect(skia.Rect(SW / 2 - w_ / 2, yy - 62, SW / 2 + w_ / 2, yy + 20), 14, 14, F.fp(F.GREEN, 240 * e))
            F.text(c, msg, SW / 2, yy, 54, F.BEBAS, F.BG, 'center', 255 * e, 4)
        p.stdin.write(surf.makeImageSnapshot().toarray(colorType=skia.kRGBA_8888_ColorType).tobytes())
    p.stdin.close()
    if p.wait() != 0: raise SystemExit('ffmpeg failed making the Short')
    print('wrote', out, f'({dur:.1f}s, 1080x1920)')
