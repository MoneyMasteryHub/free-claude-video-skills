"""The finance documentary look: a dark market-terminal style built on real photos and numbers that move.

    from fin import *
    film = Film(__file__, vo='vo.wav', words='words.json', mood='money')
    T = film.cue
    fin = Fin(film)
    fin.photo(0, 'media/store.jpg', frm=(.5, .5, 1.0), to=(.55, .45, 1.15), credit='Photo: Jane Doe, CC BY-SA 2.0')
    fin.number(T('six billion'), 6_000_000_000, prefix='$', label='REVENUE, 2004')
    fin.chart(T('Then'), [(2000, 4.96), (2004, 6.05), (2010, 3.2)], title='REVENUE', unit='$B', crash_from=2004)
    fin.bars(T('stores'), [('Blockbuster', 9000, GREEN), ('Netflix', 0, BLUE)], title='STORES')
    fin.versus(T('offered'), ('NETFLIX', '$50M', 'the asking price'), ('BLOCKBUSTER', '$6B', 'yearly revenue'))
    fin.statement(T('They laughed'), 'THEY LAUGHED', sub='Blockbuster said no')
    @fin.screen
    def words(c, t):
        tag(c, t, T('Dallas'), T('By'), 'Dallas, Texas', '1985', 'THE FIRST STORE')
        stamp(c, t, T('bankrupt'), 'BANKRUPT')
    fin.render()
    film.main()

Shot kinds: photo (real photo full screen or on a floating card), chart (a line that draws itself, red after the crash),
number (a big counter), bars (comparison), versus (split screen), statement (one big line), scene (anything you draw).
Overlays (inside @fin.screen): tag, name_tag, year_badge, stamp, ticker, quote, credit_line, title_card.
Chapter cards come by themselves in the narrator's chapter pauses. See references/fin.md."""
import os, math, random
import numpy as np, skia
from film import Film, W, H, FPS, C, K, ease, lerp, sfx
from core import ease_out, pop as _pop
import doc as _doc
from doc import _art, _window, _blit, fade

_FD = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'fonts') + os.sep
BEBAS = skia.Typeface.MakeFromFile(_FD + 'BebasNeue-Regular.ttf')
OSWALD = skia.Typeface.MakeFromFile(_FD + 'Oswald-Variable.ttf')
MONO = skia.Typeface.MakeFromFile(_FD + 'IBMPlexMono-Medium.ttf')
BG, PANEL, GRID, TXT, MUTED = '#0A0E13', '#111821', '#1A2430', '#ECF1F5', '#7F8C9B'
GREEN, RED, GOLD, BLUE, CYAN = '#2BD47D', '#FF4D4D', '#F2B544', '#4DA3FF', '#38D6E0'

col, fp, font, tw = _doc.col, _doc.fp, _doc.font, _doc.tw
def text(c, s, x, y, size, tf=OSWALD, h=TXT, align='left', a=255, track=0, wght=None, shadow=0):
    return _doc.text(c, s, x, y, size, tf, h, align, a, track, wght, shadow)
def line(w, h=TXT, a=255):
    p = skia.Paint(AntiAlias=True, Color=col(h, a), Style=skia.Paint.kStroke_Style, StrokeWidth=w)
    p.setStrokeCap(skia.Paint.kRound_Cap); p.setStrokeJoin(skia.Paint.kRound_Join); return p
def glow(h, a, blur): return fp(h, a, blur)
def money(v, prefix='$', decimals=0):
    """6000000000 -> '$6,000,000,000'"""
    s = f'{abs(v):,.{decimals}f}'; return ('-' if v < 0 else '') + prefix + s
def short(v, prefix='$'):
    """6e9 -> '$6B', 5e7 -> '$50M'"""
    a = abs(v)
    for d, u in ((1e12, 'T'), (1e9, 'B'), (1e6, 'M'), (1e3, 'K')):
        if a >= d: s = f'{a / d:.1f}'.rstrip('0').rstrip('.'); return ('-' if v < 0 else '') + prefix + s + u
    return prefix + f'{a:g}'


# ================================================================ background: dark terminal with a slow grid
_rng = np.random.default_rng(5)
_g = (_rng.standard_normal((H, W)) * 14 + 128).clip(0, 255).astype(np.uint8)
_GRAIN = [skia.Image.fromarray(np.dstack([np.roll(_g, k * 97, 1), np.roll(_g, k * 97, 1), np.roll(_g, k * 97, 1), np.full((H, W), 14, np.uint8)]), colorType=skia.kRGBA_8888_ColorType) for k in range(4)]

def market_bg(c, t, glow_at=(W * .72, H * .28), tint=CYAN):
    c.drawRect(skia.Rect(0, 0, W, H), fp(BG))
    sh = skia.GradientShader.MakeRadial(glow_at, W * .7, [col(tint, 34), col(tint, 0)], [0, 1])
    p = skia.Paint(); p.setShader(sh); c.drawRect(skia.Rect(0, 0, W, H), p)
    off = (t * 9) % 80
    for x in range(-80, W + 80, 80): c.drawLine(x + off, 0, x + off, H, line(1, GRID, 120))
    for y in range(0, H + 80, 80): c.drawLine(0, y, W, y, line(1, GRID, 120))

def finish(c, t, vig=.55):
    c.drawImage(_GRAIN[int(t * 12) % 4], 0, 0)
    sh = skia.GradientShader.MakeRadial((W / 2, H / 2), W * .78, [col('#000000', 0), col('#000000', 0), col('#000000', 255 * vig)], [0, .55, 1])
    p = skia.Paint(); p.setShader(sh); c.drawRect(skia.Rect(0, 0, W, H), p)

# photo grade: a touch cooler and less saturated, so real photos sit inside the dark look
_GRADE = skia.ColorFilters.Matrix([.86, .12, .02, 0, 0,  .05, .89, .06, 0, 0,  .03, .12, .87, 0, .015,  0, 0, 0, 1, 0])


# ================================================================ overlays (call inside @fin.screen)
def tag(c, t, t0, t1, line_, sub=None, kind=None, x=96, y=H - 130):
    """lower-left tag: a green mono kind, a big line, a small sub line"""
    a = fade(t, t0, t1, .45, .45)
    if a <= 0: return
    sh = skia.GradientShader.MakeLinear([(0, H - 360), (0, H)], [col('#000000', 0), col('#000000', 190 * a)])
    p = skia.Paint(); p.setShader(sh); c.drawRect(skia.Rect(0, H - 360, W, H), p)
    dx = 24 * (1 - ease_out(K(t, t0, .6)))
    if kind:
        kw = tw(kind.upper(), 24, MONO, 3) + 28
        c.drawRoundRect(skia.Rect(x + dx, y - 104, x + dx + kw, y - 66), 6, 6, fp(GREEN, 235 * a))
        text(c, kind.upper(), x + dx + 14, y - 77, 24, MONO, BG, a=255 * a, track=3)
    text(c, line_, x + dx, y, 64, OSWALD, TXT, a=255 * a, wght=600)
    if sub: text(c, sub, x + dx + 2, y + 48, 30, OSWALD, '#B8C3CF', a=230 * a, wght=400)

def name_tag(c, t, t0, t1, name, role, note=None, x=1180, y=520):
    """a person's name beside their photo"""
    a = fade(t, t0, t1, .5, .5)
    if a <= 0: return
    u = ease_out(K(t, t0, .7))
    c.drawRect(skia.Rect(x - 30, y - 120, x - 22, y + 110 * u), fp(GREEN, 255 * a))
    size = 140
    while tw(name.upper(), size, BEBAS, 2) > W - x - 60: size -= 6
    text(c, name.upper(), x, y, size, BEBAS, TXT, a=255 * a, track=2, shadow=.6)
    text(c, role, x + 4, y + 58, 40, OSWALD, '#C9D3DD', a=255 * a, wght=500, shadow=.5)
    if note: text(c, note, x + 4, y + 104, 24, MONO, MUTED, a=230 * a)

def year_badge(c, t, t0, t1, year, sub=None, x=96, y=120):
    """top-left mono year pill (year can be fn(t) -> number for a rolling year)"""
    a = fade(t, t0, t1, .45, .45)
    if a <= 0: return
    s = str(int(round(year(t)))) if callable(year) else str(year)
    w = tw(s, 54, MONO) + 50
    c.drawRoundRect(skia.Rect(x, y - 58, x + w, y + 18), 10, 10, fp(PANEL, 230 * a)); c.drawRoundRect(skia.Rect(x, y - 58, x + w, y + 18), 10, 10, line(2, GREEN, 200 * a))
    c.drawCircle(x + 20, y - 20, 6, fp(GREEN if int(t * 2) % 2 else '#1E7A4C', 255 * a))
    text(c, s, x + 36, y, 54, MONO, TXT, a=255 * a)
    if sub: text(c, sub.upper(), x + w + 22, y - 8, 30, OSWALD, '#C9D3DD', a=255 * a, track=3, wght=500, shadow=.6)

def stamp(c, t, t0, word, h=RED, x=W / 2, y=H / 2 + 60, size=170, t1=None, rot=-6):
    """a word slammed onto the frame (BANKRUPT, SOLD, CLOSED). Logs a thud."""
    if t < t0 or (t1 is not None and t > t1 + .3): return
    if abs(t - t0) < 1 / FPS: sfx('thud', t0)
    u = K(t, t0, .22); a = min(1, u * 2) * (1 - (K(t, t1, .3) if t1 else 0)); s = 1.7 - .7 * ease_out(u)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    w = tw(word, size, BEBAS, 6) + 70
    c.drawRect(skia.Rect(-w / 2, -size * .82, w / 2, size * .22), line(10, h, 235 * a))
    text(c, word, 0, 0, size, BEBAS, h, 'center', 235 * a, 6)
    c.restore()

def ticker(c, t, t0, t1, items, speed=120, y=H - 46):
    """scrolling ticker tape along the bottom. items: [('BLOCKBUSTER STORES', '9,000', GREEN), ...]"""
    a = fade(t, t0, t1, .5, .5)
    if a <= 0: return
    c.drawRect(skia.Rect(0, y - 40, W, y + 22), fp('#05080B', 235 * a)); c.drawLine(0, y - 40, W, y - 40, line(1.5, GREEN, 160 * a))
    seg = []
    for k, v, h in items: seg.append((k + '  ', MUTED, None)); seg.append((v + '  ', h, 'up' if h == GREEN else 'down' if h == RED else None)); seg.append(('      ', GRID, None))
    total = sum(tw(s, 26, MONO) + (26 if arr else 0) for s, _, arr in seg); x = -((t - t0) * speed % total)
    while x < W:
        for s, h, arr in seg:
            text(c, s, x, y, 26, MONO, h, a=255 * a); x += tw(s, 26, MONO)
            if arr:
                p = skia.Path(); yy = y - 10
                if arr == 'up': p.moveTo(x - 6, yy + 7); p.lineTo(x + 6, yy + 7); p.lineTo(x, yy - 5)
                else: p.moveTo(x - 6, yy - 5); p.lineTo(x + 6, yy - 5); p.lineTo(x, yy + 7)
                p.close(); c.drawPath(p, fp(h, 255 * a)); x += 26

def quote(c, t, t0, t1, words, who, src=None):
    """a real quote, centred, with who said it and where (never invent quotes)"""
    a = fade(t, t0, t1, .5, .5)
    if a <= 0: return
    c.drawRect(skia.Rect(0, 0, W, H), fp('#000000', 150 * a))
    text(c, '“', W / 2, 360, 220, BEBAS, GREEN, 'center', 255 * a)
    lines = _wrap(words, 70, OSWALD, W - 360, 500)
    for i, ln in enumerate(lines): text(c, ln, W / 2, 470 + i * 88, 70, OSWALD, TXT, 'center', 255 * a, wght=500)
    yy = 470 + len(lines) * 88 + 30
    text(c, '— ' + who, W / 2, yy, 36, OSWALD, GREEN, 'center', 255 * a, wght=600)
    if src: text(c, src, W / 2, yy + 46, 24, MONO, MUTED, 'center', 230 * a)

def credit_line(c, t, t0, t1, s):
    """small photo credit bottom-right (every photo needs one)"""
    a = fade(t, t0, t1, .4, .4)
    if a > 0: text(c, s, W - 40, H - 30, 20, MONO, '#AEB8C2', 'right', 210 * a, shadow=.8)

def title_card(c, t, t0, t1, small, big, sub=None):
    a = fade(t, t0, t1, .6, .6)
    if a <= 0: return
    c.drawRect(skia.Rect(0, 0, W, H), fp(BG, 200 * a))
    u = ease_out(K(t, t0, .9))
    text(c, small.upper(), W / 2, 400, 40, MONO, GREEN, 'center', 255 * a, 10)
    size = 260
    while tw(big.upper(), size, BEBAS, 8) > W - 160: size -= 10
    text(c, big.upper(), W / 2, 400 + size * .95, size, BEBAS, TXT, 'center', 255 * a, 8)
    c.drawLine(W / 2 - 300 * u, 400 + size * 1.05, W / 2 + 300 * u, 400 + size * 1.05, line(4, GREEN, 255 * a))
    if sub: text(c, sub, W / 2, 400 + size * 1.05 + 70, 40, OSWALD, '#C9D3DD', 'center', 255 * a, wght=400)

def chapter_card(c, t, t0, dur, num, title, sub=None):
    """dark chapter card in the narrator's pause: CHAPTER 01 in mono, the title in Bebas, a little chart line under it"""
    a = min(1, K(t, t0, .35)) * (1 - K(t, t0 + dur - .3, .35))
    if a <= 0: return
    c.saveLayerAlpha(None, int(255 * a)); market_bg(c, t, (W / 2, H / 2), GREEN)
    u = ease_out(K(t, t0 + .05, .8))
    n = ''.join(ch for ch in num if ch.isdigit()) or num
    lab = f'CHAPTER {int(n):02d}' if n.isdigit() else num.upper()
    text(c, lab, W / 2, 400, 34, MONO, GREEN, 'center', track=10)
    size = 220
    while tw(title.upper(), size, BEBAS, 6) > W - 200: size -= 10
    text(c, title.upper(), W / 2, 420 + size * .92 - 16 * (1 - u), size, BEBAS, TXT, 'center', track=6)
    r = random.Random(len(title)); pts = []; v = .5
    for k in range(40): v = min(.95, max(.05, v + r.uniform(-.16, .16))); pts.append((W / 2 - 360 + k * 18.5, 700 + v * 60))
    p = skia.Path(); p.moveTo(*pts[0])
    for q in pts[1:max(2, int(len(pts) * u))]: p.lineTo(*q)
    c.drawPath(p, line(3, GREEN, 230))
    if sub: text(c, sub, W / 2, 840, 40, OSWALD, '#C9D3DD', 'center', wght=400)
    finish(c, t); c.restore()

def _wrap(s, size, tf, maxw, wght=None):
    out, cur = [], ''
    for w in s.split():
        q = (cur + ' ' + w).strip()
        if tw(q, size, tf, 0, wght) > maxw and cur: out.append(cur); cur = w
        else: cur = q
    if cur: out.append(cur)
    return out


# ================================================================ shot drawers
def _photo(c, s, t, e, build):
    im, fg, bg = _art(s['src'], s['depth'], build)
    fx, fy, z = [lerp(a, b, e) for a, b in zip(s['frm'], s['to'])]
    if s.get('card'):
        market_bg(c, t)
        iw, ih = im.width(), im.height(); maxw, maxh = W * .62, H * .66; sc = min(maxw / iw, maxh / ih) * z
        ww, hh = iw * sc, ih * sc; x = W * s['card'] - ww / 2 + (fx - .5) * 30; y = H / 2 - hh / 2 - 20
        c.drawRect(skia.Rect(x + 16, y + 22, x + ww + 16, y + hh + 22), fp('#000000', 150, 30))
        c.drawRect(skia.Rect(x - 10, y - 10, x + ww + 10, y + hh + 10), fp('#E9EEF2'))
        p = skia.Paint(); p.setColorFilter(_GRADE)
        c.drawImageRect(im, skia.Rect(x, y, x + ww, y + hh), skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear), p)
        if s.get('label'): text(c, s['label'].upper(), x, y + hh + 56, 26, MONO, GREEN, track=3)
        return
    gp = skia.Paint(); gp.setColorFilter(_GRADE); c.saveLayer(None, gp)
    if fg is not None:
        cx, cy, ww, wh = _window(bg, fx, fy, z); _blit(c, bg, cx, cy, ww, wh)
        k = 1 + .045 * e; _blit(c, fg, cx + ww * .012 * e, cy, ww / k, wh / k)
    else:
        cx, cy, ww, wh = _window(im, fx, fy, z); _blit(c, im, cx, cy, ww, wh)
    c.restore()
    # cool shadows: draw a cool shadow tint and a soft top/bottom fade toward the background colour
    c.drawRect(skia.Rect(0, 0, W, H), fp('#0A1A22', 38))
    sh = skia.GradientShader.MakeLinear([(0, 0), (0, H)], [col(BG, 120), col(BG, 0), col(BG, 0), col(BG, 150)], [0, .22, .7, 1])
    q = skia.Paint(); q.setShader(sh); c.drawRect(skia.Rect(0, 0, W, H), q)

def _chart(c, s, t):
    market_bg(c, t)
    pts, t0, dur = s['pts'], s['t0'], s['dur']
    x0, x1, y0, y1 = 220, W - 200, 250, H - 210
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    xmin, xmax = min(xs), max(xs); ymin = s.get('ymin', 0 if min(ys) >= 0 else min(ys)); ymax = s.get('ymax', max(ys) * 1.15)
    X = lambda v: x0 + (x1 - x0) * (v - xmin) / max(xmax - xmin, 1e-9); Y = lambda v: y1 - (y1 - y0) * (v - ymin) / max(ymax - ymin, 1e-9)
    u = ease(K(t, t0 + .4, dur)); xh = xmin + (xmax - xmin) * u
    # axes and labels
    a0 = K(t, t0, .4)
    text(c, s['title'].upper(), x0, 170, 64, BEBAS, TXT, a=255 * a0, track=3)
    if s.get('sub'): text(c, s['sub'], x0 + tw(s['title'].upper(), 64, BEBAS, 3) + 30, 166, 30, OSWALD, MUTED, a=255 * a0, wght=400)
    for k in range(5):
        v = ymin + (ymax - ymin) * k / 4; yy = Y(v)
        c.drawLine(x0, yy, x1, yy, line(1, '#253241', 200 * a0))
        text(c, s['fmt'](v), x0 - 24, yy + 10, 26, MONO, MUTED, 'right', 230 * a0)
    for v in s['xticks']: text(c, str(v), X(v), y1 + 52, 26, MONO, MUTED, 'center', 230 * a0)
    # the line up to the head, red after crash_from
    seg = []; prev = None
    for i in range(len(pts) - 1):
        (xa, ya), (xb, yb) = pts[i], pts[i + 1]
        if xa >= xh: break
        f = min(1, (xh - xa) / max(xb - xa, 1e-9)); seg.append(((xa, ya), (xa + (xb - xa) * f, ya + (yb - ya) * f)))
    cf = s.get('crash_from')
    if seg:
        area = skia.Path(); area.moveTo(X(seg[0][0][0]), y1)
        for (pa, pb) in seg: area.lineTo(X(pa[0]), Y(pa[1])); area.lineTo(X(pb[0]), Y(pb[1]))
        area.lineTo(X(seg[-1][1][0]), y1); area.close()
        hc = RED if cf is not None and xh > cf else s['color']
        sh = skia.GradientShader.MakeLinear([(0, y0), (0, y1)], [col(hc, 70), col(hc, 0)]); pa_ = skia.Paint(AntiAlias=True); pa_.setShader(sh); c.drawPath(area, pa_)
        for (pa, pb) in seg:
            h = RED if cf is not None and pa[0] >= cf else s['color']
            c.drawLine(X(pa[0]), Y(pa[1]), X(pb[0]), Y(pb[1]), glow(h, 120, 10)); c.drawLine(X(pa[0]), Y(pa[1]), X(pb[0]), Y(pb[1]), line(6, h))
        hx_, hy_ = seg[-1][1]; hc = RED if cf is not None and hx_ > cf else s['color']
        c.drawCircle(X(hx_), Y(hy_), 18, fp(hc, 90, 8)); c.drawCircle(X(hx_), Y(hy_), 9, fp(TXT))
        lab = s['fmt'](hy_); lw = tw(lab, 40, MONO) + 30; lx = min(X(hx_) + 26, x1 - lw + 60)
        c.drawRoundRect(skia.Rect(lx, Y(hy_) - 68, lx + lw, Y(hy_) - 18), 8, 8, fp(hc, 235)); text(c, lab, lx + 15, Y(hy_) - 30, 40, MONO, BG)
    # event markers appear as the head passes them
    for i, (ev, lab) in enumerate(s.get('events', [])):
        if xh < ev: continue
        b = K(xh, ev, (xmax - xmin) * .04 + 1e-9); yv = next(pp[1] for pp in pts if pp[0] >= ev) if ev <= xmax else pts[-1][1]
        xx = X(ev); c.drawLine(xx, Y(yv) + 16, xx, y1, line(2, GOLD, 160 * b))
        ty = Y(yv) - 110 - (i % 2) * 70
        text(c, lab, xx, ty, 32, OSWALD, GOLD, 'center', 255 * b, wght=600, shadow=.7)

def _number(c, s, t):
    market_bg(c, t, (W / 2, H / 2), s['color'])
    u = ease_out(K(t, s['t0'] + .25, s['dur'])); v = s['v0'] + (s['value'] - s['v0']) * u
    a = K(t, s['t0'], .3)
    if s.get('label'): text(c, s['label'].upper(), W / 2, 380, 40, MONO, s['color'], 'center', 255 * a, 8)
    txt = money(v, s['prefix'], s['decimals']) + s['suffix']
    size = 230
    while tw(txt, size, BEBAS, 4) > W - 160: size -= 8
    if u < 1 and int(t * FPS) % 2 == 0: sfx('tick', t)
    text(c, txt, W / 2, 560 + size * .35, size, BEBAS, TXT, 'center', 255 * a, 4)
    if s.get('sub'):
        b = K(t, s['t0'] + .25 + s['dur'], .4)
        text(c, s['sub'], W / 2, 760, 46, OSWALD, '#C9D3DD', 'center', 255 * b, wght=400)

def _bars(c, s, t):
    market_bg(c, t)
    items = s['items']; vmax = max(v for _, v, _ in items) or 1; x0 = 560; x1 = W - 260
    text(c, s['title'].upper(), 200, 220, 64, BEBAS, TXT, a=255 * K(t, s['t0'], .4), track=3)
    n = len(items); gap = min(150, (H - 420) / n)
    for i, (name, v, h) in enumerate(items):
        b0 = s['t0'] + .3 + i * s['stagger']; u = ease_out(K(t, b0, 1.0)); a = K(t, b0, .3); y = 330 + i * gap
        text(c, name.upper(), x0 - 34, y + 44, 48, BEBAS, TXT, 'right', 255 * a, 2)
        c.drawRoundRect(skia.Rect(x0, y, x1, y + 64), 8, 8, fp(PANEL, 255 * a))
        ww = (x1 - x0) * (v / vmax) * u
        if ww > 2: c.drawRoundRect(skia.Rect(x0, y, x0 + ww, y + 64), 8, 8, fp(h, 255 * a)); c.drawRoundRect(skia.Rect(x0, y, x0 + ww, y + 64), 8, 8, glow(h, 60 * a, 14))
        text(c, s['fmt'](v * u), x0 + max(ww, 0) + 22, y + 46, 40, MONO, TXT, a=255 * a)

def _versus(c, s, t):
    market_bg(c, t, (W / 2, H / 2), GOLD)
    u = ease_out(K(t, s['t0'], .7))
    for side, (name, big, sub, h) in ((0, s['left']), (1, s['right'])):
        cx = W * (.27 if side == 0 else .73) + (1 - u) * (-80 if side == 0 else 80); a = K(t, s['t0'] + side * s['delay'], .4)
        c.drawRoundRect(skia.Rect(cx - 380, 270, cx + 380, 830), 22, 22, fp(PANEL, 235 * a)); c.drawRoundRect(skia.Rect(cx - 380, 270, cx + 380, 830), 22, 22, line(3, h, 220 * a))
        text(c, name.upper(), cx, 380, 58, BEBAS, h, 'center', 255 * a, 6)
        size = 220
        while tw(big, size, BEBAS, 2) > 680: size -= 10
        text(c, big, cx, 610, size, BEBAS, TXT, 'center', 255 * a, 2)
        text(c, sub, cx, 730, 38, OSWALD, '#C9D3DD', 'center', 255 * a, wght=400)
    b = K(t, s['t0'] + .5, .4)
    c.drawCircle(W / 2, 550, 60, fp(BG, 255 * b)); c.drawCircle(W / 2, 550, 60, line(3, GOLD, 255 * b)); text(c, 'VS', W / 2, 570, 54, BEBAS, GOLD, 'center', 255 * b, 2)

def _statement(c, s, t):
    market_bg(c, t, (W / 2, H / 2), s['color'])
    a = K(t, s['t0'], .35); u = ease_out(K(t, s['t0'], .6))
    lines = _wrap(s['line'].upper(), s['size'], BEBAS, W - 260)
    y = H / 2 + 40 - (len(lines) - 1) * s['size'] * .5
    for i, ln in enumerate(lines): text(c, ln, W / 2, y + i * s['size'] * .98 + 20 * (1 - u), s['size'], BEBAS, TXT, 'center', 255 * a, 4)
    c.drawLine(W / 2 - 220 * u, y + (len(lines) - 1) * s['size'] * .98 + 50, W / 2 + 220 * u, y + (len(lines) - 1) * s['size'] * .98 + 50, line(5, s['color'], 255 * a))
    if s.get('sub'): text(c, s['sub'], W / 2, y + (len(lines) - 1) * s['size'] * .98 + 130, 44, OSWALD, '#C9D3DD', 'center', 255 * a, wght=400)


# ================================================================ the timeline of shots
class Fin(_doc.Doc):
    """Shots in time order with quick crossfades. Same interface as Doc (film.py renders it in parallel chunks)."""
    def __init__(self, film, xfade=.45, chapter_subs=None):
        super().__init__(film, xfade=xfade, chapter_subs=chapter_subs)

    def photo(self, t0, src, frm=(.5, .5, 1.0), to=None, depth=False, card=None, label=None):
        """a real photo. Full screen with a slow push (frm/to = (focus x, focus y, zoom)), or card=x (0..1) to show it whole
        on a floating white card over the dark background (logos on signs, documents, screenshots of filings), with a label."""
        to = to or (frm[0], frm[1], frm[2] * 1.08)
        self._add(t0, 'photo', src=os.path.join(self.film.dir, src), frm=frm, to=to, depth=depth, card=card, label=label)

    def chart(self, t0, pts, title, fmt=lambda v: short(v * 1e9), xticks=None, events=(), crash_from=None, color=GREEN, dur=3.5, sub=None, ymin=None, ymax=None):
        """a line chart that draws itself over dur seconds. pts: [(year, value), ...]; fmt(value) -> label;
        events: [(year, 'Netflix launches')]; crash_from: year after which the line turns red."""
        kw = dict(pts=pts, title=title, fmt=fmt, xticks=xticks or [p[0] for p in pts], events=events, crash_from=crash_from, color=color, dur=dur, sub=sub)
        if ymin is not None: kw['ymin'] = ymin
        if ymax is not None: kw['ymax'] = ymax
        self._add(t0, 'chart', **kw)

    def number(self, t0, value, prefix='$', suffix='', label=None, sub=None, dur=1.6, v0=0, decimals=0, color=GREEN):
        """a big counter rolling up (or down, with v0 > value) to value"""
        self._add(t0, 'number', value=value, prefix=prefix, suffix=suffix, label=label, sub=sub, dur=dur, v0=v0, decimals=decimals, color=color)

    def bars(self, t0, items, title, fmt=lambda v: f'{v:,.0f}', stagger=.5):
        """horizontal bars growing one after another. items: [('Blockbuster', 9000, GREEN), ...]"""
        self._add(t0, 'bars', items=items, title=title, fmt=fmt, stagger=stagger)

    def versus(self, t0, left, right, delay=.6):
        """split screen: left/right = ('NETFLIX', '$50M', 'asking price', RED)"""
        self._add(t0, 'versus', left=left, right=right, delay=delay)

    def statement(self, t0, line_, sub=None, color=GREEN, size=180):
        """one big line in capitals (the key idea of a paragraph)"""
        self._add(t0, 'statement', line=line_, sub=sub, color=color, size=size)

    def scene(self, t0, fn):
        """fn(c, t, u): draw anything on the 1920x1080 frame over the dark background"""
        self._add(t0, 'scene', fn=fn, paper=False)

    def _draw_shot(self, c, i, t):
        s = self.shots[i]; t0, t1 = s['t0'], self._end(i) + self.xf; u = max(0, min(1, (t - t0) / max(t1 - t0, .01))); e = ease(u) * .85 + u * .15
        k = s['kind']
        if k == 'photo': _photo(c, s, t, e, self.film.build)
        elif k == 'chart': _chart(c, s, t)
        elif k == 'number': _number(c, s, t)
        elif k == 'bars': _bars(c, s, t)
        elif k == 'versus': _versus(c, s, t)
        elif k == 'statement': _statement(c, s, t)
        else: market_bg(c, t); s['fn'](c, t, u)

    def draw(self, c, t, f, view):
        c.clear(col(BG)); i = max([k for k, s in enumerate(self.shots) if s['t0'] <= t] or [0])
        if i > 0 and t < self.shots[i]['t0'] + self.xf:
            self._draw_shot(c, i - 1, t)
            c.saveLayerAlpha(None, int(255 * ease(K(t, self.shots[i]['t0'], self.xf)))); self._draw_shot(c, i, t); c.restore()
        else: self._draw_shot(c, i, t)
        finish(c, t)

    @property
    def over(self):
        def chap(c, t):
            for ch in self.film.chapters: chapter_card(c, t, ch[0] + .05, ch[3] + .25, ch[1], ch[2], self.chapter_subs.get(ch[2]))
        return [lambda c, t: [o(c, t) for o in self._screen], chap]
