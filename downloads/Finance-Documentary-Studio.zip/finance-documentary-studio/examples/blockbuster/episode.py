"""How Blockbuster lost to Netflix: 70-second preview in the finance look."""
import sys, os
ENGINE = os.environ.get('FDS_ENGINE', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'engine'))
sys.path.insert(0, ENGINE)
from fin import *

film = Film(__file__, vo='vo.wav', words='words.json', mood='money')
T = film.cue
D = os.path.dirname(os.path.abspath(__file__))
def cr(f):
    """the credit line saved next to a photo by scripts/photos.py"""
    p = os.path.join(D, 'media', f + '.credit.txt')
    return ('Photo: ' + open(p, encoding='utf-8').read().splitlines()[0]) if os.path.exists(p) else ''

fin = Fin(film, chapter_subs={'THE GOLD RUSH': 'Dallas, 1985'})
film.music = {'hits': [T('bankrupt') - .05, T('lost to')]}

# ---------------------------------------------------------------- cold open: the offer
fin.photo(0, 'media/netflix_envelope.jpg', card=.5, label='Netflix, 2000: DVDs by mail', frm=(.5, .5, 1.0), to=(.5, .5, 1.06))
fin.photo(T('two men') - .1, 'media/hastings.jpg', frm=(.64, .36, 1.05), to=(.62, .34, 1.2))
fin.photo(T('flew to') - .1, 'media/dallas.jpg', frm=(.45, .55, 1.1), to=(.5, .5, 1.3))
fin.number(T('For') - .1, 50_000_000, label='The price of Netflix', sub='the whole company', dur=1.3, color=GOLD)
fin.photo(T('The company was') - .2, 'media/netflix_envelope.jpg', frm=(.5, .45, 1.35), to=(.52, .45, 1.6))
fin.statement(T("Blockbuster's CEO") - .2, 'Trying not to laugh', sub="Blockbuster's CEO, as Netflix co-founder Marc Randolph remembers it", color=GOLD, size=170)

# ---------------------------------------------------------------- the empire
fin.photo(T('At its peak') - .2, 'media/anchorage.jpg', frm=(.5, .55, 1.0), to=(.5, .45, 1.25))
fin.photo(T('had more than') - .1, 'media/rockhampton.jpg', frm=(.5, .4, 1.05), to=(.48, .36, 1.2))
fin.number(T('made around') - .2, 6_100_000_000, label='Revenue, 2004', sub='one year of rentals', dur=1.3)
fin.number(T('In 2000 alone') - .1, 800_000_000, label='Late fees, 2000', sub='paid by people who returned a tape late', dur=1.6, color=GOLD)

# ---------------------------------------------------------------- the fall
REV = [(2000, 4.96), (2001, 5.16), (2002, 5.57), (2003, 5.91), (2004, 6.05), (2005, 5.72), (2006, 5.52), (2007, 5.54), (2008, 5.29), (2010, 3.24)]
fin.chart(T('years later') - .5, REV, 'Blockbuster revenue', sub='billions of dollars a year', fmt=lambda v: f'${v:.1f}B',
          xticks=[2000, 2002, 2004, 2006, 2008, 2010], events=[(2004, 'The peak')], crash_from=2004, dur=1.9, ymin=0, ymax=7)
fin.photo(T('Today') - .2, 'media/bend.jpg', frm=(.72, .28, 1.7), to=(.7, .27, 1.95))
fin.versus(T('This is how') - .1, ('Blockbuster', '$6B', 'a year in revenue', BLUE), ('Netflix', '$50M', 'the price they said no to', RED), delay=1.0)

# ---------------------------------------------------------------- chapter one: the gold rush
fin.photo(film.chapter_at('THE GOLD RUSH') + 1.6, 'media/dallas.jpg', frm=(.6, .5, 1.0), to=(.55, .5, 1.15))
fin.statement(T('A software guy') - .2, 'David Cook', sub='He ran a software company for oil and gas firms', color=CYAN, size=200)
fin.number(T('opened a video') + .3, 8000, prefix='', label='Tapes on day one', sub='more than any video store in town', dur=1.0, color=CYAN)
fin.photo(T('bright lights') - .2, 'media/anchorage.jpg', frm=(.5, .3, 1.1), to=(.5, .6, 1.3))
fin.photo(T('People lined') - .2, 'media/bend_inside.jpg', frm=(.4, .5, 1.0), to=(.6, .5, 1.15))
fin.chart(T('A few years later') - .2, [(1985, 1), (1988, 400), (2003, 8867), (2004, 9094)], 'Blockbuster stores', sub='worldwide, end of year',
          fmt=lambda v: f'{v:,.0f}', xticks=[1985, 1990, 1995, 2000, 2004], events=[(1988, '400 stores')], dur=3.0, color=CYAN, ymin=0, ymax=10000)


@fin.screen
def words(c, t):
    year_badge(c, t, .2, T('For') - .4, 2000, 'Two men, one offer')
    credit_line(c, t, 0, T('two men') - .3, cr('netflix_envelope.jpg'))
    name_tag(c, t, T('two men') + .3, T('flew to') - .3, 'Reed Hastings', 'Netflix co-founder', cr('hastings.jpg'), x=120, y=560)
    tag(c, t, T('Dallas') - .2, T('For') - .4, 'Dallas, Texas', "Blockbuster's headquarters", 'The meeting')
    credit_line(c, t, T('flew to'), T('For') - .4, cr('dallas.jpg'))
    credit_line(c, t, T('The company was'), T("Blockbuster's CEO") - .4, cr('netflix_envelope.jpg'))
    stamp(c, t, T('no', after=T('answer')), 'NO', RED, y=H - 140, size=200, t1=T('At its peak') - .3)
    year_badge(c, t, T('At its peak'), T('made around') - .4, 2004, 'The peak')
    credit_line(c, t, T('At its peak'), T('had more than') - .3, cr('anchorage.jpg'))
    tag(c, t, T('had more than') + .2, T('made around') - .4, 'More than 9,000 stores', '84,300 employees worldwide, 2004', 'At the peak')
    credit_line(c, t, T('had more than'), T('made around') - .4, cr('rockhampton.jpg'))
    ticker(c, t, T('made around') - .2, T('years later') - .6, [('STORES', '9,094', GREEN), ('EMPLOYEES', '84,300', GREEN), ('REVENUE 2004', '$6.1B', GREEN), ('LATE FEES 2000', '$800M', GOLD)])
    stamp(c, t, T('bankrupt'), 'BANKRUPT', RED, y=H / 2 + 120, t1=T('Today') - .3)
    tag(c, t, T('Today') + .1, T('This is how') - .4, 'Bend, Oregon', 'The last Blockbuster on Earth', 'Still open')
    credit_line(c, t, T('Today'), T('This is how') - .4, cr('bend.jpg'))
    year_badge(c, t, film.chapter_at('THE GOLD RUSH') + 2.2, T('A software guy') - .4, 1985, 'October 19')
    tag(c, t, T('Dallas', after=40) - .2, T('A software guy') - .4, 'Dallas, Texas', 'The first Blockbuster opens', 'Where it started')
    credit_line(c, t, film.chapter_at('THE GOLD RUSH') + 1.6, T('A software guy') - .4, cr('dallas.jpg'))
    credit_line(c, t, T('bright lights'), T('People lined') - .3, cr('anchorage.jpg'))
    tag(c, t, T('People lined') + .1, T('A few years later') - .4, 'Lines around the block', 'the late 1980s', 'The boom')
    credit_line(c, t, T('People lined'), T('A few years later') - .4, cr('bend_inside.jpg'))


fin.render()
film.main()
