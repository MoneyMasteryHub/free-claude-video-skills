"""Blockbuster, the vertical Short (1080x1920): its own 38-second script, made for Shorts / Reels / TikTok.
Same engine as the long film; FDS_VERTICAL=1 switches every shot to a 9:16 layout with big word-by-word captions."""
import sys, os
os.environ['FDS_VERTICAL'] = '1'                       # must come before the engine import
ENGINE = os.environ.get('FDS_ENGINE', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'engine'))
sys.path.insert(0, ENGINE)
from fin import *

film = Film(__file__, vo='vo.wav', words='words.json', mood='money')
T = film.cue
D = os.path.dirname(os.path.abspath(__file__))
def cr(f):
    p = os.path.join(D, '..', 'media', f + '.credit.txt')
    return ('Photo: ' + open(p, encoding='utf-8').read().splitlines()[0]) if os.path.exists(p) else ''

fin = Fin(film, xfade=.18, thriller=False)            # Shorts: fast cuts, captions on by default
film.music = {'hits': [T('bankrupt'), T('no', after=T('answer'))]}
REV = [(2000, 4.96), (2001, 5.16), (2002, 5.57), (2003, 5.91), (2004, 6.05), (2005, 5.72), (2006, 5.52), (2007, 5.54), (2008, 5.29), (2010, 3.24)]

fin.photo(0, '../media/miami_closing.jpg', frm=(.3, .45, 1.0), to=(.32, .45, 1.12))
fin.photo(T('Netflix') - .05, '../media/netflix_envelope.jpg', card=.5, label='Netflix, 2000', frm=(.5, .5, 1.0), to=(.5, .5, 1.06))
fin.number(T('50') - .1, 50_000_000, label='The asking price', dur=.8, color=GOLD)
fin.statement(T('In 2000') - .1, '2000', sub='Netflix is a tiny website', color=CYAN, size=320)
fin.statement(T('losing money') - .1, 'Losing money', color=RED, size=220)
fin.photo(T('It mailed') - .1, '../media/netflix_envelope.jpg', frm=(.4, .5, 1.0), to=(.46, .5, 1.15))
fin.photo(T('Its founders') - .1, '../media/hastings.jpg', frm=(.62, .4, 1.0), to=(.62, .38, 1.1))
fin.photo(T('offered') - .2, '../media/dallas.jpg', frm=(.5, .5, 1.0), to=(.55, .5, 1.12))
fin.versus(T('50', after=T('Blockbuster')) - .2, ('Netflix', '$50M', 'the asking price', RED), ('Blockbuster', '$4.96B', 'revenue in 2000', BLUE), delay=.35)
fin.clipping(T('Blockbuster made') - .1, outlet='Mental Floss', headline='15 Fast-Forward Facts About Blockbuster Video',
             body='In 2000, $800 million, or 16 percent of total revenue, came from fines.',
             phrase='$800 million, or 16 percent of total revenue, came from fines.', at=T('much'), dur=1.3, source='mentalfloss.com')
fin.statement(T('about three') - .2, '3 weeks', sub="of Blockbuster's late fees", color=GOLD, size=300)
fin.statement(T("Blockbuster's CEO") - .1, 'Trying not to laugh', sub="Blockbuster's CEO, as Netflix co-founder Marc Randolph remembers it", color=GOLD, size=200)
fin.chart(T('Ten years') - .1, REV, 'Blockbuster revenue', sub='billions of dollars a year', fmt=lambda v: f'${v:.1f}B',
          xticks=[2000, 2002, 2004, 2006, 2008, 2010], crash_from=2004, dur=1.5, ymin=0, ymax=7)
fin.photo(T('Today') - .15, '../media/bend.jpg', frm=(.7, .4, 1.0), to=(.7, .38, 1.12))
fin.number(T('All because') - .1, 50_000_000, label='The price of saying no', dur=.9, color=RED)

@fin.screen
def words(c, t):
    credit_line(c, t, 0, T('Netflix') - .1, cr('miami_closing.jpg'))
    credit_line(c, t, T('Netflix'), T('50') - .2, cr('netflix_envelope.jpg'))
    credit_line(c, t, T('It mailed'), T('Its founders') - .2, cr('netflix_envelope.jpg'))
    name_tag(c, t, T('Its founders') + .2, T('offered') - .3, 'Reed Hastings', 'Netflix co-founder')
    credit_line(c, t, T('Its founders'), T('offered') - .3, cr('hastings.jpg'))
    tag(c, t, T('offered') - .1, T('50', after=T('Blockbuster')) - .3, 'Dallas, Texas', 'Blockbuster headquarters', 'The offer')
    credit_line(c, t, T('offered'), T('50', after=T('Blockbuster')) - .3, cr('dallas.jpg'))
    stamp(c, t, T('no', after=T('answer')), 'NO', RED, y=CY + 330, size=200, t1=T('Ten years') - .2)
    stamp(c, t, T('bankrupt'), 'BANKRUPT', RED, y=CY + 120, size=150, t1=T('Today') - .2)
    tag(c, t, T('Today'), T('All because') - .2, 'Bend, Oregon', 'The last Blockbuster on Earth', 'Still open')
    credit_line(c, t, T('Today'), T('All because') - .2, cr('bend.jpg'))
    end_card(c, t, T('All because') + .9, film.end_time + 1)

fin.render()
film.main()
