# The finance look: episode file reference

    from fin import *
    film = Film(__file__, vo='vo.wav', words='words.json', mood='money')
    T = film.cue                    # T('phrase') -> time the phrase starts; T('no', after=T('answer')); film.end('phrase')
    fin = Fin(film, chapter_subs={'THE GOLD RUSH': 'Dallas, 1985'})
    film.music = {'hits': [T('bankrupt')]}           # optional: risers into impacts at these times; 'drops': [(a, b)] near silence

Shots follow each other with quick crossfades (0.45 s). Each starts at its time and lasts until the next one.

| Shot | Use it for | Call |
|---|---|---|
| photo | a real place, product, person, store | `fin.photo(t, 'media/x.jpg', frm=(fx, fy, zoom), to=(fx, fy, zoom))` slow push; `card=.5, label='Netflix, 2000'` shows it whole on a white card |
| chart | anything over time (revenue, stores, share price) | `fin.chart(t, [(2000, 4.96), ...], 'Revenue', sub='billions a year', fmt=lambda v: f'${v:.1f}B', events=[(2004, 'The peak')], crash_from=2004, dur=2.5)` |
| number | one huge number | `fin.number(t, 6_100_000_000, label='Revenue, 2004', sub='one year of rentals', dur=1.3, color=GREEN)` (`prefix=''` for counts, `v0` to count down) |
| bars | comparing a few things | `fin.bars(t, [('Blockbuster', 9094, BLUE), ('Netflix', 0, RED)], 'Stores, 2004')` |
| versus | the core conflict | `fin.versus(t, ('Blockbuster', '$6B', 'a year', BLUE), ('Netflix', '$50M', 'asking price', RED))` |
| statement | the key line of a paragraph | `fin.statement(t, 'Trying not to laugh', sub='...', color=GOLD)` |
| clipping | proof: the real article, filing or press release with the key line highlighted as it's said | screenshot: `fin.clipping(t, 'media/clip_10k.png', mark=[(.08, .41, .93, .45)], at=T('six billion'), source='sec.gov', note='Form 10-K, 2004')`; no screenshot: `fin.clipping(t, outlet='Mental Floss', headline='...', body='exact published text', phrase='exact words to mark', at=T('800'), dur=2.2, source='mentalfloss.com')` |
| flash | fast montage in the cold open | `fin.flash(t, ['media/a.jpg', 'media/b.jpg'], every=.42)` |
| scene | anything custom | `fin.scene(t, fn)` with `fn(c, t, u)` drawing on 1920x1080 over the dark background |

Thriller cold open: everything before the `[TITLE: ...]` pause gets letterbox bars, hard cuts with a glitch, a red pulse on the heartbeat, and a heartbeat + ticking-clock score with a riser into the title (`Fin(film, thriller=False)` turns it off). The title card is drawn by itself in the pause.

Overlays (inside `@fin.screen def words(c, t): ...`, each with a start and end time):
- `datestamp(c, t, t0, t1, 'SEPTEMBER 23, 2010', 'BLOCKBUSTER FILES FOR BANKRUPTCY', y=...)` typed date line with a red cursor (cold open).
- `credit_line(c, t, t0, t1, 'Photo: ...')` on every photo. In the example `cr('file.jpg')` reads the saved credit.
- `tag(c, t, t0, t1, 'Dallas, Texas', 'The first store opens', 'Where it started')` lower-left tag (kind in a green pill).
- `name_tag(c, t, t0, t1, 'Reed Hastings', 'Netflix co-founder', note, x=120, y=560)` beside a person's photo.
- `year_badge(c, t, t0, t1, 2004, 'The peak')` top-left; the year can be a function of t.
- `stamp(c, t, t0, 'BANKRUPT', RED, y=..., size=..., t1=...)` slams a word on screen (adds a thud).
- `ticker(c, t, t0, t1, [('STORES', '9,094', GREEN), ('LATE FEES 2000', '$800M', GOLD)])` along the bottom (green = up arrow, red = down).
- `quote(c, t, t0, t1, 'words', 'who', 'source')` only for real, sourced quotes.
- `title_card(c, t, t0, t1, 'The rise and fall of', 'Blockbuster', sub)`.

Colours: `GREEN` growth, `RED` the fall, `GOLD` events and money facts, `BLUE` / `CYAN` the other side. Chapter cards (CHAPTER 01, title, a little chart line) come by themselves in the narrator's pauses.

Rhythm that works: photo → number → photo → chart → stamp → photo → versus. Never more than two number shots in a row; a new visual with almost every sentence; a stamp only at the one big turn of a chapter.
Text placement: tags sit bottom-left, credits bottom-right, year badges top-left; don't put a stamp on top of a statement's subtitle (use `y=H - 140`).

## Source clippings (the proof shots)
One or two per chapter, on the line that carries the chapter: the revenue in the 10-K, the bankruptcy press release, the court filing, the CEO's real quote in a newspaper. The card slides in tilted, pushes in on the marked line, and a yellow marker sweeps across it while the narrator says it (cue `at` on the first spoken word of that line, `dur` about the time it takes to say it).
- **Screenshot (best):** the user saves a screenshot of the page as `media/clip_<what>.png` (ask for it in the asset list). Run `python3 scripts/grid.py media/clip_<what>.png`, look at the `.grid.png`, and give one box per line of the passage in `mark` (fractions: x0, y0, x1, y1, with a little room above and below the letters). Check it with `stills`: the yellow must sit exactly on the words.
- **No screenshot:** give the exact published wording (`body`, copied from the page, never paraphrased) and the words to mark (`phrase`, copied exactly from `body`). The card says "quoted text, layout recreated" by itself. Keep `body` to two or three sentences.
- Always `source=` the site (sec.gov, nytimes.com) and add the clipping's quote and URL to `sources.md`. Never invent a clipping or make a screenshot of something that wasn't published.
- No tag or ticker under a clipping (the Source label sits bottom-left).
