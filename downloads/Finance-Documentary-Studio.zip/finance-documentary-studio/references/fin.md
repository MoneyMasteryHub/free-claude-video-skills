# The finance look: episode file reference

    from fin import *
    film = Film(__file__, vo='vo.wav', words='words.json', mood='money')
    T = film.cue                    # T('phrase') -> time the phrase starts; T('no', after=T('answer')); film.end('phrase')
    fin = Fin(film, chapter_subs={'THE GOLD RUSH': 'Dallas, 1985'})
    film.music = {'hits': [T('bankrupt')]}           # optional: risers into impacts at these times; 'drops': [(a, b)] near silence

Shots follow each other with quick crossfades (0.45 s). Each starts at its time and lasts until the next one.

| Shot | Use it for | Call |
|---|---|---|
| photo | a real place, product, person, store | `fin.photo(t, 'media/x.jpg', frm=(fx, fy, zoom), to=(fx, fy, zoom))` slow push; `card=.5, label='Netflix, 2000'` shows it whole on a white card |
| chart | anything over time (revenue, stores, share price) | `fin.chart(t, [(2000, 4.96), ...], 'Revenue', sub='billions a year', fmt=lambda v: f'${v:.1f}B', events=[(2004, 'The peak')], crash_from=2004, dur=2.5)` |
| number | one huge number | `fin.number(t, 6_100_000_000, label='Revenue, 2004', sub='one year of rentals', dur=1.3, color=GREEN)` (`prefix=''` for counts, `v0` to count down) |
| bars | comparing a few things | `fin.bars(t, [('Blockbuster', 9094, BLUE), ('Netflix', 0, RED)], 'Stores, 2004')` |
| versus | the core conflict | `fin.versus(t, ('Blockbuster', '$6B', 'a year', BLUE), ('Netflix', '$50M', 'asking price', RED))` |
| statement | the key line of a paragraph | `fin.statement(t, 'Trying not to laugh', sub='...', color=GOLD)` |
| scene | anything custom | `fin.scene(t, fn)` with `fn(c, t, u)` drawing on 1920x1080 over the dark background |

Overlays (inside `@fin.screen def words(c, t): ...`, each with a start and end time):
- `credit_line(c, t, t0, t1, 'Photo: ...')` on every photo. In the example `cr('file.jpg')` reads the saved credit.
- `tag(c, t, t0, t1, 'Dallas, Texas', 'The first store opens', 'Where it started')` lower-left tag (kind in a green pill).
- `name_tag(c, t, t0, t1, 'Reed Hastings', 'Netflix co-founder', note, x=120, y=560)` beside a person's photo.
- `year_badge(c, t, t0, t1, 2004, 'The peak')` top-left; the year can be a function of t.
- `stamp(c, t, t0, 'BANKRUPT', RED, y=..., size=..., t1=...)` slams a word on screen (adds a thud).
- `ticker(c, t, t0, t1, [('STORES', '9,094', GREEN), ('LATE FEES 2000', '$800M', GOLD)])` along the bottom (green = up arrow, red = down).
- `quote(c, t, t0, t1, 'words', 'who', 'source')` only for real, sourced quotes.
- `title_card(c, t, t0, t1, 'The rise and fall of', 'Blockbuster', sub)`.

Colours: `GREEN` growth, `RED` the fall, `GOLD` events and money facts, `BLUE` / `CYAN` the other side. Chapter cards (CHAPTER 01, title, a little chart line) come by themselves in the narrator's pauses.

Rhythm that works: photo → number → photo → chart → stamp → photo → versus. Never more than two number shots in a row; a new visual with almost every sentence; a stamp only at the one big turn of a chapter.
Text placement: tags sit bottom-left, credits bottom-right, year badges top-left; don't put a stamp on top of a statement's subtitle (use `y=H - 140`).
