# Script formula: finance documentaries

The viewer clicked for one question ("how did they lose?", "how do they make so much?"). Answer it at the end, but show the size of the stakes in the first 20 seconds.

## Shape (about 150 words a minute)
1. **Cold open (20 to 40 s): the decision that doomed them, or the craziest number.** Start inside one moment ("In the year 2000, two men from a tiny website flew to Dallas with an offer."). Then the peak in numbers, then the fall in one line ("Ten years later, it was bankrupt.").
2. **The promise (one line).** The whole arc, ideally with two numbers that clash: "This is how a six billion dollar empire lost to a fifty million dollar website."
3. **Chapters** with `[CHAPTER: CHAPTER ONE | THE GOLD RUSH]` on their own line: the rise, the peak, the mistake, the challenger, the fall, what happened next. Every chapter ends on a hook into the next.
4. **One number per beat.** Each number gets its own sentence so the screen can show it big. Give it a human scale: "eight hundred million dollars in late fees, from people who returned a tape late".
5. **People and decisions.** Name the people who decided (CEOs, founders), say what they decided, when, and what they knew then. No villains: explain why the decision looked smart at the time.
6. **The lesson**, said simply near the end (what the business actually depended on), then a callback to the cold open.

## Lines
- Say numbers the way people say them: "six billion dollars", "nine thousand stores", "in 2004".
- Say the source for anything surprising ("according to the company's own annual report").
- Short spoken sentences. One dry joke every two or three minutes.
- No em dashes, no "not just X but Y", no "let's dive in", no "little did they know". Run the humanizer.
- Call to action once, after the first chapter's payoff ("If you like these business stories, like the video so YouTube shows you more of them"), never at the very end.
- Nothing that sounds like investment advice. This is history, not "buy this stock".

## Chapter markers
`[CHAPTER: CHAPTER ONE | THE GOLD RUSH]`. The free voice turns it into a 2.2-second pause and saves its time in `chapters.json`. One every 2 to 3 minutes. Own voice (ElevenLabs): a 2-second pause at each marker (`<break time="2s" />`).

## Timing map for 15 minutes
0:00 cold open · 0:40 promise · 0:50 CHAPTER ONE the rise · 3:00 CHAPTER TWO the peak · 5:30 CHAPTER THREE the mistake · 8:00 CHAPTER FOUR the challenger · 10:30 CHAPTER FIVE the fall · 13:00 what happened next · 14:20 the lesson and the callback.
A preview (60 to 90 s) is the cold open, the promise and the start of chapter one.
