---
name: finance-documentary-studio
description: Makes faceless finance documentaries (the rise and fall of companies, how brands make money, scams and frauds, billionaires, bubbles and crashes) in a dark market-terminal look: finds topics people are searching for, researches real numbers from annual reports and SEC filings, writes a hook-first script, voices it free, tells it with real free photos, charts that draw themselves and turn red at the crash, big money counters, versus screens, stamps (BANKRUPT) and a ticker tape, adds an original tense score, and renders the MP4. Everything is free. Use for "finance documentary", "rise and fall of", "how X went bankrupt", "how X makes money", "business documentary", "company collapse", or when someone asks for this skill by name.
---

# Finance Documentary Studio

Turns a money story into a finished documentary (2 to 30 minutes) that looks like a streaming-service business film:
- **A thriller cold open** (about 30 seconds): letterbox bars, hard cuts with a glitch on every cut, a red pulse on a heartbeat, a ticking clock, a typed date line, a rewind, a fast photo montage; then a hard cut to black and the episode title slams in ("HOW BLOCKBUSTER WENT FROM / $6 BILLION TO ONE STORE"). After the title the film settles into the calm documentary look.
- **Real photos** of the stores, products, buildings and people (free licences, credited on screen), graded cool so they sit in the dark look, with a slow push. Or shown whole on a floating card (an envelope, a sign, a document).
- **Numbers that move**: line charts that draw themselves and turn red after the peak, big counters rolling up to "$6,100,000,000", horizontal bars, a VERSUS split screen, a ticker tape, year badges.
- **Type**: Bebas Neue headlines, Oswald captions, IBM Plex Mono numbers; green tags, gold events, red for the fall; BANKRUPT / SOLD / CLOSED stamps.
- **Sound**: a free narrator (Kokoro `bm_george`, British, calm) or the user's ElevenLabs MP3; an original score (synth pulse, piano, risers into impacts) that never gets a copyright claim.

The reference film is `examples/blockbuster/` (How Blockbuster went from $6 billion to one store, 75-second preview: thriller open, title, chapter one). Copy its `episode.py` for every new film. No paid tools, no AI images.

Folder map: `engine/fin.py` the finance look (start here) · `engine/film.py` cues and render · `engine/audio.py` score (mood `money`) · `scripts/voice.py` free narrator · `scripts/timestamps.py` word timings · `scripts/photos.py` free photos with credits · `references/fin.md` (read before the episode file) · `references/script.md` (read before writing) · `references/legal.md` (read before research) · `references/research.md` (topic finding, data sources) · `references/music.md`.

## Credits rule (always)
Before writing or rendering anything long, **ask how many minutes the video should be.** Always render a **60 to 90 second preview first** and the full film only after the user approves it.

## 0. Setup (do it yourself; the user never types commands)
Tell the user in one line: "Setting the studio up now. The first time takes a few minutes." Then run `bash setup.sh` (macOS/Linux) or `powershell -ExecutionPolicy Bypass -File setup.ps1` (Windows) from this folder. It installs the Python packages and ffmpeg and draws `selftest.png` (a revenue chart that crashes); look at it.
- If Python is missing, give the user the one link the script prints, wait, run it again.
- Make the project folder yourself: `~/FinanceStudio/<topic>/` with `media/` and `music/`. Copy `examples/blockbuster/episode.py` there and set `ENGINE` to this skill's `engine` folder (or the env var `FDS_ENGINE`).

## 1. Topic
Ask once whether they have a topic. If not, follow `references/research.md`: 10 ideas built on what people are watching now, each with title, the hook moment, demand proof (real numbers you saw), whether real numbers and free photos exist, sensitivity, suggested length. Never invent view counts.

## 2. Research and numbers
Follow `references/legal.md`. Build `sources.md`: every number with its source and year (annual reports, SEC 10-K filings on sec.gov EDGAR, company press releases, reputable news). Note restated figures. Mark estimates as estimates. Chart data goes into a small table in `sources.md` first.

## 3. Script
Follow `references/script.md`: a thriller cold open (the collapse, the rewind, the decision that doomed them), then the title line `[TITLE: HOW BLOCKBUSTER WENT FROM | $6 BILLION TO ONE STORE]`, then chapters with `[CHAPTER: CHAPTER ONE | THE GOLD RUSH]` markers, one number per beat, a callback ending. About 150 words a minute. Run it through the humanizer skill. Show the script and wait for the user's OK. Then write `shots.txt`: per paragraph, the photo, chart, counter or statement, and the tags.

## 4. Voice
Free narrator: `python3 scripts/voice.py script.txt vo.wav --voice bm_george` (other good voices: am_michael, am_fenrir, af_heart). If the free voice can't be installed, or the user prefers ElevenLabs, ask for an MP3 (`vo.mp3`) with a 2-second pause at each chapter marker (`<break time="2s" />`). Then `python3 scripts/timestamps.py vo.wav words.json`.

## 5. Photos and music
- Photos: `python3 scripts/photos.py search "Blockbuster store"`, `get "File:..." media/` (free licences only; the credit is saved next to the photo). Prefer stores, products, headquarters, the founders and executives (public figures, real photos only), closing-down sales. Crop out private bystanders' faces (use the push focus) and never show a private person as if they were part of the story.
- Music: the generated score is the default. A real track the user saves into `music/` replaces it (`references/music.md`).

## 6. Episode file
Read `references/fin.md`, then write `episode.py` from the Blockbuster example:
1. A shot for almost every sentence: `fin.photo`, `fin.chart`, `fin.number`, `fin.bars`, `fin.versus`, `fin.statement`, `fin.flash` (fast montage for the cold open), or `fin.scene` for anything custom (the example's `rewind`).
   The cold open needs a new shot every 1 to 3 seconds; everything before the `[TITLE: ...]` pause gets the thriller treatment by itself.
2. Never more than two number shots in a row: put a photo between them.
3. Cue everything on the voiceover's words (`T('phrase')`).
4. Overlays in `@fin.screen`: `datestamp` (typed date line) to open the film, a `credit_line` on every photo, `tag` for places and facts, `name_tag` for people, `year_badge` at time jumps, `stamp` for the big turn (BANKRUPT), `ticker` under counters.

## 7. Check, render, deliver
1. `python3 episode.py info`, then `python3 episode.py stills 2 6 12 ...` and look at every sheet: overlapping text, a number that doesn't match the script, a photo without a credit.
2. Preview first. `python3 episode.py all 2` renders, mixes and writes `<episode>_final.mp4` at -14 LUFS (70 seconds take about 4 minutes on a laptop; tell the user before starting).
3. Pull frames from the final MP4 before sending.

Deliver: the MP4, `sources.md`, `upload.md` (3 titles, a description with chapters, the photo credits, a short sources line, tags, 3 thumbnail ideas: one striking photo, a big number, 2 to 4 words).

## Bend it (other niches this skill makes)
The look is built for money stories, so it fits any channel where numbers carry the plot:
- **Company collapses**: Blockbuster, Toys"R"Us, Kodak, Nokia, WeWork, Sears.
- **How X makes money**: Costco, McDonald's real estate, Disney, the NFL.
- **Scams and frauds**: Enron, FTX, Theranos, Bernie Madoff (court records and SEC filings are free sources).
- **Billionaires and dynasties**: how a fortune was built and lost.
- **Bubbles and crashes**: tulips, the dot-com crash, 2008, meme stocks.
- **Economics of everyday things**: why a stadium hot dog costs $12, the real cost of owning a Ferrari.
Change the topic, keep the engine. For a lighter channel, change the colours at the top of `engine/fin.py`.
