"""free test voiceover (Kokoro, offline). The real MMH voice is Blaze's ElevenLabs read; use this only for tests.
python tts.py script.txt voice.wav [voice=am_michael] [speed=1.0]
needs: pip install kokoro-onnx soundfile ; model files kokoro-v1.0.onnx + voices-v1.0.bin in ~/.hds/kokoro or ~/.mmh/kokoro"""
import sys, os, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro
d = next(p for p in (os.path.expanduser('~/.entire-history-studio/kokoro'), os.path.expanduser('~/.mmh/kokoro'), os.path.expanduser('~/.hds/kokoro'), '/root/.hds/kokoro') if os.path.exists(os.path.join(p, 'kokoro-v1.0.onnx')))
k = Kokoro(os.path.join(d, 'kokoro-v1.0.onnx'), os.path.join(d, 'voices-v1.0.bin'))
voice = sys.argv[3] if len(sys.argv) > 3 else 'am_michael'; speed = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
paras = [p.strip() for p in open(sys.argv[1]).read().split('\n') if p.strip()]
parts = []
for p in paras:
    a, sr = k.create(p, voice=voice, speed=speed, lang='en-us'); parts += [a, np.zeros(int(sr * .35))]
a = np.concatenate(parts); import scipy.signal as ss; a = ss.resample_poly(a, 48000, sr)
a = a / (np.abs(a).max() + 1e-9) * .89; sf.write(sys.argv[2], np.stack([a, a], 1).astype(np.float32), 48000); print(sys.argv[2], len(a) / 48000, 's')
