"""word timings for the edit: python transcribe.py voice.wav words.json  -> [[start, end, word], ...]"""
import sys, json
from faster_whisper import WhisperModel
m = WhisperModel('small.en', device='cpu', compute_type='int8')
import soundfile as sf, numpy as np, scipy.signal as ss
a, sr = sf.read(sys.argv[1]); a = a.mean(1) if a.ndim > 1 else a
a = ss.resample_poly(a, 16000, sr).astype(np.float32)   # decode ourselves (avoids PyAV version clashes)
segs, _ = m.transcribe(a, word_timestamps=True, vad_filter=False, beam_size=5)
out = [[round(w.start, 3), round(w.end, 3), w.word.strip()] for s in segs for w in s.words]
json.dump(out, open(sys.argv[2], 'w')); print(len(out), 'words,', out[-1][1], 's')
