"""contact sheet for checking an edit: frames every STEP seconds with the words spoken at that moment.
python sheet.py video.mp4 words.json t0 t1 step out.jpg   (times are video times; words.json = voiceover timings, pass OFFSET env if the video has inserts before the voice)"""
import sys, json, subprocess, os
from PIL import Image, ImageDraw, ImageFont
v, wj, a, b, st, out = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5]), sys.argv[6]
off = float(os.environ.get('OFFSET', 0)); W = json.load(open(wj)); tiles = []
F = ImageFont.truetype(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)), '..', 'assets', 'fonts', 'Inter-SemiBold.otf'), 15)
t = a
while t <= b:
    p = f'/tmp/_sh_{t:.2f}.jpg'; subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t}', '-i', v, '-frames:v', '1', '-vf', 'scale=480:-1', p])
    im = Image.open(p).convert('RGB'); c = Image.new('RGB', (480, 270 + 46), 'white'); c.paste(im, (0, 0)); d = ImageDraw.Draw(c)
    said = ' '.join(w[2] for w in W if t - off - 1.2 <= w[0] <= t - off + .3)[-60:]
    d.text((6, 274), f'{t:6.2f}s', fill='black', font=F); d.text((6, 294), said, fill=(200, 80, 30), font=F); tiles.append(c); t += st
cols = 4; rows = (len(tiles) + cols - 1) // cols; S = Image.new('RGB', (cols * 480, rows * 316), 'white')
for i, tl in enumerate(tiles): S.paste(tl, ((i % cols) * 480, (i // cols) * 316))
S.save(out, quality=85); print(out, len(tiles), 'frames')
