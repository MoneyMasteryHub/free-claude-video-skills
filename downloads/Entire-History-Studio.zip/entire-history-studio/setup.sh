#!/bin/bash
# Entire History Studio setup (Claude runs this; the user never types commands)
set -e
cd "$(dirname "$0")"
PY=python3; command -v $PY >/dev/null || { echo "Python 3 is missing: https://www.python.org/downloads/"; exit 1; }
$PY -m pip install --quiet --upgrade skia-python numpy scipy soundfile pillow faster-whisper kokoro-onnx opencv-python-headless 2>/dev/null || \
$PY -m pip install --quiet --break-system-packages --upgrade skia-python numpy scipy soundfile pillow faster-whisper kokoro-onnx opencv-python-headless
command -v ffmpeg >/dev/null || echo "ffmpeg is missing: install it (Mac: download from evermeet.cx/ffmpeg, Windows: winget install ffmpeg)"
K="$HOME/.entire-history-studio/kokoro"; mkdir -p "$K"
B=https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0
[ -f "$K/kokoro-v1.0.onnx" ] || curl -sL -o "$K/kokoro-v1.0.onnx" $B/kokoro-v1.0.onnx
[ -f "$K/voices-v1.0.bin" ] || curl -sL -o "$K/voices-v1.0.bin" $B/voices-v1.0.bin
C="$HOME/.entire-history-studio/cache"; mkdir -p "$C"
if [ ! -f "$C/bm_world.jpg" ]; then
  echo "Downloading the satellite Earth (NASA Blue Marble, public domain, about 60 MB, once)..."
  curl -sL -A "EntireHistoryStudio/1.0 (free skill; contact via GitHub)" -o "$C/bm_src.jpg" \
    "https://commons.wikimedia.org/wiki/Special:FilePath/Whole_world_-_land_and_oceans_12000.jpg"
  $PY -c "import sys; sys.path.insert(0,'engine'); import satmap; satmap.prepare_imagery('$C/bm_src.jpg')" && rm -f "$C/bm_src.jpg"
fi
$PY -c "import sys; sys.path.insert(0,'engine'); import history, toon, satmap; print('Entire History Studio is ready.')"
