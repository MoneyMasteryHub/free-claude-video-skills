---
name: entire-history-studio
description: Makes faceless "The ENTIRE History of X" documentaries (35-60 min, or any length) in a sitcom-cartoon style: thick-outlined, big-eyed characters in era costumes acting out the story with speech bubbles, a guide character, countries as cartoon blobs, a real 3D satellite map whenever a place is named, real paintings and photos taped onto the page at every big moment, a free narrator, an epic score and a full upload pack. Works for a country, a royal dynasty, a city, a brand, a food, an invention or a secret society. Free. Use for "entire history of", "complete history of", "history of the Romanovs/Japan/Coca-Cola", "dynasty documentary", "royal family history".
---

# Entire History Studio

This skill turns any "Entire History of ___" topic into a finished documentary. It works in two modes, and you pick the mode from the topic:

- **Country mode** for countries and empires ("The Entire History of Japan").
- **Dynasty mode** for royal families ("The Entire History of the Romanovs"). Dynasty mode adds the **Bloodline**: a family line where the crown passes from ruler to ruler and murdered or overthrown rulers are struck out. It also tells succession moments second by second.
- **Any other topic** (cities, brands, foods, inventions, secret societies) uses country mode's toolkit. Use the Bloodline only if the topic has a line of owners or leaders.

The reference films are `examples/japan/` (a 30-second hook) and `examples/romanovs/` (an 80-second preview). Copy the closer one for every new film.

## The look: Sitcom Toon cartoon + satellite map + real images

The cartoon follows the Lemo-Opuscar 'Sci-Fi Sitcom Toon' grammar, with our own cast: thick near-black outlines that wobble (boil) at 12 fps and keep the same width at any zoom, flat colours with one hard shadow shape, big white eyes with tiny pupils, brows that carry the emotion, a reaction close-up after every absurd moment, and a TIME PORTAL (the only glowing thing) that whooshes the viewer between eras. Never copy any real show's characters.

Three layers take turns, and a new picture lands every 3-4 seconds:

| Layer | Where (`engine/`) | Use it for |
|---|---|---|
| **Cartoon scenes** | `toon.py`: `panel`, `room`, `outdoor`, `person`, `guide`, `blob`, `bubble`, `tag`, props (`throne`, `door`, `ship`, `house`, `monastery`) | Acting the story out. Big-eyed toon people in era costumes (`SPEC`: tsar, boyar, monk, samurai, shogun, perry, sailor, guard, maid...), speech bubbles with short jokes, name tags slapped on |
| **Guide** | `toon.guide()` | The recurring on-screen host ("Quill": red beret, round glasses, a quill as tall as a staff). Reacts, points, says the joke line. Our own design: never copy another channel's character |
| **Countries as characters** | `toon.blob(land('JPN'))` | Wars, deals and rivalries between countries: the real outline with eyes, arms and legs |
| **Satellite map** | `satmap.SatMap().draw(...)` | **Every time a place, route or link between places is named.** Real NASA Earth tilted like a camera, the country or empire filled red, glowing white routes with a little ship or rider on the tip, yellow pins, a year card counting |
| **Real images** | `toon.photo_card()` | Real paintings, prints and photos in a thick wobbly frame on a flat wall, with a caption tag, for every big moment, person and place. Name faces in group photos with red circles and tags |
| **Time portal + close-ups** | `toon.portal_wipe(c, v, CUTS)` at the end of every scene, `toon.closeup(c, x, y, zoom, shake, v)` ... `c.restore()` | Era jumps go through the portal. After a joke or shock, cut to a close-up of the face reacting |
| **Family tree line** (borrowed from Transit Map) | `toon.Bloodline(rulers).draw(c, v, t0, t1, end_t=...)` | Dynasties: one thick line through every ruler, each a little toon portrait; the crown rides the tip; killed rulers get a red X; the line ENDS at the last one. Follow the tip with `closeup`, then pull back to show the whole line |
| **Telestrator marks** (borrowed from Telestrator) | `toon.scribble_circle()`, `toon.scribble_arrow()` | Hand-drawn red loops and arrows scrawled onto real photos: name the faces, point at the detail |
| **Hard light** (borrowed from Dark Documentary) | `toon.light_cone()` | Grim moments (a cellar, a cell, a night arrest): one flat cone of light, everything else sinks into shadow. No blood, ever |
| **Title and chapter cards** | `toon.title_card()` | "THE ENTIRE HISTORY OF" + the big word slammed in on a banner. Chapter cards run as a silent hold |

Rules:
- **A map every time a place is named**, and keep it short (3-5 s). Never fake a location.
- **About a third of the film is real images**, a third cartoon, the rest maps and cards. No scene holds longer than about 4 seconds without something changing.
- **What is on screen matches the words being said at that moment.** Cue on the narrator's words.
- Jokes live in the bubbles and the guide, never in the narration of a death. For killings, wars and executions: cut to a real photo or painting, stay calm, no blood.
- Real art and photos only: public domain or free licences, credited on screen (bottom right) and in the description. Never AI images.
- The older era skins in `history.py` (engraving, newsreel, ukiyo-e scroll, Bloodline) are still there for a special chapter, but the cartoon look is the default.

## Length and preview (always)
Ask how many minutes the film should be before writing or rendering anything long. Always render a **60-90 second preview first**: the cold open, the title, a chapter card and the start of part one, showing cartoon scenes, real images and at least one map. Render the full film only after the user approves it.

## 0. Setup (Claude does it; the user never types commands)
Say in one line: "Setting the studio up now. The first time takes a few minutes." Then run `bash setup.sh` from this folder. It installs the Python packages, downloads the free narrator voice once (about 330 MB) and checks the engine. If Python or ffmpeg is missing, give the user the one link the script prints, wait, then run it again.
Make the project folder yourself: `~/HistoryStudio/<topic>/` with `media/`. Copy `examples/<closest>/edit.py` there and set `EHS_ENGINE` to this skill's `engine` folder (or edit the `ENG` line).

## 1. Topic
If the user has none, give 10 ideas built on what people are already watching, each with:
- the title
- the cold-open moment
- real demand proof (view counts you actually saw)
- how much free art and photography exists
- suggested length

Never invent numbers.

## 2. Research and sources
Write `sources.md`: every date, number, name and quote with its source. Mark legends and traditional dates as such. Where historians disagree, say so in the script.

## 3. Script
- **Cold open (20-35 s):** start on the ending or the strangest true fact. The Romanov film opens on the basement in 1918.
- **Then the promise:** "This is the entire history of ___."
- **Then the chapters:** one per era, each opened with a chapter card. Each chapter has a turn: a betrayal, a war, a death, a reform.
- **Find the hidden connection and use it.** The Romanovs began at the Ipatiev Monastery and ended in the Ipatiev House.
- **Pace:** about 145 words a minute. Run the script through the humanizer skill, show it to the user, and wait for an OK.

## 4. Voice, timings, music
- **Voice:** the default narrator is `python3 tools/tts.py script.txt vo.wav am_michael 0.92` (free and offline). If the user has an ElevenLabs voiceover, use their file instead.
- **Timings:** `python3 tools/transcribe.py vo.wav words.json`. Cue every beat on the narrator's words with `T('phrase')`.
- **Music:** the score is generated by `engine/audio.py` (`epic`, never copyright-claimed). Add hits on the title, horns on big turns, drums under wars, and drops (near silence) under the cold open.

## 5. Art
Run `python3 tools/photos.py search "..."` and `get "File:..." media/`. If Wikimedia answers "busy" (429), wait and retry. If you're connected to the user's computer, download through it with a descriptive User-Agent.
- Aim for 15-25 real images per 80 seconds.
- Show them with `photo_card` (slow push, tape, caption). For a group photo, give `photo_card` a rectangle with the image's own aspect so the face circles land on the faces.

## 6. The edit file
Register scenes with `@S(t0)`.
- Chapter cards run on their own clock as a silent hold: `SEGS = [('V', 0, t), ('H', 0, 2.8, 1000.0, 1.0), ('V', t, end)]` plus `@S(1000.0)`.
- Maps: `SM.draw(c, v, MapCam([(t, lon, lat, zoom)]), fills=[dict(year=1600, name='Tsardom of Muscovy')] or [dict(iso='JPN')], routes=[dict(pts=[...], t0, dur, icon=ship_icon())], pins=[dict(lon, lat, label, t0)], label=('caption', t0), year=(y0, y1, ta, tb))`. Historical names are as they appear in historical-basemaps for that year ('Tsardom of Muscovy' in 1600 and 1650, 'Russian Empire' in 1914). The engine downloads the borders itself.
- Cartoon scene: `panel(c, inner)` where `inner` draws a set, then people (`person(c, x, feet_y, scale, SPEC['boyar'], v, pose, expr, talk=...)`), then bubbles and tags.

## 7. Check, render, deliver
1. Run `STILLS=1,5,9 python3 engine/render.py . /tmp/st` and look at a still from every scene: text cut off, overlapping labels, the wrong year on a map.
2. Render: `python3 engine/render.py . out.mp4` (writes at -14 LUFS).
3. Transcribe the final MP4. Run `tools/sheet.py` over the whole film and read every frame against the words under it. Fix, re-render, check again. Only then send.
4. Deliver the upload pack:
   - 3 titles
   - a description with chapters and every credit line
   - tags
   - a pinned comment
   - 3 thumbnail ideas
   - a separate vertical Short (its own 30-45 second script, built on the cold open)

## Files
- `engine/toon.py`: the cartoon kit (characters, guide, blobs, sets, props, bubbles, photo cards, title cards).
- `engine/satmap.py`: the satellite map.
- `engine/history.py`: older era skins, Bloodline, HistMap and investigation.
- `engine/moves.py`: maps, giant number, telestrator, flythrough, sketchnote.
- `engine/kit.py`: type and drawing helpers.
- `engine/timeline.py` and `engine/render.py`: the scene registry, render and mix.
- `engine/audio.py`: the generated epic score.
- `tools/`: voice, timings, photos, contact sheets.
- `assets/`: fonts (OFL) and Natural Earth countries.

Credits:
- Satellite imagery: NASA Blue Marble (public domain).
- Historical borders: historical-basemaps by A. Ourednik.
- Map: Natural Earth (public domain).
