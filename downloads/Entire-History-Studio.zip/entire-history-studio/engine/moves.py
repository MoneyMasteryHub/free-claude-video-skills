"""MMH signature moves, adapted from the Lemo-Opuscar library (grammar only, MMH look):
  screencast  - Living Screencast: window floats on the wallpaper, camera auto-follows the cursor,
                push-in on every click, smoothed cursor, optional pixel mascot acting out the software.
  tele        - Telestrator: play, FREEZE, draw on the frame (ring, marker arrow, highlight patch), play on.
  flythrough  - Desktop Flythrough: app screens as paper cards on a sunlit desk, one unbroken camera
                flies card to card (whip between stops) and pulls back over the whole desk.
  giant_number- Dark Keynote 'one giant number': dip to near-black, hairline grid, light sweep, one number.
  sketchnote  - Sketchnote: one page of visual notes drawn while you watch, one yellow highlight.
  mapx        - Map Explainer: 2.5D lit map, sea by depth, glowing routes and pins, flying camera.
All functions draw on a skia canvas at 1920x1080 and are keyed on voiceover time t (seconds)."""
import json, math, os
from kit import *

HERE = os.path.dirname(os.path.abspath(__file__))
def _clamp(u): return max(0.0, min(1.0, u))
def _sm(u): u = _clamp(u); return u * u * (3 - 2 * u)
def _rng(seed):
    x = [seed * 9301 + 49297]
    def r():
        x[0] = (x[0] * 9301 + 49297) % 233280; return x[0] / 233280.0
    return r
def _stroke(h, w, a=255, cap=True):
    p = skia.Paint(AntiAlias=True, Color=col(h, a), Style=skia.Paint.kStroke_Style, StrokeWidth=w)
    if cap: p.setStrokeCap(skia.Paint.kRound_Cap); p.setStrokeJoin(skia.Paint.kRound_Join)
    return p
def _trim(p, u):
    if u < .999:
        e = skia.TrimPathEffect.Make(0, max(0.001, _clamp(u)))
        if e is None: p.setAlphaf(0)                                  # nothing to draw yet (skia returns None near 0 or 1)
        else: p.setPathEffect(e)
    return p
def hand_path(pts, seed=1, jit=2.2, closed=False):
    """a smooth, slightly wobbly marker path through pts"""
    r = _rng(seed); q = [(x + (r() - .5) * jit * 2, y + (r() - .5) * jit * 2) for x, y in pts]
    p = skia.Path(); p.moveTo(*q[0])
    for i in range(1, len(q)):
        mx, my = (q[i - 1][0] + q[i][0]) / 2, (q[i - 1][1] + q[i][1]) / 2
        p.quadTo(q[i - 1][0], q[i - 1][1], mx, my) if i > 1 else p.lineTo(mx, my)
    p.lineTo(*q[-1])
    if closed: p.close()
    return p
def hand_ellipse(cx, cy, rx, ry, seed=1, turns=1.12, n=48):
    """marker ring that overshoots its start, like a commentator's circle"""
    r = _rng(seed); pts = []
    for i in range(n + 1):
        a = -math.pi * .6 + turns * 2 * math.pi * i / n; k = 1 + (r() - .5) * .05 + .04 * i / n
        pts.append((cx + rx * k * math.cos(a), cy + ry * k * math.sin(a)))
    return hand_path(pts, seed, 0.6)

# ============================================================== pixel mascot (original MMH character, "Bit")
_BIT = {   # 12x12; o=orange body, d=dark, w=visor, y=antenna light, .=empty
 'idle': [".....yy.....", ".....dd.....", "..oooooooo..", ".oooooooooo.", ".owwwwwwwwo.", ".owdwwwwdwo.", ".owwwwwwwwo.", ".oooooooooo.", "..oooooooo..", "..oo....oo..", "..dd....dd..", "............"],
 'run1': [".....yy.....", ".....dd.....", "..oooooooo..", ".oooooooooo.", ".owwwwwwwwo.", ".owwdwwwwdo.", ".owwwwwwwwo.", ".oooooooooo.", "..oooooooo..", ".oo......oo.", ".dd.......d.", "............"],
 'run2': ["............", ".....yy.....", ".....dd.....", "..oooooooo..", ".oooooooooo.", ".owwwwwwwwo.", ".owwdwwwwdo.", ".owwwwwwwwo.", ".oooooooooo.", "...oooooo...", "...dd..dd...", "............"],
 'read': [".....yy.....", ".....dd.....", "..oooooooo..", ".oooooooooo.", ".owwwwwwwwo.", ".owwwwwwwwo.", ".owdwwwwdwo.", ".oooooooooo.", "..oooooooo..", "..oo....oo..", "..dd....dd..", "............"],
 'cheer': ["y....yy....y", "o....dd....o", "o.oooooooo.o", "ooooooooooo.", ".owwwwwwwwo.", ".owdwwwwdwo.", ".owwddddwwo.", ".oooooooooo.", "..oooooooo..", "..oo....oo..", "..dd....dd..", "............"],
}
_BITC = {'o': ACC, 'd': '#2A1A12', 'w': '#FFF4E8', 'y': '#FFD23F'}
def mascot(c, x, y, t, mode='idle', px=8, facing=1, squash=0.0, a=255):
    """draw Bit with feet at (x, y). modes: idle, run, read, cheer, stomp (squash 0..1 for the impact)"""
    if mode == 'run': grid = _BIT['run1' if int(t * 10) % 2 == 0 else 'run2']
    elif mode in ('stomp',): grid = _BIT['idle']
    else: grid = _BIT.get(mode, _BIT['idle'])
    bob = 0 if mode in ('run', 'stomp') else round(math.sin(t * 5) * .6) * px * .5
    sx, sy = 1 + .25 * squash, 1 - .3 * squash
    c.save(); c.translate(x, y + bob); c.scale(facing * sx, sy)
    c.drawOval(skia.Rect(-6 * px, -px * .6, 6 * px, px * .6), fp('#000000', 40 * a / 255))
    for j, row in enumerate(grid):
        for i, ch in enumerate(row):
            if ch in _BITC: c.drawRect(skia.Rect((i - 6) * px, (j - 12) * px, (i - 5) * px + .5, (j - 11) * px + .5), fp(_BITC[ch], a))
    c.restore()

# ============================================================== Living Screencast
class Cam:
    """auto camera for a screen. track: [(t, fx, fy)] cursor positions (source fractions), clicks: [t].
    The camera follows the cursor with a critically damped spring, zooms in when the cursor settles,
    eases out to the full screen when it travels far, and pushes in a little on every click."""
    def __init__(self, track, clicks=(), z_in=1.55, z_out=1.0, settle=.35, follow=5.0, wide_until=None):
        self.wide = wide_until; self.tr = sorted(track); self.clicks = sorted(clicks); self.z_in, self.z_out = z_in, z_out
        self.settle, self.k = settle, follow; self._cache = None
    def cur(self, t):
        tr = self.tr
        if t <= tr[0][0]: return tr[0][1:]
        for p, q in zip(tr, tr[1:]):
            if t <= q[0]: u = _sm((t - p[0]) / max(1e-6, q[0] - p[0])); return (p[1] + (q[1] - p[1]) * u, p[2] + (q[2] - p[2]) * u)
        return tr[-1][1:]
    def speed(self, t, h=.12):
        a, b = self.cur(t - h), self.cur(t + h); return math.hypot(b[0] - a[0], b[1] - a[1]) / (2 * h)
    def _sim(self):
        t0 = self.tr[0][0] - .5; t1 = self.tr[-1][0] + 6; dt = 1 / 60
        x, y = self.cur(t0); z = self.z_out; vx = vy = vz = 0.0; out = []; t = t0; still = 0.0
        while t <= t1:
            fx, fy = self.cur(t); sp = self.speed(t)
            still = still + dt if sp < .12 else 0.0
            zt = self.z_in if still > self.settle else (self.z_out if sp > .6 else z)
            if self.wide is not None and t < self.wide: zt = self.z_out
            for cc in self.clicks:
                if -.05 < t - cc < .55: zt = max(zt, self.z_in) * (1 + .08 * math.sin(math.pi * _clamp((t - cc) / .55)))
            k = self.k; ax = k * k * (fx - x) - 2 * k * vx; ay = k * k * (fy - y) - 2 * k * vy; az = 9 * (zt - z) - 6 * vz
            vx += ax * dt; vy += ay * dt; vz += az * dt; x += vx * dt; y += vy * dt; z += vz * dt
            out.append((t, x, y, z)); t += dt
        self._cache = out
    def at(self, t):
        if self._cache is None: self._sim()
        o = self._cache; i = int(max(0, min(len(o) - 1, (t - o[0][0]) * 60))); return o[i][1:]

def screen_map(box, crop, img_wh, fx, fy, bar=True):
    """source fraction -> canvas xy inside a kit.window(box, crop)"""
    x0, y0, x1, y1 = box; top = y0 + (40 if bar else 0); cx, cy, z = crop; iw, ih = img_wh
    vw, vh = iw / z, ih / z; sx = min(max(cx * iw - vw / 2, 0), iw - vw); sy = min(max(cy * ih - vh / 2, 0), ih - vh)
    return x0 + (fx * iw - sx) / vw * (x1 - x0), top + (fy * ih - sy) / vh * (y1 - top)

def wallpaper(c, t, hue=('#F6E1CF', '#DCE6F2', '#E8E0F4')):
    """Screen-Studio wallpaper: soft moving colour fields (stays in the MMH light palette)"""
    c.clear(col('#EFEBE3'))
    for i, h in enumerate(hue):
        x = W * (.2 + .6 * (i / 2)) + 140 * math.sin(t * .1 + i * 2.1); y = H * (.3 + .4 * (i % 2)) + 90 * math.cos(t * .13 + i)
        p = skia.Paint(); p.setShader(skia.GradientShader.MakeRadial((x, y), 900, [col(h, 230), col(h, 0)])); c.drawRect(skia.Rect(0, 0, W, H), p)

def screencast(c, t, img, cam, box=None, clicks=(), cursor_on=True, a=1.0, tilt=0.0):
    """one frame of a Living Screencast. img: the screen (recording frame or a redrawn UI snapshot).
    cam: Cam. Returns (box, crop) so overlays (rings, mascot, telestrator) can map onto the screen."""
    iw, ih = img.width(), img.height()
    box = box or fit_box(iw / ih, maxw=1600, maxh=860, cy=560)
    fx, fy, z = cam.at(t); z = max(1.0, z); crop = (fx, fy, z)
    c.save()
    if tilt: c.translate(W / 2, H / 2); c.rotate(tilt); c.translate(-W / 2, -H / 2)
    window(c, img, box, crop, a)
    if cursor_on:
        cx, cy = cam.cur(t); X, Y = screen_map(box, crop, (iw, ih), cx, cy)
        clk = max([_clamp((t - k) / .5) for k in clicks if 0 <= t - k < .5] or [0])
        x0, y0, x1, y1 = box
        if x0 - 20 < X < x1 and y0 < Y < y1: cursor(c, X, Y, clk, 255 * a)
    c.restore()
    return box, crop

class UI:
    """render a redrawn interface (fn(c, t) drawing into a uw x uh canvas) to an image each frame"""
    def __init__(self, fn, uw=1600, uh=1000): self.fn, self.uw, self.uh = fn, uw, uh; self.s = skia.Surface(uw, uh)
    def at(self, t):
        c = self.s.getCanvas(); c.clear(col('#FFFFFF')); c.save(); self.fn(c, t); c.restore(); return self.s.makeImageSnapshot()

# ============================================================== Telestrator
def tele_time(t, a, freezes):
    """source clock with holds. freezes: [(t_freeze, t_resume)] in voiceover time. returns seconds since a."""
    s = t - a
    for f0, f1 in freezes:
        if t > f0: s -= min(t, f1) - f0
    return s
def frozen(t, freezes): return any(f0 <= t < f1 for f0, f1 in freezes)

def tele_freeze_fx(c, box, t, f0, f1):
    """the freeze itself: quick flash, slight dim, pause badge on the window, frame counter"""
    if not (f0 - .01 <= t < f1 + .25): return
    x0, y0, x1, y1 = box; inn = skia.Rect(x0, y0 + 40, x1, y1)
    on = K(t, f0, .12) * (1 - K(t, f1, .2)); fl = 1 - K(t, f0, .18)
    if fl > 0 and t >= f0: c.drawRect(inn, fp('#FFFFFF', 150 * fl))
    c.save(); c.clipRect(inn); c.drawRect(inn, fp('#0B0C10', 55 * on)); c.restore()
    if on > 0:
        bx, by = x0 + 22, y0 + 58; r = skia.Rect(bx, by, bx + 190, by + 54)
        c.drawRRect(skia.RRect.MakeRectXY(r, 12, 12), fp('#0F0F12', 220 * on))
        c.drawRect(skia.Rect(bx + 18, by + 15, bx + 26, by + 39), fp('#FFFFFF', 255 * on)); c.drawRect(skia.Rect(bx + 32, by + 15, bx + 40, by + 39), fp('#FFFFFF', 255 * on))
        text(c, 'FREEZE', bx + 54, by + 37, 26, XB, '#FFFFFF', 255 * on)

def tele_ring(c, x, y, rx, ry, t, t0, seed=3, h=ACC, a=1.0):
    """commentator ring: white underlay + colour marker, drawn in ~0.45 s"""
    u = eout(K(t, t0, .45))
    if u <= 0: return
    p = hand_ellipse(x, y, rx, ry, seed)
    c.drawPath(p, _trim(_stroke('#FFFFFF', 15, 200 * a), u)); c.drawPath(p, _trim(_stroke(h, 8, 255 * a), u))
def tele_arrow(c, x0, y0, x1, y1, t, t0, bend=.25, seed=5, h=ACC, a=1.0):
    """curved marker arrow drawn from (x0,y0) to (x1,y1) with a head at the end"""
    u = eout(K(t, t0, .5))
    if u <= 0: return
    mx, my = (x0 + x1) / 2 - (y1 - y0) * bend, (y0 + y1) / 2 + (x1 - x0) * bend
    pts = [((1 - s) ** 2 * x0 + 2 * (1 - s) * s * mx + s * s * x1, (1 - s) ** 2 * y0 + 2 * (1 - s) * s * my + s * s * y1) for s in [i / 20 for i in range(21)]]
    p = hand_path(pts, seed, 1.2)
    c.drawPath(p, _trim(_stroke('#FFFFFF', 15, 200 * a), u)); c.drawPath(p, _trim(_stroke(h, 8, 255 * a), u))
    if u > .92:
        k = _clamp((u - .92) / .08); ang = math.atan2(y1 - pts[-3][1], x1 - pts[-3][0])
        for d in (2.6, -2.6):
            hx, hy = x1 + 34 * k * math.cos(ang + d), y1 + 34 * k * math.sin(ang + d)
            c.drawLine(x1, y1, hx, hy, _stroke('#FFFFFF', 15, 200 * a)); c.drawLine(x1, y1, hx, hy, _stroke(h, 8, 255 * a))
def tele_patch(c, r, t, t0, h='#FFD23F', a=1.0):
    """highlight patch (the 'space nobody covered'): translucent fill + hatch, wiped in left to right"""
    u = eout(K(t, t0, .4))
    if u <= 0: return
    x0, y0, x1, y1 = r; xr = x0 + (x1 - x0) * u
    c.save(); c.clipRect(skia.Rect(x0, y0, xr, y1)); c.drawRect(skia.Rect(x0, y0, x1, y1), fp(h, 90 * a))
    for k in range(-int(y1 - y0), int(x1 - x0), 22): c.drawLine(x0 + k, y1, x0 + k + (y1 - y0), y0, _stroke(h, 3, 150 * a))
    c.restore(); c.drawRect(skia.Rect(x0, y0, xr, y1), _stroke(h, 4, 255 * a, cap=False))
def tele_label(c, x, y, s, t, t0, h=ACC):
    u = eout(K(t, t0, .3))
    if u <= 0: return
    w = tw(s, XB, 34) + 40; r = skia.Rect(x - w / 2, y - 30, x + w / 2, y + 30)
    c.save(); c.translate(x, y); c.scale(.8 + .2 * u, .8 + .2 * u); c.translate(-x, -y)
    c.drawRRect(skia.RRect.MakeRectXY(r, 12, 12), fp(h, 255 * u)); text(c, s, x, y + 12, 34, XB, '#FFFFFF', 255 * u, 'center'); c.restore()

# ============================================================== Desktop Flythrough
DESK = '#E9DCC6'
def _desk(c, t, wx0, wy0, wx1, wy1):
    c.drawRect(skia.Rect(wx0, wy0, wx1, wy1), fp(DESK))
    r = _rng(7)
    for i in range(60):                                                     # faint wood grain
        y = wy0 + (wy1 - wy0) * r(); p = skia.Path(); p.moveTo(wx0, y)
        for k in range(1, 9): p.lineTo(wx0 + (wx1 - wx0) * k / 8, y + 14 * math.sin(k * 1.3 + i))
        c.drawPath(p, _stroke('#D9C7A8', 2 + 3 * r(), 90))
    p = skia.Paint(); p.setShader(skia.GradientShader.MakeLinear([(wx0, wy0), (wx1, wy1)], [col('#FFF6DF', 120), col('#FFF6DF', 0), col('#6B5434', 60)], [0, .55, 1]))
    c.drawRect(skia.Rect(wx0, wy0, wx1, wy1), p)                               # low sun from the top-left
def paper_card(c, x, y, w, h, rot, title, ic=None, lines=3, hot=0.0, body=None, t=0.0):
    """printed paper card on the desk with a long sun shadow; body(c, w, h, t) can draw a mini screen"""
    c.save(); c.translate(x, y); c.rotate(rot)
    r = skia.Rect(-w / 2, -h / 2, w / 2, h / 2)
    c.drawRect(r.makeOffset(26, 30), fp('#3A2A14', 70, 22))
    c.drawRect(r, fp('#FFFDF8'))
    if hot > 0: c.drawRect(r, _stroke(ACC, 10 * hot, 255 * hot, cap=False))
    text(c, title, -w / 2 + 40, -h / 2 + 78, 46, XB, INK)
    if ic: c.save(); c.translate(w / 2 - 80, -h / 2 + 64); c.scale(.8, .8); icon(c, ic, ACC); c.restore()
    if body: c.save(); c.translate(-w / 2 + 40, -h / 2 + 120); body(c, w - 80, h - 160, t); c.restore()
    else:
        for i in range(lines): c.drawRoundRect(skia.Rect(-w / 2 + 40, -h / 2 + 130 + i * 44, -w / 2 + 40 + (w - 80) * (.95 - .2 * (i % 2)), -h / 2 + 150 + i * 44), 10, 10, fp('#E6E0D4'))
    c.restore()

class Fly:
    """cards: [dict(x, y, w, h, rot, title, ic, body)] in desk coords. stops: [(t, card_index or None, zoom)].
    None = the whole-desk pull-back. Moves between stops are whips: fast in the middle, motion-blurred."""
    def __init__(self, cards, stops, desk=(-200, -200, 4200, 2600)):
        self.cards, self.stops, self.desk = cards, stops, desk
    def _target(self, s):
        _, i, z = s
        if i is None:
            x0, y0, x1, y1 = self.desk; return ((x0 + x1) / 2, (y0 + y1) / 2, min(W / (x1 - x0), H / (y1 - y0)) * 1.08)
        cd = self.cards[i]; return (cd['x'], cd['y'], z)
    def camera(self, t):
        st = self.stops
        if t <= st[0][0]: return self._target(st[0]) + (0.0,)
        for p, q in zip(st, st[1:]):
            d = min(.8, .55 * (q[0] - p[0]))                                    # always leave a hold on each card
            if t < q[0] - d: return self._target(p) + (0.0,)
            if t < q[0]:
                u = (t - (q[0] - d)) / d; e = u * u * u * (u * (u * 6 - 15) + 10)       # smootherstep = whip
                a, b = self._target(p), self._target(q)
                zl = math.exp(math.log(a[2]) + (math.log(b[2]) - math.log(a[2])) * e) * (1 - .28 * math.sin(math.pi * u) * (q[2] is not None and p[1] is not None and q[1] is not None))
                vel = math.sin(math.pi * u)
                return (a[0] + (b[0] - a[0]) * e, a[1] + (b[1] - a[1]) * e, zl, vel * math.hypot(b[0] - a[0], b[1] - a[1]) / 900)
        return self._target(st[-1]) + (0.0,)
    def draw(self, c, t, hot_card=None, carry=True):
        x, y, z, blur = self.camera(t)
        if blur > .05: c.saveLayer(None, skia.Paint(ImageFilter=skia.ImageFilters.Blur(8 * min(2.5, blur), 2 * min(2.5, blur))))
        else: c.save()
        c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-x, -y)
        _desk(c, t, *self.desk)
        for i, cd in enumerate(self.cards):
            paper_card(c, cd['x'], cd['y'], cd.get('w', 900), cd.get('h', 600), cd.get('rot', 0), cd['title'], cd.get('ic'), hot=(1.0 if i == hot_card else 0.0), body=cd.get('body'), t=t)
        if carry:                                                           # Bit carries the work card to card
            mx = x + 560 / z; my = y + 380 / z
            moving = blur > .05
            mascot(c, mx, my, t, 'run' if moving else 'idle', px=9 / max(.6, z) * .9)
            c.drawRoundRect(skia.Rect(mx - 30, my - 150, mx + 30, my - 112), 6, 6, fp('#FFD23F'))
        c.restore()

# ============================================================== Dark Keynote: one giant number
def giant_number(c, t, t0, t1, value, label='', prefix='', suffix='', decimals=0, sub=None, count=True):
    """full-frame dark beat. value counts up from 0 (or shows as-is when count=False). fades in/out at t0/t1"""
    on = ease(K(t, t0, .35)) * (1 - ease(K(t, t1 - .35, .35)))
    if on <= 0: return False
    c.save(); c.saveLayerAlpha(None, int(255 * on))
    p = skia.Paint(); p.setShader(skia.GradientShader.MakeRadial((W / 2, H * .42), 1300, [col('#1D2028'), col('#0A0B0E')])); c.drawRect(skia.Rect(0, 0, W, H), p)
    for x in range(0, W + 1, 96): c.drawLine(x, 0, x, H, _stroke('#FFFFFF', 1, 14, cap=False))
    for y in range(0, H + 1, 96): c.drawLine(0, y, W, y, _stroke('#FFFFFF', 1, 14, cap=False))
    u = eout(K(t, t0 + .15, 1.1)) if count else 1.0
    v = value * u if count else value
    s = f'{v:,.{decimals}f}'
    sz = 330
    while tw(prefix + s + suffix, XB, sz) > W - 260: sz -= 10
    total = tw(prefix + s + suffix, XB, sz); x = W / 2 - total / 2; y = H * .55
    rise = 30 * (1 - eout(K(t, t0 + .1, .5)))
    sw = K(t, t0 + .3, 1.2); sx = W * (-.2 + 1.4 * sw)                    # light sweep travels through the glyphs only
    for part, h in ((prefix, '#FFFFFF'), (s, '#FFFFFF'), (suffix, ACC)):
        if not part: continue
        pnt = fp(h)
        if 0 < sw < 1 and h == '#FFFFFF':
            pnt.setShader(skia.GradientShader.MakeLinear([(sx - 260, 0), (sx + 260, 0)], [col('#D9DBE0'), col('#FFFFFF'), col('#D9DBE0')], [0, .5, 1]))
        elif h == '#FFFFFF': pnt = fp('#ECEDF0')
        c.drawString(part, x, y + rise, font(XB, sz), pnt); x += tw(part, XB, sz)
    if label: text(c, label, W / 2, y + 110, 52, SEMI, '#C9CCD3', 255 * K(t, t0 + .5, .4), 'center')
    if sub: text(c, sub, W / 2, y + 180, 36, MED, '#7D828C', 255 * K(t, t0 + .8, .4), 'center')
    c.restore(); c.restore(); return True

# ============================================================== Sketchnote
YEL = '#FFE14D'
def _paper(c):
    c.clear(col('#FBFAF6'))
    for x in range(0, W, 40):
        for y in range(0, H, 40): c.drawCircle(x + 20, y + 20, 1.6, fp('#CFCBC2'))
def sketch_box(c, x, y, w, h, t, t0, title, ic=None, hl=0.0, seed=1, dur=.7):
    """rounded marker box: grey marker shadow, fineliner outline, hand lettering, optional yellow highlight"""
    u = K(t, t0, dur)
    if u <= 0: return
    if hl > 0:
        e = eout(hl); c.save(); c.clipRect(skia.Rect(x - 16, y - 20, x - 16 + (w + 32) * e, y + h + 26))
        q = skia.Path(); q.moveTo(x - 14, y - 8); q.lineTo(x + w + 16, y - 14); q.lineTo(x + w + 10, y + h + 18); q.lineTo(x - 8, y + h + 12); q.close()
        c.drawPath(q, fp(YEL, 230)); c.restore()
    r = 26; pts = []
    for k in range(9): pts.append((x + r + (w - 2 * r) * k / 8, y))
    for k in range(9): pts.append((x + w, y + r + (h - 2 * r) * k / 8))
    for k in range(9): pts.append((x + w - r - (w - 2 * r) * k / 8, y + h))
    for k in range(9): pts.append((x, y + h - r - (h - 2 * r) * k / 8))
    pts.append(pts[0])
    p = hand_path(pts, seed, 1.5)
    if u > .3: c.drawRoundRect(skia.Rect(x + 12, y + 14, x + w + 12, y + h + 14), r, r, fp('#B9B5AD', 120 * K(t, t0 + .2, .3)))
    if u > .3: c.drawRoundRect(skia.Rect(x, y, x + w, y + h), r, r, fp('#FFFFFF', 255 * K(t, t0 + .2, .3)))
    if hl > 0: c.drawRoundRect(skia.Rect(x, y, x + w, y + h), r, r, fp(YEL, 150 * eout(hl)))
    c.drawPath(p, _trim(_stroke(INK, 5), eout(min(1, u * 1.4))))
    tx = x + (110 if ic else 34)
    if ic and u > .4: c.save(); c.translate(x + 62, y + h / 2); c.scale(.62, .62); icon(c, ic, INK, 255 * K(t, t0 + .35, .2)); c.restore()
    n = int(len(title) * _clamp((u - .45) / .55)); sz = 42
    while tw(title, BOLD, sz) > w - (tx - x) - 24 and sz > 26: sz -= 2
    text(c, title[:n], tx, y + h / 2 + sz * .36, sz, BOLD, INK)
def sketch_arrow(c, x0, y0, x1, y1, t, t0, seed=2):
    """fat hand-drawn arrow"""
    u = eout(K(t, t0, .4))
    if u <= 0: return
    p = hand_path([(x0, y0), ((x0 + x1) / 2, (y0 + y1) / 2 + 8), (x1, y1)], seed, 2)
    c.drawPath(p, _trim(_stroke('#9C978E', 16), u)); c.drawPath(p, _trim(_stroke(INK, 6), u))
    if u > .9:
        ang = math.atan2(y1 - y0, x1 - x0)
        for d in (2.5, -2.5): c.drawLine(x1, y1, x1 + 30 * math.cos(ang + d), y1 + 30 * math.sin(ang + d), _stroke(INK, 7))
def sketch_banner(c, x, y, w, t, t0, s):
    """ribbon banner title"""
    u = K(t, t0, .8)
    if u <= 0: return
    h = 96; pts = [(x, y), (x + w, y), (x + w - 24, y + h / 2), (x + w, y + h), (x, y + h), (x + 24, y + h / 2), (x, y)]
    p = hand_path(pts, 11, 1.2)
    if u > .25: c.drawPath(hand_path(pts, 11, 0), fp(INK, 255 * K(t, t0 + .25, .3)))
    c.drawPath(p, _trim(_stroke(INK, 5), eout(min(1, u * 1.6))))
    n = int(len(s) * _clamp((u - .35) / .65)); text(c, s[:n], x + w / 2, y + h / 2 + 22, 58, XB, '#FFFFFF', 255, 'center')
class Sketch:
    """one page of notes drawn live. items: [(t0, kind, args)]; the camera rides with whatever is being drawn,
    then pulls back to the full page at t_full."""
    def __init__(self, items, t_full, z=1.35): self.items, self.t_full, self.z = sorted(items, key=lambda i: i[0]), t_full, z
    def _focus(self, it):
        k, a = it[1], it[2]
        if k == 'box': return a[0] + a[2] / 2, a[1] + a[3] / 2
        if k == 'banner': return a[0] + a[2] / 2, a[1] + 48
        if k == 'arrow': return (a[0] + a[2]) / 2, (a[1] + a[3]) / 2
        return W / 2, H / 2
    def draw(self, c, t, hl=None):
        cur = [i for i in self.items if i[0] <= t] or self.items[:1]
        fx, fy = self._focus(cur[-1])
        if len(cur) >= 2 and t - cur[-1][0] < .5:
            px, py = self._focus(cur[-2]); u = _sm((t - cur[-1][0]) / .5); fx, fy = px + (fx - px) * u, py + (fy - py) * u
        pb = _sm(K(t, self.t_full, 1.0)); z = self.z + (1 - self.z) * pb; fx = fx + (W / 2 - fx) * pb; fy = fy + (H / 2 - fy) * pb
        c.save(); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-fx, -fy)
        _paper(c)
        for t0, k, a in self.items:
            if k == 'box': sketch_box(c, *a[:4], t, t0, a[4], a[5] if len(a) > 5 else None, hl=(hl(t) if hl and len(a) > 6 and a[6] else 0.0), seed=int(t0 * 10))
            elif k == 'arrow': sketch_arrow(c, *a, t, t0, seed=int(t0 * 10))
            elif k == 'banner': sketch_banner(c, a[0], a[1], a[2], t, t0, a[3])
        c.restore()

# ============================================================== Map Explainer
_GEO = None
def _merc(lon, lat): lat = max(-84, min(84, lat)); return lon, math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))
def geo():
    global _GEO
    if _GEO is None:
        data = json.load(open(os.path.join(HERE, '..', 'assets', 'countries.json'))); _GEO = {}
        for f in data:
            p = skia.Path(); polys = f['coords'] if f['type'] == 'MultiPolygon' else [f['coords']]
            for poly in polys:
                for ring in poly:
                    for i, (lo, la) in enumerate(ring):
                        x, y = _merc(lo, la); (p.moveTo if i == 0 else p.lineTo)(x, -y)
                    p.close()
            _GEO[f['iso']] = (f['name'], p)
    return _GEO
def iso_of(name):
    for k, (n, _) in geo().items():
        if n.lower() == name.lower(): return k
    raise KeyError(name)
class MapCam:
    """keys: [(t, lon, lat, zoom)] zoom = pixels per degree. Long moves rise (zoom out) mid-flight, like a fall from orbit."""
    def __init__(self, keys): self.k = keys
    def at(self, t):
        k = self.k
        if t <= k[0][0]: return k[0][1:]
        for p, q in zip(k, k[1:]):
            if t <= q[0]:
                u = ease((t - p[0]) / (q[0] - p[0])); lo = p[1] + (q[1] - p[1]) * u; la = p[2] + (q[2] - p[2]) * u
                z = math.exp(math.log(p[3]) + (math.log(q[3]) - math.log(p[3])) * u)
                d = math.hypot(q[1] - p[1], q[2] - p[2]); z /= 1 + min(1.5, d / 60) * math.sin(math.pi * u) * .6
                return lo, la, z
        return k[-1][1:]
def _to_xy(lon, lat, cam):
    lo, la, z = cam; x, y = _merc(lon, lat); cx, cy = _merc(lo, la); return W / 2 + (x - cx) * z, H / 2 - (y - cy) * z
def mapx(c, t, cam, focus=(), routes=(), pins=(), dim_others=.0, label_focus=None):
    """focus: [(iso, t_on)] countries lit in the accent; routes: [dict(pts=[(lon,lat)...], t0, dur, h)];
    pins: [dict(lon, lat, label, t0)]. Returns nothing; draws the full frame."""
    lo, la, z = cam.at(t) if hasattr(cam, 'at') else cam
    G = geo(); cx, cy = _merc(lo, la)
    c.clear(col('#0E3B57'))
    p = skia.Paint(); p.setShader(skia.GradientShader.MakeRadial((W * .3, H * .2), 1700, [col('#2E6E8E'), col('#0B2F47')])); c.drawRect(skia.Rect(0, 0, W, H), p)
    c.save(); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-cx, cy)
    sw = 1 / z
    shallow = skia.Paint(AntiAlias=True, Color=col('#5FA8C4', 90), Style=skia.Paint.kStroke_Style, StrokeWidth=22 * sw, StrokeJoin=skia.Paint.kRound_Join)
    shallow.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 10 * sw))
    for _, (n, path) in G.items(): c.drawPath(path, shallow)                 # shelf water: lighter near coasts
    for _, (n, path) in G.items(): c.drawPath(path.makeOffset(0, 5 * sw) if hasattr(path, 'makeOffset') else path, fp('#5C4A33'))   # 2.5D side
    for iso, (n, path) in G.items(): c.drawPath(path, fp('#E9DFC8'))
    for iso, t_on in focus:
        u = ease(K(t, t_on, .6))
        if u > 0 and iso in G:
            gl = skia.Paint(AntiAlias=True, Color=col(ACC, 200 * u)); gl.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 18 * sw)); c.drawPath(G[iso][1], gl)
            c.drawPath(G[iso][1], fp('#F3B48E', 255 * u))
    bd = skia.Paint(AntiAlias=True, Color=col('#9C8D74', 200), Style=skia.Paint.kStroke_Style, StrokeWidth=1.1 * sw)
    for _, (n, path) in G.items(): c.drawPath(path, bd)
    for iso, t_on in focus:
        if iso in G and t >= t_on: c.drawPath(G[iso][1], skia.Paint(AntiAlias=True, Color=col(ACC, 255 * ease(K(t, t_on, .6))), Style=skia.Paint.kStroke_Style, StrokeWidth=3 * sw))
    c.restore()
    sun = skia.Paint(); sun.setShader(skia.GradientShader.MakeLinear([(0, 0), (W, H)], [col('#FFE2B0', 70), col('#FFE2B0', 0), col('#000000', 90)], [0, .5, 1])); c.drawRect(skia.Rect(0, 0, W, H), sun)
    for r in routes:                                                          # glowing routes with a bright head
        u = _clamp((t - r['t0']) / r.get('dur', 1.5))
        if u <= 0: continue
        pts = [_to_xy(a, b, (lo, la, z)) for a, b in r['pts']]
        path = skia.Path(); path.moveTo(*pts[0])
        for i in range(1, len(pts)):
            (x0, y0), (x1, y1) = pts[i - 1], pts[i]; mx, my = (x0 + x1) / 2, (y0 + y1) / 2 - .18 * math.hypot(x1 - x0, y1 - y0); path.quadTo(mx, my, x1, y1)
        h = r.get('h', '#FFD23F')
        g = _trim(_stroke(h, 16, 120), eout(u)); g.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 10)); c.drawPath(path, g)
        c.drawPath(path, _trim(_stroke(h, 5, 255), eout(u)))
        pm = skia.PathMeasure(path, False); L = pm.getLength()
        if 0 < u < 1 and L > 0:
            pos = pm.getPosTan(L * eout(u))
            if pos: (hx, hy) = pos[0]; c.drawCircle(hx, hy, 14, fp('#FFFFFF', 230, 6)); c.drawCircle(hx, hy, 7, fp('#FFFFFF'))
    for pn in pins:
        u = eout(K(t, pn['t0'], .4))
        if u <= 0: continue
        x, y = _to_xy(pn['lon'], pn['lat'], (lo, la, z))
        ph = (t - pn['t0']) % 1.6 / 1.6; c.drawCircle(x, y, 10 + 40 * ph, _stroke('#FFFFFF', 3, 200 * (1 - ph)))
        c.drawCircle(x, y, 11 * u, fp('#FFFFFF')); c.drawCircle(x, y, 6 * u, fp(ACC))
        if pn.get('label'):
            s = pn['label']; w = tw(s, BOLD, 34) + 34; r = skia.Rect(x + 22, y - 58, x + 22 + w, y - 8)
            c.drawRRect(skia.RRect.MakeRectXY(r, 10, 10), fp('#0F1217', 220 * u)); text(c, s, x + 39, y - 22, 34, BOLD, '#FFFFFF', 255 * u)
    if label_focus:
        s, t0 = label_focus; u = eout(K(t, t0, .5))
        if u > 0:
            s = s.upper(); w = tw(s, XB, 60) + 70; y = H - 110 + 20 * (1 - u); r = skia.Rect(W / 2 - w / 2, y - 62, W / 2 + w / 2, y + 22)
            c.drawRRect(skia.RRect.MakeRectXY(r, 18, 18), fp('#0F1217', 215 * u)); text(c, s, W / 2, y, 60, XB, '#FFFFFF', 255 * u, 'center')
