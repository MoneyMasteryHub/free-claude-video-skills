"""SATELLITE MAP (Map Explainer grammar): real Earth imagery (NASA Blue Marble, public domain), tilted like a camera
looking across the land, lit by a warm low sun with haze at the horizon. Over it: a country or empire filled in one
colour with a bright rim, glowing white routes, pins with labels, paper puppets standing on the land.

  sm = SatMap()                          # loads imagery from the cache (setup.sh downloads it)
  cam = MapCam([(t, lon, lat, zoom)])    # zoom = screen pixels per degree of longitude
  sm.draw(c, t, cam, fills=[...], routes=[...], pins=[...], label=('text', t0))
fills: dict(name=..., year=1600 (historical-basemaps) or iso='JPN' (Natural Earth), t0, h='#D8322A')"""
import os, json, math
from kit import *
from moves import MapCam, _clamp, _sm, _stroke, _trim

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.expanduser(os.environ.get('EHS_CACHE', '~/.entire-history-studio/cache'))
TILE_DEG, TILE_PX = 45, 3000

def _img(p): return skia.Image.MakeFromEncoded(skia.Data.MakeFromFileName(p))

def prepare_imagery(src):
    """one-time: cut the 24000x12000 Blue Marble into a world image and 32 tiles"""
    from PIL import Image; Image.MAX_IMAGE_PIXELS = None
    im = Image.open(src).convert('RGB'); os.makedirs(os.path.join(CACHE, 'bm_tiles'), exist_ok=True)
    im.resize((6000, 3000), Image.LANCZOS).save(os.path.join(CACHE, 'bm_world.jpg'), quality=90)
    for j in range(4):
        for i in range(8): im.crop((i * TILE_PX, j * TILE_PX, (i + 1) * TILE_PX, (j + 1) * TILE_PX)).save(os.path.join(CACHE, 'bm_tiles', 't_%d_%d.jpg' % (i, j)), quality=88)

_EQ = {}
def _eq_path(rings_iter):
    p = skia.Path()
    for ring in rings_iter:
        for i, (lo, la) in enumerate(ring): (p.moveTo if i == 0 else p.lineTo)(lo, -la)
        p.close()
    return p
def country_eq(iso):
    """Natural Earth country outline in plain lon/-lat coordinates"""
    if ('ne', iso) not in _EQ:
        data = json.load(open(os.path.join(HERE, '..', 'assets', 'countries.json')))
        for f in data:
            polys = f['coords'] if f['type'] == 'MultiPolygon' else [f['coords']]
            _EQ[('ne', f['iso'])] = _eq_path(r for poly in polys for r in poly)
    return _EQ.get(('ne', iso))
def polity_eq(year, name):
    """historical-basemaps polity for a year (downloaded once, cached)"""
    k = ('hb', year, name)
    if k not in _EQ:
        fn = os.path.join(CACHE, 'world_%d.geojson' % year)
        if not os.path.exists(fn):
            import urllib.request; urllib.request.urlretrieve('https://raw.githubusercontent.com/aourednik/historical-basemaps/master/geojson/world_%d.geojson' % year, fn)
        p = skia.Path()
        for f in json.load(open(fn))['features']:
            if f['properties'].get('NAME') != name or not f['geometry']: continue
            g = f['geometry']; polys = g['coordinates'] if g['type'] == 'MultiPolygon' else [g['coordinates']]
            p.addPath(_eq_path(r for poly in polys for r in poly))
        _EQ[k] = p
    return _EQ[k]

class SatMap:
    def __init__(self, tilt=.42):
        self.world = _img(os.path.join(CACHE, 'bm_world.jpg')); self.tiles = {}; self.tilt = tilt
    def _tile(self, i, j):
        if (i, j) not in self.tiles: self.tiles[(i, j)] = _img(os.path.join(CACHE, 'bm_tiles', 't_%d_%d.jpg' % (i, j)))
        return self.tiles[(i, j)]
    def matrices(self, cam, tilt):
        lo, la, z = cam; kx = math.cos(math.radians(la)) ** .35                    # gentle compression of longitude
        M = skia.Matrix(); M.setTranslate(W / 2, H / 2); M.preScale(z * kx, z); M.preTranslate(-lo, la)
        P = skia.Matrix(); s, h = .55 * tilt, .55 * tilt
        P.setPolyToPoly([skia.Point(-s * W, -h * H), skia.Point((1 + s) * W, -h * H), skia.Point(W * (1 + .02 * tilt), H), skia.Point(-W * .02 * tilt, H)],
                        [skia.Point(0, 0), skia.Point(W, 0), skia.Point(W, H), skia.Point(0, H)])
        return M, P
    def to_screen(self, M, P, lon, lat):
        x, y = M.mapXY(lon, -lat); return P.mapXY(x, y)
    def draw(self, c, t, cam, fills=(), routes=(), pins=(), label=None, year=None, tilt=None, dim=0.0, puppets=None):
        lo, la, z = cam.at(t) if hasattr(cam, 'at') else cam; tilt = self.tilt if tilt is None else tilt
        M, P = self.matrices((lo, la, z), tilt)
        sky = skia.Paint(); sky.setShader(skia.GradientShader.MakeLinear([(0, 0), (0, H * .5)], [col('#9DC3E6'), col('#1C3550')])); c.drawRect(skia.Rect(0, 0, W, H), sky)
        tilt = tilt * _clamp((z - 5) / 14)                                        # wide views look straight down
        M, P = self.matrices((lo, la, z), tilt)
        c.save(); c.concat(P); c.concat(M)
        S = skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear)
        for wrap in (-360, 0, 360):                                                       # whole Earth, low detail, wrapped
            if abs(lo - wrap) < 360: c.drawImageRect(self.world, skia.Rect(-180 + wrap, -90, 180 + wrap, 90), S)
        if z > 22:                                                                        # sharp tiles where the camera is
            span_lon = W / z * (1 + 1.2 * tilt) / 2 + 2; span_lat = H / z * (1 + tilt) + 2
            for i in range(8):
                for j in range(4):
                    L0, T0 = -180 + i * TILE_DEG, 90 - j * TILE_DEG
                    if L0 > lo + span_lon or L0 + TILE_DEG < lo - span_lon or T0 < la - span_lat or T0 - TILE_DEG > la + span_lat: continue
                    c.drawImageRect(self._tile(i, j), skia.Rect(L0, -T0, L0 + TILE_DEG, -T0 + TILE_DEG), S)
        sat = skia.ColorFilters.Matrix([1.08, 0, 0, 0, .02, 0, 1.06, 0, 0, .01, 0, 0, 1.0, 0, 0, 0, 0, 0, 1, 0])
        for f in fills:                                                                    # filled country / empire
            u = ease(K(t, f.get('t0', -1e9), .8)) * (1 - ease(K(t, f.get('t1', 1e9), .8)))
            if u <= 0: continue
            p = polity_eq(f['year'], f['name']) if 'year' in f else country_eq(f['iso'])
            if p is None or p.isEmpty(): continue
            h = f.get('h', '#D8322A')
            c.drawPath(p, fp(h, 150 * u))
            rim = skia.Paint(AntiAlias=True, Color=col('#FFE7C2', 230 * u), Style=skia.Paint.kStroke_Style, StrokeWidth=3.0 / z); c.drawPath(p, rim)
            gl = skia.Paint(AntiAlias=True, Color=col(h, 160 * u), Style=skia.Paint.kStroke_Style, StrokeWidth=14.0 / z); gl.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 6.0 / z)); c.drawPath(p, gl)
        c.restore()
        # sun and atmosphere (screen space): warm low light from the upper left, haze where the land meets the sky
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeLinear([(0, 0), (0, H * .45)], [col('#BFD9F2', 210), col('#9CC3E6', 70), col('#9CC3E6', 0)], [0, .35, 1])); c.drawRect(skia.Rect(0, 0, W, H * .45), g)
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial((W * .15, -H * .1), 1900, [col('#FFD9A0', 70), col('#FFD9A0', 0)])); g.setBlendMode(skia.BlendMode.kScreen); c.drawRect(skia.Rect(0, 0, W, H), g)
        v = skia.Paint(); v.setShader(skia.GradientShader.MakeRadial((W / 2, H * .55), 1250, [col('#000000', 0), col('#000000', 150)], [.6, 1])); c.drawRect(skia.Rect(0, 0, W, H), v)
        if dim: c.drawRect(skia.Rect(0, 0, W, H), fp('#000000', 255 * dim))
        for r in routes:                                                                   # glowing white routes (screen space)
            u = _clamp((t - r['t0']) / r.get('dur', 1.5))
            if u <= 0: continue
            pts = [self.to_screen(M, P, a, b) for a, b in r['pts']]
            path = skia.Path(); path.moveTo(*pts[0])
            for k in range(1, len(pts)):
                (x0, y0), (x1, y1) = pts[k - 1], pts[k]; path.quadTo((x0 + x1) / 2, (y0 + y1) / 2 - .18 * math.hypot(x1 - x0, y1 - y0), x1, y1)
            h = r.get('h', '#FFFFFF')
            gp = _trim(_stroke(h, 18, 90), eout(u)); gp.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 9)); c.drawPath(path, gp)
            c.drawPath(path, _trim(_stroke(h, 7, 255), eout(u)))
            pm = skia.PathMeasure(path, False); L = pm.getLength()
            if L > 0 and (r.get('arrow') or 0 < u < 1):
                pos = pm.getPosTan(L * eout(u))
                if pos:
                    (hx, hy), (tx, ty) = pos; a = math.atan2(ty, tx)
                    if r.get('icon'): r['icon'](c, hx, hy, a, t)
                    elif r.get('arrow') and u > .98:
                        for d in (2.5, -2.5): c.drawLine(hx, hy, hx + 30 * math.cos(a + d), hy + 30 * math.sin(a + d), _stroke(h, 7))
        for pn in pins:                                                                   # teardrop pins
            u = eout(K(t, pn['t0'], .45))
            if u <= 0: continue
            x, y = self.to_screen(M, P, pn['lon'], pn['lat']); y -= 30 * (1 - u)
            hpin = pn.get('h', '#FFC93C')
            c.drawOval(skia.Rect(x - 12, y - 4, x + 12, y + 4), fp('#000000', 90 * u))
            pp = skia.Path(); pp.moveTo(x, y); pp.cubicTo(x - 22, y - 30, x - 20, y - 56, x, y - 56); pp.cubicTo(x + 20, y - 56, x + 22, y - 30, x, y)
            c.drawPath(pp, fp(hpin, 255 * u)); c.drawPath(pp, _stroke('#3A2A10', 3, 255 * u, cap=False)); c.drawCircle(x, y - 38, 7, fp('#3A2A10', 255 * u))
            if pn.get('label'):
                s = pn['label']; f = font(LILITA, 40); w = f.measureText(s) + 36; dx = pn.get('dx', 26)
                r = skia.Rect(x + dx, y - 84, x + dx + w, y - 36) if dx > 0 else skia.Rect(x + dx - w, y - 84, x + dx, y - 36)
                c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(4, 5), 10, 10), fp('#000000', 70 * u))
                c.drawRRect(skia.RRect.MakeRectXY(r, 10, 10), fp('#F5E9C4', 255 * u)); c.drawRRect(skia.RRect.MakeRectXY(r, 10, 10), _stroke('#2B2219', 3, 255 * u, cap=False))
                c.drawString(s, r.left() + 18, r.bottom() - 13, f, fp('#2B2219', 255 * u))
        if puppets: puppets(c, t, lambda lon, lat: self.to_screen(M, P, lon, lat))
        if label:
            s, t0 = label; u = eout(K(t, t0, .45))
            if u > 0: caption_card(c, s, W / 2, H - 80 + 30 * (1 - u), u)
        if year: year_tag(c, *year, t)

LILITA = skia.Typeface.MakeFromFile(os.path.join(HERE, '..', 'assets', 'fonts', 'LilitaOne-Regular.ttf'))
HAND = skia.Typeface.MakeFromFile(os.path.join(HERE, '..', 'assets', 'fonts', 'PatrickHand-Regular.ttf'))

def caption_card(c, s, cx, cy, u=1.0, sz=48):
    """opaque cream caption card with an ink border (comic page caption)"""
    f = font(LILITA, sz); w = f.measureText(s) + 70; r = skia.Rect(cx - w / 2, cy - sz * .95, cx + w / 2, cy + sz * .45)
    c.save(); c.translate(cx, cy); c.rotate(-1.2); c.translate(-cx, -cy)
    c.drawRect(r.makeOffset(6, 7), fp('#000000', 90 * u)); c.drawRect(r, fp('#F5E9C4', 255 * u)); c.drawRect(r, _stroke('#2B2219', 4, 255 * u, cap=False))
    c.drawString(s, cx - (w - 70) / 2, cy + sz * .12, f, fp('#2B2219', 255 * u)); c.restore()

def year_tag(c, y0, y1, ta, tb, t):
    """year card top left, counting from y0 to y1 between ta and tb"""
    u = K(t, ta - .3, .3)
    if u <= 0: return
    yr = int(round(y0 + (y1 - y0) * _sm(K(t, ta, max(.01, tb - ta)))))
    r = skia.Rect(60, 56, 360, 156); c.drawRect(r.makeOffset(6, 7), fp('#000000', 90 * u)); c.drawRect(r, fp('#F5E9C4', 255 * u)); c.drawRect(r, _stroke('#2B2219', 4, 255 * u, cap=False))
    s = str(yr); f = font(LILITA, 72); c.drawString(s, 210 - f.measureText(s) / 2, 132, f, fp('#2B2219', 255 * u))
