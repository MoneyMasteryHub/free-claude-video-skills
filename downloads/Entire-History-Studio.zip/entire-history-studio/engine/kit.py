"""MMH clean-card tutorial kit (house style). Everything is drawn with skia at 1920x1080, keyed on voiceover time."""
"""Clean-card tutorial editor: light background, word-timed headline, one visual per line (window / phone / diagram)."""
import json, math, subprocess, sys, os, numpy as np, skia
W, H, FPS = 1920, 1080, 30
FF = 'ffmpeg'
FD = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'fonts', '')   # fonts ship with the skill (works on Mac, Windows, Linux)
BOLD = skia.Typeface.MakeFromFile(FD + 'Inter-Bold.otf'); SEMI = skia.Typeface.MakeFromFile(FD + 'Inter-SemiBold.otf')
MED = skia.Typeface.MakeFromFile(FD + 'Inter-Medium.otf'); XB = skia.Typeface.MakeFromFile(FD + 'Inter-ExtraBold.otf')
BG, INK, MUTE, ACC, GRN, LINE = '#F4F2ED', '#16181D', '#6B6F78', '#D9622B', '#1F9D55', '#E3DFD6'
def col(h, a=255): h = h.lstrip('#'); return skia.Color(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), int(max(0, min(255, a))))
def fp(h, a=255, blur=0):
    p = skia.Paint(AntiAlias=True, Color=col(h, a))
    if blur: p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    return p
def font(tf, s): f = skia.Font(tf, s); f.setSubpixel(True); return f
def tw(s, tf, sz): return font(tf, sz).measureText(s)
def text(c, s, x, y, sz, tf=BOLD, h=INK, a=255, align='left'):
    if align == 'center': x -= tw(s, tf, sz) / 2
    elif align == 'right': x -= tw(s, tf, sz)
    c.drawString(s, x, y, font(tf, sz), fp(h, a))
def K(t, t0, d): return max(0.0, min(1.0, (t - t0) / d)) if d > 0 else float(t >= t0)
def ease(u): u = max(0, min(1, u)); return .5 - .5 * math.cos(math.pi * u)
def eout(u): u = max(0, min(1, u)); return 1 - (1 - u) ** 3
def norm(w): return ''.join(ch for ch in w.lower() if ch.isalnum())

WORDS = []   # filled by load_words()

# ---------------------------------------------------------------- sources
class Clip:
    """sequential frame reader for one timeline item"""
    def __init__(self, path, start, speed=1.0, width=1920, dur=30):
        self.path, self.start, self.speed, self.width = path, start, speed, width
        pr = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', path], capture_output=True, text=True).stdout.split(',')
        sw, sh = int(pr[0]), int(pr[1]); self.w = width; self.h = int(round(sh * width / sw / 2) * 2)
        self.p = subprocess.Popen([FF, '-v', 'error', '-ss', f'{start:.3f}', '-i', path, '-t', f'{dur * speed + 1:.2f}', '-vf', f'setpts=PTS/{speed},fps={FPS},scale={self.w}:{self.h}',
                                   '-pix_fmt', 'rgba', '-f', 'rawvideo', '-'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.n = -1; self.img = None
    def at(self, k):
        while self.n < k:
            b = self.p.stdout.read(self.w * self.h * 4)
            if len(b) < self.w * self.h * 4: break
            self.n += 1; self.img = skia.Image.fromarray(np.frombuffer(b, np.uint8).reshape(self.h, self.w, 4).copy(), colorType=skia.kRGBA_8888_ColorType)
        return self.img
    def close(self):
        try: self.p.kill()
        except Exception: pass

class Still:
    def __init__(self, path): self.img = skia.Image.open(path); self.w, self.h = self.img.width(), self.img.height()
    def at(self, k): return self.img
    def close(self): pass

# ---------------------------------------------------------------- drawing pieces
def draw_bg(c):
    c.clear(col(BG))
    for x in range(0, W, 48):
        for y in range(0, H, 48): c.drawCircle(x + 24, y + 24, 1.4, fp('#D8D3C8', 160))

def headline(c, t, heads, y=150):
    """heads: [(t0, 'text', ['key', ...])]; words pop in when the narrator says them"""
    cur = [h for h in heads if h[0] <= t + 1e-6]
    if not cur: return
    t0, s, keys = cur[-1]; t1 = next((h[0] for h in heads if h[0] > t0), 1e9)
    out = 1 - K(t, t1 - .18, .18)
    words = s.split(); sz = 74
    while tw(s, BOLD, sz) > W - 220 and sz > 44: sz -= 2
    # appearance time of each word: when the narrator says it (inside this headline's window), else just after the last one
    times = []; last = t0
    vo = [w for w in WORDS if t0 - .3 <= w[0] < t1]
    for w in words:
        nw = norm(w); hit = next((x[0] for x in vo if nw and (norm(x[2]) == nw or (len(nw) > 3 and norm(x[2]).startswith(nw[:4])))), None)
        tt = max(last, hit if hit is not None else last + .12); times.append(tt); last = tt
    total = tw(s, BOLD, sz); x = W / 2 - total / 2
    for w, tt in zip(words, times):
        u = eout(K(t, tt - .05, .22)); a = 255 * u * out
        key = any(norm(w) == norm(k) for k in keys)
        text(c, w, x, y + 18 * (1 - u), sz, BOLD, ACC if key else INK, a)
        x += tw(w + ' ', BOLD, sz)

def shadow_rr(c, r, rad, a=70):
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 18), rad, rad), fp('#000000', a, 34))

def window(c, img, box, crop, a=1.0, bar=True):
    """macOS-style clean window holding a frame. crop = (cx, cy, z) in source fractions."""
    x0, y0, x1, y1 = box; rad = 16; barh = 40 if bar else 0
    r = skia.Rect(x0, y0, x1, y1)
    c.saveLayerAlpha(None, int(255 * a))
    shadow_rr(c, r, rad); c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), fp('#FFFFFF'))
    if bar:
        for i, h in enumerate(('#FF5F57', '#FEBC2E', '#28C840')): c.drawCircle(x0 + 26 + i * 22, y0 + 20, 6.5, fp(h))
    inner = skia.Rect(x0 + 1, y0 + barh, x1 - 1, y1 - 1)
    if img is not None:
        cx, cy, z = crop; iw, ih = img.width(), img.height(); vw, vh = iw / z, ih / z
        sx = min(max(cx * iw - vw / 2, 0), iw - vw); sy = min(max(cy * ih - vh / 2, 0), ih - vh)
        c.save(); c.clipRRect(skia.RRect.MakeRectXY(inner, 0, 0)) if not bar else c.clipRect(inner)
        if not bar: c.clipRRect(skia.RRect.MakeRectXY(inner, rad, rad))
        c.drawImageRect(img, skia.Rect(sx, sy, sx + vw, sy + vh), inner, skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear))
        c.restore()
    c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), skia.Paint(AntiAlias=True, Color=col('#000000', 30), Style=skia.Paint.kStroke_Style, StrokeWidth=1.2))
    c.restore()

def fit_box(aspect, maxw=1560, maxh=730, cy=650, bar=True):
    hh = maxh - (40 if bar else 0); w = min(maxw, hh * aspect); h = w / aspect + (40 if bar else 0)
    return (W / 2 - w / 2, cy - h / 2, W / 2 + w / 2, cy + h / 2)

def phone(c, img, cx=W / 2, cy=640, h=760, a=1.0):
    w = h * 9 / 16; r = skia.Rect(cx - w / 2 - 14, cy - h / 2 - 14, cx + w / 2 + 14, cy + h / 2 + 14)
    c.saveLayerAlpha(None, int(255 * a)); shadow_rr(c, r, 54, 90)
    c.drawRRect(skia.RRect.MakeRectXY(r, 54, 54), fp('#111214'))
    inner = skia.Rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
    c.save(); c.clipRRect(skia.RRect.MakeRectXY(inner, 42, 42))
    if img is not None: c.drawImageRect(img, inner, skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear))
    c.restore(); c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(cx - 60, cy - h / 2 + 12, cx + 60, cy - h / 2 + 40), 14, 14), fp('#111214'))
    c.restore()

def chip(c, x, y, label, state=0.0, strike=0.0, on=0.0, sz=44, a=1.0):
    """pill: state 0..1 fades it in; strike draws a red line; on turns it green with a tick"""
    w = tw(label, SEMI, sz) + 70 + (44 * on); h = sz + 44; r = skia.Rect(x - w / 2, y - h / 2, x + w / 2, y + h / 2)
    A = 255 * state * a
    if A <= 0: return w
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 8), h / 2, h / 2), fp('#000000', 25 * state * a, 14))
    fill = GRN if on > .5 else '#FFFFFF'
    c.drawRRect(skia.RRect.MakeRectXY(r, h / 2, h / 2), fp(fill, A))
    c.drawRRect(skia.RRect.MakeRectXY(r, h / 2, h / 2), skia.Paint(AntiAlias=True, Color=col(LINE if on <= .5 else GRN, A), Style=skia.Paint.kStroke_Style, StrokeWidth=2))
    tx = x - w / 2 + 35
    if on > .5:
        p = skia.Path(); p.moveTo(tx + 2, y); p.lineTo(tx + 14, y + 12); p.lineTo(tx + 32, y - 12)
        c.drawPath(p, skia.Paint(AntiAlias=True, Color=col('#FFFFFF', A), Style=skia.Paint.kStroke_Style, StrokeWidth=6, StrokeCap=skia.Paint.kRound_Cap)); tx += 44
    text(c, label, tx, y + sz * .36, sz, SEMI, '#FFFFFF' if on > .5 else INK, A)
    if strike > 0: c.drawLine(x - w / 2 + 24, y, x - w / 2 + 24 + (w - 48) * eout(strike), y, skia.Paint(AntiAlias=True, Color=col('#D63B2F', A), StrokeWidth=7, StrokeCap=skia.Paint.kRound_Cap))
    return w

def bars(c, t, t0, items, y0=380, x0=560, x1=1640, gap=170, unit=''):
    vmax = max(v for _, v, _ in items)
    for i, (name, v, h) in enumerate(items):
        b0 = t0 + i * .5; u = eout(K(t, b0, 1.0)); a = 255 * K(t, b0, .3); y = y0 + i * gap
        text(c, name, x0 - 30, y + 46, 40, SEMI, INK, a, 'right')
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x0, y, x1, y + 70), 14, 14), fp('#E9E5DC', a))
        ww = max(16, (x1 - x0) * (v / vmax) * u)
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x0, y, x0 + ww, y + 70), 14, 14), fp(h, a))
        lab = f'{v * u / 1000:,.0f}K' if v >= 10000 else f'{v * u / 1000:,.1f}K'
        text(c, lab, x0 + ww + 22, y + 50, 44, BOLD, INK, a)

"""v2 clean-card tutorial kit: icons, pipeline, studio tracks, callout rings, animated background, sfx log."""
SFX = []
def sfx(kind, t):
    if not any(k == kind and abs(x - t) < .05 for k, x in SFX): SFX.append((kind, t))

def draw_bg2(c, t):
    c.clear(col(BG))
    for i, (bx, by, r, h) in enumerate(((.18, .25, 700, '#F3D9C8'), (.85, .75, 800, '#DCE6F2'))):
        x = W * bx + 60 * math.sin(t * .13 + i * 2); y = H * by + 40 * math.cos(t * .11 + i)
        sh = skia.GradientShader.MakeRadial((x, y), r, [col(h, 120), col(h, 0)]); p = skia.Paint(); p.setShader(sh); c.drawRect(skia.Rect(0, 0, W, H), p)
    for x in range(0, W, 48):
        for y in range(0, H, 48): c.drawCircle(x + 24, y + 24, 1.3, fp('#D2CCBF', 150))

# ---------------------------------------------------------------- icons (stroke drawings in a 100x100 box centred on 0,0)
def _sp(h, w=7, a=255, fill=False):
    p = skia.Paint(AntiAlias=True, Color=col(h, a), StrokeWidth=w, StrokeCap=skia.Paint.kRound_Cap, StrokeJoin=skia.Paint.kRound_Join)
    p.setStyle(skia.Paint.kFill_Style if fill else skia.Paint.kStroke_Style); return p
def icon(c, name, h, a=255):
    s = _sp(h, 7, a); f = _sp(h, 0, a, True)
    if name == 'building':
        c.drawRect(skia.Rect(-28, -34, 28, 38), s); c.drawLine(-40, 38, 40, 38, s)
        for yy in (-18, 0, 18):
            for xx in (-12, 12): c.drawRect(skia.Rect(xx - 5, yy - 5, xx + 5, yy + 5), f)
    elif name == 'doc':
        p = skia.Path(); p.moveTo(-26, -38); p.lineTo(12, -38); p.lineTo(28, -22); p.lineTo(28, 38); p.lineTo(-26, 38); p.close(); c.drawPath(p, s)
        for yy in (-12, 4, 20): c.drawLine(-14, yy, 16, yy, _sp(h, 6, a))
    elif name == 'pen':
        c.save(); c.rotate(45); c.drawRoundRect(skia.Rect(-10, -40, 10, 26), 4, 4, s)
        p = skia.Path(); p.moveTo(-10, 26); p.lineTo(0, 42); p.lineTo(10, 26); c.drawPath(p, s); c.restore()
    elif name == 'search':
        c.drawCircle(-8, -8, 24, s); c.drawLine(10, 10, 34, 34, _sp(h, 9, a))
    elif name == 'photo':
        c.drawRoundRect(skia.Rect(-38, -30, 38, 30), 8, 8, s); c.drawCircle(16, -12, 7, f)
        p = skia.Path(); p.moveTo(-30, 24); p.lineTo(-8, -2); p.lineTo(8, 14); p.lineTo(18, 6); p.lineTo(32, 24); c.drawPath(p, s)
    elif name == 'mic':
        c.drawRoundRect(skia.Rect(-13, -40, 13, 10), 13, 13, s)
        p = skia.Path(); p.addArc(skia.Rect(-26, -18, 26, 24), 0, 180); c.drawPath(p, s); c.drawLine(0, 24, 0, 38, s); c.drawLine(-14, 38, 14, 38, s)
    elif name == 'cut':
        for i, (x0, x1) in enumerate(((-38, 6), (-20, 38), (-38, 18))):
            y = -22 + i * 22; c.drawRoundRect(skia.Rect(x0, y - 7, x1, y + 7), 5, 5, f)
        c.drawLine(2, -40, 2, 40, _sp('#D63B2F', 5, a))
    elif name == 'music':
        c.drawCircle(-18, 24, 12, f); c.drawCircle(22, 16, 12, f); c.drawLine(-7, 24, -7, -30, s); c.drawLine(33, 16, 33, -38, s); c.drawLine(-7, -30, 33, -38, _sp(h, 10, a))
    elif name == 'play':
        c.drawRoundRect(skia.Rect(-40, -30, 40, 30), 10, 10, s)
        p = skia.Path(); p.moveTo(-10, -15); p.lineTo(16, 0); p.lineTo(-10, 15); p.close(); c.drawPath(p, f)
    elif name == 'check':
        p = skia.Path(); p.moveTo(-26, 2); p.lineTo(-8, 20); p.lineTo(28, -20); c.drawPath(p, _sp(h, 10, a))
    elif name == 'phone':
        c.drawRoundRect(skia.Rect(-22, -40, 22, 40), 9, 9, s); c.drawLine(-6, 30, 6, 30, s)

def tile(c, x, y, name, state=1.0, active=0.0, done=0.0, cross=0.0, size=128, label=None, a=1.0):
    """rounded icon tile. state: appear; active: accent fill + pop; done: green with tick; cross: red X"""
    if state <= 0: return
    pop = 1 + .12 * math.sin(math.pi * min(1, active * 1.0)) * (active < 1) if active > 0 else 1
    sc = (.7 + .3 * eout(state)) * pop; A = 255 * min(1, state * 1.6) * a
    c.save(); c.translate(x, y); c.scale(sc, sc)
    r = skia.Rect(-size / 2, -size / 2, size / 2, size / 2); rad = size * .26
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 10), rad, rad), fp('#000000', 40 * A / 255, 18))
    fill = GRN if done > .5 else (ACC if active > .5 else '#FFFFFF')
    c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), fp(fill, A))
    if fill == '#FFFFFF': c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), skia.Paint(AntiAlias=True, Color=col(LINE, A), Style=skia.Paint.kStroke_Style, StrokeWidth=2))
    c.save(); c.scale(size / 128, size / 128)
    icon(c, 'check' if done > .5 else name, '#FFFFFF' if fill != '#FFFFFF' else INK, A)
    c.restore()
    if cross > 0:
        u = eout(cross); p = _sp('#D63B2F', 9, A)
        c.drawLine(-size * .42, -size * .42, -size * .42 + size * .84 * u, -size * .42 + size * .84 * u, p)
    c.restore()
    if label: text(c, label, x, y + size / 2 + 46, 30, SEMI, MUTE, A * .9, 'center')

def claude_burst(c, x, y, r, a=255, rot=0.0):
    c.save(); c.translate(x, y); c.rotate(rot)
    p = skia.Paint(AntiAlias=True, Color=col(ACC, a), StrokeWidth=r * .22, StrokeCap=skia.Paint.kRound_Cap)
    for k in range(12):
        ang = k * math.pi / 6; rr = r * (1.0 if k % 2 == 0 else .78)
        c.drawLine(math.cos(ang) * r * .18, math.sin(ang) * r * .18, math.cos(ang) * rr, math.sin(ang) * rr, p)
    c.restore()

def ring(c, box, crop, img_wh, pt, t, t0, rad=70, a=1.0):
    """orange hand-drawn ring around a point (source fractions) inside a window"""
    u = eout(K(t, t0, .45))
    if u <= 0: return
    x0, y0, x1, y1 = box; inner = (x0, y0 + 40, x1, y1)
    cx, cy, z = crop; iw, ih = img_wh; vw, vh = iw / z, ih / z
    sx = min(max(cx * iw - vw / 2, 0), iw - vw); sy = min(max(cy * ih - vh / 2, 0), ih - vh)
    px = inner[0] + (pt[0] * iw - sx) / vw * (inner[2] - inner[0]); py = inner[1] + (pt[1] * ih - sy) / vh * (inner[3] - inner[1])
    p = skia.Path(); p.addArc(skia.Rect(px - rad * 1.5, py - rad, px + rad * 1.5, py + rad), -100, 350 * u)
    c.drawPath(p, skia.Paint(AntiAlias=True, Color=col(ACC, 255 * a), Style=skia.Paint.kStroke_Style, StrokeWidth=8, StrokeCap=skia.Paint.kRound_Cap))

def prompt_box(c, t, t0, s, y=650, a=1.0, cps=26):
    w = 1100; r = skia.Rect(W / 2 - w / 2, y - 60, W / 2 + w / 2, y + 60)
    shadow_rr(c, r, 30); c.drawRRect(skia.RRect.MakeRectXY(r, 30, 30), fp('#FFFFFF', 255 * a))
    n = int(min(len(s), max(0, (t - t0)) * cps)); shown = s[:n]
    if n and n < len(s) and int((t - t0) * cps) != int((t - t0 - 1 / FPS) * cps): sfx('key', t)
    text(c, shown, r.left() + 50, y + 18, 50, MED, INK, 255 * a)
    if int(t * 2.2) % 2 == 0: c.drawRect(skia.Rect(r.left() + 54 + tw(shown, MED, 50), y - 26, r.left() + 58 + tw(shown, MED, 50), y + 26), fp(ACC, 255 * a))
    c.drawCircle(r.right() - 60, y, 30, fp(ACC if n >= len(s) else '#D7D2C8', 255 * a))
    p = skia.Path(); p.moveTo(r.right() - 60, y + 13); p.lineTo(r.right() - 60, y - 13); p.moveTo(r.right() - 71, y - 2); p.lineTo(r.right() - 60, y - 13); p.lineTo(r.right() - 49, y - 2)
    c.drawPath(p, _sp('#FFFFFF', 5, 255 * a))

def doc_card(c, x, y, rot, title, sub, a=1.0, s=1.0):
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    r = skia.Rect(-170, -215, 170, 215); shadow_rr(c, r, 10, 50); c.drawRRect(skia.RRect.MakeRectXY(r, 10, 10), fp('#FFFFFF', 255 * a))
    text(c, 'FORM 10-K', -140, -160, 34, XB, INK, 255 * a); text(c, title, -140, -118, 24, SEMI, MUTE, 255 * a); text(c, sub, -140, -86, 24, SEMI, ACC, 255 * a)
    for k in range(9): c.drawRect(skia.Rect(-140, -50 + k * 26, 140 - (k % 3) * 40, -40 + k * 26), fp('#E6E2D9', 255 * a))
    c.restore()

def fact_row(c, x, y, label, val, t, t0, a=1.0):
    u = eout(K(t, t0, .35))
    if u <= 0: return
    if abs(t - t0) < 1 / FPS: sfx('pop', t0)
    w = 860; r = skia.Rect(x, y - 40, x + w, y + 40); A = 255 * u * a
    c.save(); c.translate(40 * (1 - u), 0)
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 6), 18, 18), fp('#000000', 25 * u, 12)); c.drawRRect(skia.RRect.MakeRectXY(r, 18, 18), fp('#FFFFFF', A))
    text(c, label, x + 34, y + 12, 34, MED, MUTE, A); text(c, val, x + w - 110, y + 13, 40, XB, INK, A, 'right')
    k = eout(K(t, t0 + .35, .3)); c.drawCircle(x + w - 50, y, 26, fp(GRN, A * k))
    c.save(); c.translate(x + w - 50, y); c.scale(.55, .55); icon(c, 'check', '#FFFFFF', A * k); c.restore()
    c.restore()

def photo_card(c, img, x, y, rot, w, credit, u, a=1.0):
    if u <= 0 or img is None: return
    h = w * img.height() / img.width()
    c.save(); c.translate(x, y + 60 * (1 - u)); c.rotate(rot * u); s = .85 + .15 * u; c.scale(s, s)
    r = skia.Rect(-w / 2 - 14, -h / 2 - 14, w / 2 + 14, h / 2 + 60); shadow_rr(c, r, 8, 60)
    c.drawRRect(skia.RRect.MakeRectXY(r, 8, 8), fp('#FFFFFF', 255 * u * a))
    c.drawImageRect(img, skia.Rect(-w / 2, -h / 2, w / 2, h / 2), skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear))
    text(c, credit, -w / 2, h / 2 + 42, 24, SEMI, MUTE, 255 * u * a)
    c.restore()

def studio(c, t, t_voice, t_edit, t_music, x0=330, x1=1590, y0=520):
    """three tracks building up: voice waveform, edit clips, music"""
    rows = [('mic', 'Voice', t_voice, ACC), ('cut', 'Edit', t_edit, '#4C7DD8'), ('music', 'Music', t_music, GRN)]
    for i, (ic, lab, t0, h) in enumerate(rows):
        y = y0 + i * 150; u = eout(K(t, t0, .4))
        if u <= 0: continue
        if abs(t - t0) < 1 / FPS: sfx('pop', t0)
        A = 255 * u
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x0, y - 55, x1, y + 55), 22, 22), fp('#FFFFFF', A))
        c.save(); c.translate(x0 + 70, y); c.scale(.5, .5); icon(c, ic, h, A); c.restore()
        gx0 = x0 + 150; gx1 = gx0 + (x1 - 40 - gx0) * u
        if ic == 'mic':
            for k in range(int((gx1 - gx0) / 12)):
                amp = (abs(math.sin(k * .7 + t * 9)) * .6 + .4 * abs(math.sin(k * .23 + 1))) * 38
                c.drawRoundRect(skia.Rect(gx0 + k * 12, y - amp, gx0 + k * 12 + 6, y + amp), 3, 3, fp(h, A))
        elif ic == 'cut':
            xs = gx0
            for k, wv in enumerate((140, 220, 110, 260, 180, 150, 240)):
                if xs >= gx1: break
                ww = min(wv, gx1 - xs); c.drawRoundRect(skia.Rect(xs, y - 34, xs + ww - 8, y + 34), 8, 8, fp(h if k % 2 == 0 else '#8FB0EA', A)); xs += wv
        else:
            p = skia.Path(); p.moveTo(gx0, y)
            for xx in range(int(gx0), int(gx1), 6): p.lineTo(xx, y + 26 * math.sin(xx * .03 - t * 4))
            c.drawPath(p, _sp(h, 6, A))

def video_card(c, img, t, t0, label, cx=W / 2, cy=640, w=1000, a=1.0):
    u = eout(K(t, t0, .45))
    if u <= 0: return
    h = w * 9 / 16; c.save(); c.translate(cx, cy + 40 * (1 - u)); s = .9 + .1 * u; c.scale(s, s)
    r = skia.Rect(-w / 2, -h / 2, w / 2, h / 2 + 90); shadow_rr(c, r, 22, 80); c.drawRRect(skia.RRect.MakeRectXY(r, 22, 22), fp('#FFFFFF', 255 * u * a))
    c.save(); c.clipRRect(skia.RRect.MakeRectXY(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), 22, 22))
    if img is not None: c.drawImageRect(img, skia.Rect(-w / 2, -h / 2, w / 2, h / 2), skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear))
    c.restore()
    prog = min(1, (t - t0) / 8); c.drawRoundRect(skia.Rect(-w / 2 + 30, h / 2 + 22, w / 2 - 30, h / 2 + 30), 4, 4, fp('#E6E2D9', 255 * u))
    c.drawRoundRect(skia.Rect(-w / 2 + 30, h / 2 + 22, -w / 2 + 30 + (w - 60) * prog, h / 2 + 30), 4, 4, fp(ACC, 255 * u))
    text(c, label, -w / 2 + 30, h / 2 + 72, 30, SEMI, INK, 255 * u)
    c.restore()

_icon0 = icon  # chain onto the base icon set
def icon(c, name, h, a=255):
    s = _sp(h, 7, a); f = _sp(h, 0, a, True)
    if name == 'chat':
        c.drawRoundRect(skia.Rect(-38, -32, 38, 18), 14, 14, s); p = skia.Path(); p.moveTo(-18, 18); p.lineTo(-26, 36); p.lineTo(0, 18); c.drawPath(p, s)
    elif name == 'code':
        p = skia.Path(); p.moveTo(-14, -22); p.lineTo(-36, 0); p.lineTo(-14, 22); p.moveTo(14, -22); p.lineTo(36, 0); p.lineTo(14, 22); c.drawPath(p, s); c.drawLine(6, -30, -6, 30, s)
    elif name == 'terminal':
        c.drawRoundRect(skia.Rect(-40, -30, 40, 30), 8, 8, s); p = skia.Path(); p.moveTo(-24, -10); p.lineTo(-10, 2); p.lineTo(-24, 14); c.drawPath(p, s); c.drawLine(0, 16, 22, 16, s)
    elif name == 'folder':
        p = skia.Path(); p.moveTo(-40, -24); p.lineTo(-12, -24); p.lineTo(-4, -14); p.lineTo(40, -14); p.lineTo(40, 30); p.lineTo(-40, 30); p.close(); c.drawPath(p, s)
    elif name == 'clock':
        c.drawCircle(0, 0, 36, s); c.drawLine(0, 0, 0, -22, s); c.drawLine(0, 0, 16, 8, s)
    elif name == 'down':
        p = skia.Path(); p.moveTo(-38, -26); p.lineTo(-12, -2); p.lineTo(4, -16); p.lineTo(36, 22); c.drawPath(p, _sp('#D63B2F', 8, a))
        p2 = skia.Path(); p2.moveTo(18, 24); p2.lineTo(38, 24); p2.lineTo(38, 4); c.drawPath(p2, _sp('#D63B2F', 8, a))
    elif name == 'dollar':
        c.drawCircle(0, 0, 38, s); text(c, '$', 0, 18, 54, XB, h, a, 'center')
    elif name == 'mask':
        p = skia.Path(); p.moveTo(-40, -16); p.quadTo(0, -30, 40, -16); p.quadTo(36, 22, 0, 26); p.quadTo(-36, 22, -40, -16); p.close(); c.drawPath(p, s)
        c.drawOval(skia.Rect(-26, -10, -8, 2), f); c.drawOval(skia.Rect(8, -10, 26, 2), f)
    elif name == 'bolt':
        p = skia.Path(); p.moveTo(8, -40); p.lineTo(-22, 6); p.lineTo(0, 6); p.lineTo(-8, 40); p.lineTo(24, -8); p.lineTo(2, -8); p.close(); c.drawPath(p, f)
    elif name == 'crown':
        p = skia.Path(); p.moveTo(-38, 24); p.lineTo(-38, -20); p.lineTo(-18, 0); p.lineTo(0, -30); p.lineTo(18, 0); p.lineTo(38, -20); p.lineTo(38, 24); p.close(); c.drawPath(p, s)
    elif name == 'noface':
        c.drawCircle(0, 0, 34, s); c.drawCircle(-12, -6, 4, f); c.drawCircle(12, -6, 4, f); c.drawLine(-12, 14, 12, 14, s); c.drawLine(-40, 40, 40, -40, _sp('#D63B2F', 8, a))
    elif name == 'thumb':
        p = skia.Path(); p.moveTo(-30, -4); p.lineTo(-30, 34); p.moveTo(-18, 34); p.lineTo(22, 34); p.quadTo(34, 34, 36, 22); p.lineTo(40, -2); p.quadTo(40, -12, 30, -12)
        p.lineTo(8, -12); p.lineTo(12, -32); p.quadTo(10, -42, 0, -40); p.lineTo(-18, -6); p.close(); c.drawPath(p, s)
    elif name == 'bell':
        p = skia.Path(); p.moveTo(-28, 20); p.quadTo(-24, 10, -24, -6); p.quadTo(-22, -32, 0, -34); p.quadTo(22, -32, 24, -6); p.quadTo(24, 10, 28, 20); p.close(); c.drawPath(p, s); c.drawCircle(0, 30, 6, f)
    elif name == 'file':
        p = skia.Path(); p.moveTo(-26, -38); p.lineTo(12, -38); p.lineTo(28, -22); p.lineTo(28, 38); p.lineTo(-26, 38); p.close(); c.drawPath(p, s); text(c, 'MP3', 0, 16, 22, XB, h, a, 'center')
    elif name == 'copy':
        c.drawRoundRect(skia.Rect(-30, -22, 14, 34), 6, 6, s); c.drawRoundRect(skia.Rect(-14, -38, 30, 18), 6, 6, s)
    elif name == 'paste':
        c.drawRoundRect(skia.Rect(-28, -30, 28, 38), 6, 6, s); c.drawRoundRect(skia.Rect(-12, -40, 12, -24), 4, 4, f)
    elif name == 'upload':
        c.drawLine(0, 22, 0, -30, s); p = skia.Path(); p.moveTo(-18, -12); p.lineTo(0, -30); p.lineTo(18, -12); c.drawPath(p, s); c.drawLine(-34, 36, 34, 36, s)
    elif name == 'eye':
        p = skia.Path(); p.moveTo(-40, 0); p.quadTo(0, -36, 40, 0); p.quadTo(0, 36, -40, 0); c.drawPath(p, s); c.drawCircle(0, 0, 12, f)
    elif name == 'shield':
        p = skia.Path(); p.moveTo(0, -38); p.lineTo(32, -26); p.quadTo(32, 20, 0, 38); p.quadTo(-32, 20, -32, -26); p.close(); c.drawPath(p, s)
        p2 = skia.Path(); p2.moveTo(-14, 0); p2.lineTo(-3, 11); p2.lineTo(16, -10); c.drawPath(p2, s)
    else: _icon0(c, name, h, a)


def card_row(c, t, items, y=640, w=360, h=230, gap=40, a=1.0):
    """cards with an icon and a title, popping in at their times. items: [(icon, title, t0)]"""
    n = len(items); tot = n * w + (n - 1) * gap; x0 = W / 2 - tot / 2
    for j, (ic, title, t0) in enumerate(items):
        u = eout(K(t, t0, .4))
        if u <= 0: continue
        if abs(t - t0) < 1 / FPS: sfx('pop', t0)
        x = x0 + j * (w + gap); c.save(); c.translate(x + w / 2, y + 40 * (1 - u)); s = .9 + .1 * u; c.scale(s, s)
        r = skia.Rect(-w / 2, -h / 2, w / 2, h / 2); shadow_rr(c, r, 26, 50); c.drawRRect(skia.RRect.MakeRectXY(r, 26, 26), fp('#FFFFFF', 255 * u * a))
        if ic:
            c.save(); c.translate(0, -30); c.scale(.62, .62); icon(c, ic, ACC, 255 * u); c.restore()
        sz = 36
        while tw(title, BOLD, sz) > w - 40 and sz > 22: sz -= 2
        text(c, title, 0, (62 if ic else 12), sz, BOLD, INK, 255 * u, 'center')
        c.restore()

def big_button(c, t, t0, label, icon_name, pressed_t=None, done_label=None, cy=600, color='#FF0033'):
    u = eout(K(t, t0, .4))
    if u <= 0: return
    pr = pressed_t is not None and t >= pressed_t; k = K(t, pressed_t or 1e9, .15)
    sc = (0.85 + .15 * u) * (1 - .06 * math.sin(math.pi * k) if pr else 1)
    lab = done_label if (pr and k >= 1 and done_label) else label; fill = color   # stays in the brand colour after the press (Like = YouTube red)
    w = tw(lab, XB, 60) + 210; c.save(); c.translate(W / 2, cy); c.scale(sc, sc)
    r = skia.Rect(-w / 2, -70, w / 2, 70); shadow_rr(c, r, 70, 70); c.drawRRect(skia.RRect.MakeRectXY(r, 70, 70), fp(fill, 255 * u))
    c.save(); c.translate(-w / 2 + 85, 0); c.scale(.7, .7); icon(c, icon_name, '#FFFFFF' if fill != '#E9E5DC' else INK, 255 * u); c.restore()
    text(c, lab, -w / 2 + 150, 22, 60, XB, '#FFFFFF' if fill != '#E9E5DC' else INK, 255 * u)
    c.restore()
    if pr and abs(t - pressed_t) < 1 / FPS: sfx('pop', pressed_t)
    if pr:  # cursor tap ripple
        rr = 40 + 160 * eout(K(t, pressed_t, .5)); c.drawCircle(W / 2 + 60, cy + 10, rr, skia.Paint(AntiAlias=True, Color=col(INK, 110 * (1 - K(t, pressed_t, .5))), Style=skia.Paint.kStroke_Style, StrokeWidth=6))

def bubble(c, x, y, s, u, likes=None, win=False):
    if u <= 0: return
    w = tw(s, SEMI, 38) + 120; h = 96; c.save(); c.translate(x, y + 30 * (1 - u)); c.scale(.9 + .1 * u, .9 + .1 * u)
    r = skia.Rect(-w / 2, -h / 2, w / 2, h / 2); shadow_rr(c, r, 30, 45); c.drawRRect(skia.RRect.MakeRectXY(r, 30, 30), fp('#FFFFFF', 255 * u))
    if win: c.drawRRect(skia.RRect.MakeRectXY(r, 30, 30), skia.Paint(AntiAlias=True, Color=col(ACC, 255 * u), Style=skia.Paint.kStroke_Style, StrokeWidth=5))
    c.drawCircle(-w / 2 + 50, 0, 24, fp('#D9D3C7', 255 * u)); text(c, s, -w / 2 + 92, 13, 38, SEMI, INK, 255 * u)
    if likes is not None:
        lw = tw(f'{likes:,}', BOLD, 30) + 70; rr = skia.Rect(w / 2 - lw - 10, h / 2 - 6, w / 2 - 10, h / 2 + 40)
        c.drawRRect(skia.RRect.MakeRectXY(rr, 22, 22), fp(ACC if win else '#FFFFFF', 255 * u))
        c.save(); c.translate(rr.left() + 26, rr.centerY()); c.scale(.3, .3); icon(c, 'thumb', '#FFFFFF' if win else INK, 255 * u); c.restore()
        text(c, f'{likes:,}', rr.left() + 50, rr.centerY() + 11, 30, BOLD, '#FFFFFF' if win else INK, 255 * u)
    if win:
        c.save(); c.translate(w / 2 - 20, -h / 2 - 10); c.rotate(20); c.scale(.55, .55); icon(c, 'crown', ACC, 255 * u); c.restore()
    c.restore()

def T(phrase, after=0.0, nth=0):
    """time the narrator starts saying `phrase` (first match after `after`)"""
    ws = [norm(x) for x in phrase.split()]; hits = []
    for i in range(len(WORDS) - len(ws) + 1):
        if WORDS[i][0] >= after and all(norm(WORDS[i + j][2]) == ws[j] for j in range(len(ws))): hits.append(WORDS[i][0])
    if not hits: raise SystemExit('cue not found: ' + phrase)
    return hits[nth]

def rr(c, r, rad, h, a=255): c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), fp(h, a))
def stroke_rr(c, r, rad, h, w=2, a=255): c.drawRRect(skia.RRect.MakeRectXY(r, rad, rad), skia.Paint(AntiAlias=True, Color=col(h, a), Style=skia.Paint.kStroke_Style, StrokeWidth=w))
def lerp(a, b, u): return a + (b - a) * u

def cursor(c, x, y, click=0.0, a=255):
    """mouse pointer; click 0..1 draws a soft ripple and a small press"""
    if click > 0:
        u = eout(click); c.drawCircle(x, y, 14 + 46 * u, skia.Paint(AntiAlias=True, Color=col(INK, 110 * (1 - u)), Style=skia.Paint.kStroke_Style, StrokeWidth=5))
    s = 1 - .12 * math.sin(math.pi * min(1, click * 2.2)) if 0 < click < .46 else 1
    c.save(); c.translate(x, y); c.scale(1.9 * s, 1.9 * s)
    p = skia.Path(); p.moveTo(0, 0); p.lineTo(0, 24); p.lineTo(6.2, 18.6); p.lineTo(10.4, 28); p.lineTo(14.6, 26.2); p.lineTo(10.4, 17); p.lineTo(18, 17); p.close()
    c.drawPath(p, fp('#000000', 70 * a / 255, 4)); c.drawPath(p, fp('#FFFFFF', a)); c.drawPath(p, skia.Paint(AntiAlias=True, Color=col('#16181D', a), Style=skia.Paint.kStroke_Style, StrokeWidth=1.8, StrokeJoin=skia.Paint.kRound_Join))
    c.restore()

def path_pos(pts, t):
    """pts: [(time, x, y)] eased between stops"""
    if t <= pts[0][0]: return pts[0][1:]
    for a, b in zip(pts, pts[1:]):
        if t <= b[0]: u = ease(K(t, a[0], b[0] - a[0])); return (lerp(a[1], b[1], u), lerp(a[2], b[2], u))
    return pts[-1][1:]

def arrow(c, x0, y0, x1, y1, u, h=ACC, w=8):
    if u <= 0: return
    x = lerp(x0, x1, u); y = lerp(y0, y1, u); c.drawLine(x0, y0, x, y, _sp(h, w))
    if u > .97:
        ang = math.atan2(y1 - y0, x1 - x0); p = skia.Path()
        for s in (-1, 1): p.moveTo(x1, y1); p.lineTo(x1 - 26 * math.cos(ang + s * .5), y1 - 26 * math.sin(ang + s * .5))
        c.drawPath(p, _sp(h, w))

def pill(c, cx, cy, s, u, h=GRN, ic=True):
    if u <= 0: return
    u = eout(u); w = tw(s, SEMI, 34) + (86 if ic else 50); r = skia.Rect(cx - w / 2, cy - 34, cx + w / 2, cy + 34)
    c.save(); c.translate(0, 16 * (1 - u)); shadow_rr(c, r, 34, 40); rr(c, r, 34, '#FFFFFF', 255 * u); stroke_rr(c, r, 34, LINE, 2, 255 * u)
    if ic:
        c.drawCircle(r.left() + 38, cy, 17, fp(h, 255 * u)); c.save(); c.translate(r.left() + 38, cy); c.scale(.3, .3); icon(c, 'check', '#FFFFFF', 255 * u); c.restore()
    text(c, s, r.left() + (66 if ic else 25), cy + 12, 34, SEMI, INK, 255 * u); c.restore()

def laptop(c, cx, cy, w, a=255, screen=None):
    h = w * .62; r = skia.Rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
    shadow_rr(c, r, 22, 60 * a / 255); rr(c, r, 22, '#1B1D22', a); inner = skia.Rect(r.left() + 14, r.top() + 14, r.right() - 14, r.bottom() - 14); rr(c, inner, 10, '#FFFFFF', a)
    base = skia.Path(); base.moveTo(cx - w * .62, cy + h / 2 + 6); base.lineTo(cx + w * .62, cy + h / 2 + 6); base.lineTo(cx + w * .56, cy + h / 2 + 30); base.lineTo(cx - w * .56, cy + h / 2 + 30); base.close()
    c.drawPath(base, fp('#C9CCD3', a)); c.drawRoundRect(skia.Rect(cx - 60, cy + h / 2 + 6, cx + 60, cy + h / 2 + 14), 4, 4, fp('#A9ADB6', a))
    return inner

_CL = {}
def clip(key, path, start, v, width=960, speed=1.0, dur=40):
    """sequential frames of a video, starting at `start` when first asked"""
    if key not in _CL: _CL[key] = Clip(path, start, speed, width, dur=dur); _CL[key].base = v
    return _CL[key].at(max(0, int((v - _CL[key].base) * FPS)))
def reset_clips():
    for x in _CL.values(): x.close()
    _CL.clear()

def card(c, cx, cy, w, h, u, rad=24, fill='#FFFFFF', border=LINE, bw=2):
    """white card that rises in; returns alpha"""
    e = eout(u); A = 255 * min(1, u * 1.6)
    if u <= 0: return 0
    r = skia.Rect(cx - w / 2, cy - h / 2 + 26 * (1 - e), cx + w / 2, cy + h / 2 + 26 * (1 - e))
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 14), rad, rad), fp('#000000', 46 * A / 255, 26)); rr(c, r, rad, fill, A)
    if border: stroke_rr(c, r, rad, border, bw, A)
    return A

def icon_at(c, name, x, y, s, h=INK, a=255):
    c.save(); c.translate(x, y); c.scale(s, s); icon(c, name, h, a); c.restore()

def info_card(c, cx, cy, w, h, u, ic, title, sub=None, ic_h=INK, hot=0.0):
    A = card(c, cx, cy, w, h, u, border=ACC if hot > .5 else LINE, bw=4 if hot > .5 else 2)
    if not A: return
    icon_at(c, ic, cx, cy - h / 2 + 78, .78, ic_h, A)
    sz = 36
    while tw(title, BOLD, sz) > w - 40 and sz > 24: sz -= 1
    text(c, title, cx, cy + 34, sz, BOLD, INK, A, 'center')
    if sub:
        s2 = 27
        while tw(sub, MED, s2) > w - 36 and s2 > 20: s2 -= 1
        text(c, sub, cx, cy + 78, s2, MED, MUTE, A, 'center')

def check_row(c, x, y, w, s, t, t0, done_t=None):
    u = eout(K(t, t0, .35))
    if u <= 0: return
    if abs(t - t0) < 1 / FPS: sfx('pop', t0)
    A = 255 * u; r = skia.Rect(x, y - 44, x + w, y + 44); c.save(); c.translate(40 * (1 - u), 0)
    c.drawRRect(skia.RRect.MakeRectXY(r.makeOffset(0, 6), 18, 18), fp('#000000', 25 * u, 12)); rr(c, r, 18, '#FFFFFF', A)
    k = eout(K(t, (done_t if done_t is not None else t0 + .35), .3)); c.drawCircle(x + 52, y, 24, fp('#E9E5DC', A)); c.drawCircle(x + 52, y, 24 * k, fp(GRN, A))
    icon_at(c, 'check', x + 52, y, .5 * k, '#FFFFFF', A); text(c, s, x + 98, y + 13, 36, SEMI, INK, A); c.restore()

def app_window(c, r, u, title='', dark_bar=False):
    """a clean app window; returns the content rect (clip is the caller's job)"""
    A = 255 * min(1, u * 1.6)
    shadow_rr(c, r, 22, 70 * A / 255); rr(c, r, 22, '#FFFFFF', A)
    c.save(); c.clipRRect(skia.RRect.MakeRectXY(r, 22, 22)); c.drawRect(skia.Rect(r.left(), r.top(), r.right(), r.top() + 58), fp('#F1F0EC', A)); c.restore()
    for k, h in enumerate(('#FF5F57', '#FEBC2E', '#28C840')): c.drawCircle(r.left() + 32 + k * 25, r.top() + 29, 7.5, fp(h, A))
    if title: text(c, title, r.centerX(), r.top() + 38, 24, SEMI, MUTE, A, 'center')
    return skia.Rect(r.left(), r.top() + 58, r.right(), r.bottom())

def vcard(c, img, cx, cy, w, u, label=None, hot=0.0, a=1.0):
    """a video frame in a white card (16:9), optional label under it"""
    if u <= 0: return
    e = eout(u); h = w * 9 / 16; A = 255 * min(1, u * 1.6) * a
    c.save(); c.translate(cx, cy + 30 * (1 - e)); s = (.93 + .07 * e) * (1 + .04 * hot); c.scale(s, s)
    r = skia.Rect(-w / 2 - 10, -h / 2 - 10, w / 2 + 10, h / 2 + (58 if label else 10)); shadow_rr(c, r, 18, 70 * A / 255); rr(c, r, 18, '#FFFFFF', A)
    if hot > 0: stroke_rr(c, r, 18, ACC, 5, A * hot)
    c.save(); c.clipRRect(skia.RRect.MakeRectXY(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), 12, 12)); c.drawRect(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), fp('#16181D', A))
    if img is not None:
        iw, ih = img.width(), img.height(); k = max(w / iw, h / ih); dw, dh = iw * k, ih * k
        c.drawImageRect(img, skia.Rect(-dw / 2, -dh / 2, dw / 2, dh / 2), skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear), skia.Paint(Alphaf=A / 255))
    c.restore()
    if label: text(c, label, -w / 2 + 6, h / 2 + 40, min(28, w / 16), SEMI, INK, A)
    c.restore()

def script_card(c, cx, cy, t, t0, lines, hl=None, hl_t=0, w=1180):
    u = K(t, t0, .4); A = card(c, cx, cy, w, 120 + 74 * len(lines), u)
    if not A: return
    x = cx - w / 2 + 60; y = cy - 37 * len(lines) + 18; text(c, 'SCRIPT', x, y - 26, 22, BOLD, MUTE, A)
    for j, ln in enumerate(lines):
        n = int(max(0, t - t0 - .3 - j * .55) * 60); yy = y + 44 + j * 74
        if hl == j:
            k = eout(K(t, hl_t, .4)); rr(c, skia.Rect(x - 12, yy - 44, x - 12 + (tw(ln, MED, 40) + 24) * k, yy + 16), 8, '#FFE27A', A)
        text(c, ln[:n], x, yy, 40, MED, INK, A)


def load_words(path='words.json'):
    """word timings [[start, end, word], ...] from tools/transcribe.py"""
    global WORDS
    WORDS[:] = json.load(open(path)); return WORDS
