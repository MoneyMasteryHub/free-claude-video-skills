"""SITCOM TOON cartoon kit for 'Entire History of' films (adapted from the Lemo-Opuscar 'Sci-Fi Sitcom Toon' style grammar,
with our own cast and a TIME PORTAL as the travel device between eras).

Rules this kit enforces:
- thick near-black outlines that BOIL (3 drawings cycling at 12 fps) and keep the same width on screen at any zoom
- flat fills, one hard-edged darker shadow shape per form, no gradients; skies are flat colour bands
- big white touching eyes with tiny pupils, brows carry the emotion, elastic parametric mouths
- characters animate on twos (12 fps); camera moves on ones
- the portal is the ONLY thing that glows

  person(c, x, feet_y, s, SPEC['tsar'], t, pose, expr, talk=True, face=1)
  guide(c, x, y, s, t, ...)         Quill, the time-travelling historian (our own design)
  blob(c, x, y, w, land('JPN'), col, t, expr)   a country as a character
  room / outdoor / wall              flat-band sets;  throne, door, ship, house, monastery  props
  bubble / tag / photo_card / title_card / portal / portal_wipe / closeup
"""
import math, os
from kit import *
from moves import _clamp, _sm, _stroke, _trim

HERE = os.path.dirname(os.path.abspath(__file__))
LILITA = skia.Typeface.MakeFromFile(os.path.join(HERE, '..', 'assets', 'fonts', 'LilitaOne-Regular.ttf'))
HAND = skia.Typeface.MakeFromFile(os.path.join(HERE, '..', 'assets', 'fonts', 'PatrickHand-Regular.ttf'))
INK = '#221626'; INKC = INK; WHITE = '#FFFFFF'; BRASS = '#E2B33C'; CREAM = '#FFF4DC'
PORTAL = ('#4FD8FF', '#B8F1FF', '#1A8FD6')          # glow colours: reserved for the time portal only
MOUTH_IN, TONGUE = '#4A1A2A', '#E8637A'
SKIN = [('#F2C9A0', '#D9A57C'), ('#E3AE84', '#C48A60'), ('#B97E55', '#946039'), ('#8A5634', '#6A3E22')]
_B = [0]                                              # boil drawing index (0..2), 12 fps

def tick(t): _B[0] = int(t * 12) % 3
def on_twos(t): return math.floor(t * 12) / 12
def _h(i): return (math.sin(i * 12.9898 + 78.233) * 43758.5453) % 1.0
def darker(h, k=.78):
    c = col(h); r, g, b = (c >> 16) & 255, (c >> 8) & 255, c & 255
    return '#%02X%02X%02X' % (int(r * k), int(g * k), int(b * k))

# ------------------------------------------------------------------ pen
def _sc(c):
    m = c.getTotalMatrix(); return max(1e-3, math.sqrt(abs(m.getScaleX() * m.getScaleY() - m.getSkewX() * m.getSkewY())))
def ink(c, w=7, h=INK, a=255, boil=1.0):
    s = _sc(c); p = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeWidth=w / s, Color=col(h, a),
                               StrokeCap=skia.Paint.kRound_Cap, StrokeJoin=skia.Paint.kRound_Join)
    if boil: p.setPathEffect(skia.DiscretePathEffect.Make(12 / s, 1.5 * boil / s, 7 + _B[0] * 31))
    return p
def flat(h, a=255): return skia.Paint(AntiAlias=True, Color=col(h, a))
def spline(pts, closed=True):
    """Catmull-Rom through the points -> smooth skia path (hand-drawn curves, not geometry)"""
    p = skia.Path(); n = len(pts)
    if n < 2: return p
    if closed:
        p.moveTo(*pts[0])
        for i in range(n):
            p0, p1, p2, p3 = pts[i - 1], pts[i], pts[(i + 1) % n], pts[(i + 2) % n]
            p.cubicTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1])
        p.close()
    else:
        P = [pts[0]] + list(pts) + [pts[-1]]; p.moveTo(*pts[0])
        for i in range(n - 1):
            p0, p1, p2, p3 = P[i], P[i + 1], P[i + 2], P[i + 3]
            p.cubicTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1])
    return p
def ell(cx, cy, rx, ry): p = skia.Path(); p.addOval(skia.Rect(cx - rx, cy - ry, cx + rx, cy + ry)); return p
def rr(x0, y0, x1, y1, r): p = skia.Path(); p.addRoundRect(skia.Rect(x0, y0, x1, y1), r, r); return p
def poly(pts): p = skia.Path(); p.addPoly(pts, True); return p
def _open(pts):
    p = skia.Path(); p.moveTo(*pts[0]); [p.lineTo(*q) for q in pts[1:]]; return p
def shape(c, path, fill, shade=True, w=7, a=255, sdir=(1, 1)):
    """flat fill + one hard-edged shadow band away from the light (top-left) + boiling ink outline"""
    c.drawPath(path, flat(fill, a))
    if shade:
        sh = darker(fill) if shade is True else shade; k = 13 / _sc(c)
        c.save(); c.clipPath(path, skia.ClipOp.kIntersect, True)
        c.drawPath(path, flat(sh, a)); c.translate(-k * sdir[0], -k * .8 * sdir[1]); c.drawPath(path, flat(fill, a)); c.restore()
    if w: c.drawPath(path, ink(c, w, INK, a))
def line(c, pts, w=7, h=INK, a=255): c.drawPath(spline(pts, False) if len(pts) > 2 else _open(pts), ink(c, w, h, a))
def noodle(c, pts, width, fill, a=255):
    """a rubbery limb: a smooth tube through the points, filled and outlined"""
    src = spline(pts, False); out = skia.Path()
    skia.Paint(StrokeWidth=width, Style=skia.Paint.kStroke_Style, StrokeCap=skia.Paint.kRound_Cap, StrokeJoin=skia.Paint.kRound_Join).getFillPath(src, out)
    shape(c, out, fill, False, 6, a)
def dot(c, x, y, r, h=INK, a=255): c.drawCircle(x, y, r, flat(h, a))

# ------------------------------------------------------------------ face parts
def eye(c, cx, cy, rx, ry, lid=0.0, look=(0, 0), pupil=5.0, skin='#F2C9A0', closed=False, jitter=0.0):
    if closed:
        p = skia.Path(); p.addArc(skia.Rect(cx - rx * .8, cy - ry * .3, cx + rx * .8, cy + ry * .6), 200, 140); c.drawPath(p, ink(c, 6)); return
    E = ell(cx, cy, rx, ry); c.drawPath(E, flat(WHITE))
    c.save(); c.clipPath(E, skia.ClipOp.kIntersect, True)
    c.drawCircle(cx + look[0] * rx * .5 + jitter, cy + look[1] * ry * .45, pupil, flat(INK))
    if lid > 0:
        yl = cy - ry + lid * 2 * ry; c.drawRect(skia.Rect(cx - rx * 1.4, cy - ry * 1.5, cx + rx * 1.4, yl), flat(skin))
        c.drawPath(_open([(cx - rx * 1.2, yl + ry * .06), (cx + rx * 1.2, yl)]), ink(c, 6))
    c.restore(); c.drawPath(E, ink(c, 6))
def mouth(c, cx, cy, mw, o=0.0, w=1.0, sm=0.0, skew=0.0, teeth=True):
    hw = mw * w / 2; k = mw * .22; lc = (cx - hw, cy - sm * k + skew * k); rc = (cx + hw, cy - sm * k - skew * k)
    if o < .07:
        p = skia.Path(); p.moveTo(*lc); p.quadTo(cx, cy + sm * k * 1.2, *rc); c.drawPath(p, ink(c, 6)); return
    h = o * mw * .62
    p = skia.Path(); p.moveTo(*lc); p.quadTo(cx, cy - h * .25 + sm * k * .4, *rc); p.quadTo(cx, cy + h + sm * k * .6, *lc); p.close()
    c.drawPath(p, flat(MOUTH_IN)); c.save(); c.clipPath(p, skia.ClipOp.kIntersect, True)
    if teeth and o > .22: c.drawRect(skia.Rect(cx - hw * 1.2, cy - h, cx + hw * 1.2, cy - h * .55 + 4), flat(WHITE))
    c.drawOval(skia.Rect(cx - hw * .45, cy + h * .5, cx + hw * .75, cy + h * 1.4), flat(TONGUE)); c.restore()
    c.drawPath(p, ink(c, 6))
def sweat(c, x, y, s=1.0): shape(c, spline([(x, y - 16 * s), (x + 9 * s, y + 4 * s), (x, y + 12 * s), (x - 9 * s, y + 4 * s)]), '#BFE9FF', False, 5)

# ------------------------------------------------------------------ cast (era costumes)
# body: robe | coat | uniform | dress | kimono | sailor ; hat: see _hat ; hstyle: short | bowl | long | bun | topknot | curly | bald
SPEC = {
 'tsar':     dict(skin=0, hair='#6B4A2E', hstyle='short', beard='full', hat='monomakh', body='robe', c1='#C0392B', c2=BRASS, legs='#4A2E1C'),
 'nicholas': dict(skin=0, hair='#7A5636', hstyle='short', beard='trim', hat='none', body='uniform', c1='#5E7A52', c2=BRASS, legs='#2B2219'),
 'alexandra':dict(skin=0, hair='#9A6A3E', hstyle='bun', beard='none', hat='tiara', body='dress', c1='#F3EFE6', c2='#C9B9A0', legs='#2B2219'),
 'daughter': dict(skin=0, hair='#A8743E', hstyle='long', beard='none', hat='bow', body='dress', c1='#FFFFFF', c2='#E4D6F0', legs='#2B2219'),
 'son':      dict(skin=0, hair='#8A6038', hstyle='short', beard='none', hat='sailor', body='sailor', c1='#FFFFFF', c2='#2F4E8C', legs='#2F4E8C', size=.8),
 'servant':  dict(skin=0, hair='#555048', hstyle='bald', beard='mustache', hat='none', body='coat', c1='#4A4F58', c2='#2B2219', legs='#2B2219'),
 'doctor':   dict(skin=0, hair='#9A9A90', hstyle='short', beard='trim', hat='none', body='coat', c1='#3A3F4A', c2=CREAM, legs='#2B2219', glasses=True),
 'maid':     dict(skin=0, hair='#5A4030', hstyle='bun', beard='none', hat='none', body='dress', c1='#4A4F58', c2=WHITE, legs='#2B2219'),
 'cook':     dict(skin=1, hair='#3A3028', hstyle='short', beard='mustache', hat='chef', body='coat', c1='#F3EFE6', c2='#2B2219', legs='#2B2219'),
 'guard':    dict(skin=0, hair='#3A2A1A', hstyle='short', beard='mustache', hat='peaked', body='coat', c1='#3B3540', c2='#C0392B', legs='#2B2219'),
 'michael':  dict(skin=0, hair='#9A6A3E', hstyle='bowl', beard='none', hat='none', body='robe', c1='#6E93D6', c2=BRASS, legs='#4A2E1C', size=.88),
 'boyar':    dict(skin=0, hair='#5A3E26', hstyle='short', beard='long', hat='boyar', body='robe', c1='#9C3B2B', c2=BRASS, legs='#3A2A1A'),
 'boyar2':   dict(skin=1, hair='#3A2A1A', hstyle='short', beard='full', hat='boyar', body='robe', c1='#3F7A5A', c2='#E5D3A0', legs='#3A2A1A'),
 'boyar3':   dict(skin=0, hair='#B0A08A', hstyle='bald', beard='long', hat='boyar', body='robe', c1='#6A55A0', c2='#E5D3A0', legs='#3A2A1A'),
 'monk':     dict(skin=0, hair='#3A3028', hstyle='short', beard='long', hat='klobuk', body='robe', c1='#2E2A2C', c2='#2E2A2C', legs='#2B2219'),
 'pole':     dict(skin=0, hair='#6B4A2E', hstyle='short', beard='mustache', hat='kolpak', body='coat', c1='#B03A3A', c2=CREAM, legs='#2B2219'),
 'messenger':dict(skin=1, hair='#4A3220', hstyle='short', beard='full', hat='boyar', body='coat', c1='#9C7440', c2=BRASS, legs='#3A2A1A'),
 'samurai':  dict(skin=1, hair='#1C1814', hstyle='topknot', beard='none', hat='none', body='kimono', c1='#2F5E9C', c2='#E8E0CC', legs='#2B2219'),
 'shogun':   dict(skin=1, hair='#1C1814', hstyle='topknot', beard='none', hat='eboshi', body='kimono', c1='#8A2A2A', c2=BRASS, legs='#2B2219'),
 'fisher':   dict(skin=2, hair='#1C1814', hstyle='short', beard='none', hat='kasa', body='kimono', c1='#8AA0B0', c2='#E8E0CC', legs='#4A4038'),
 'perry':    dict(skin=0, hair='#7A6450', hstyle='short', beard='sideburns', hat='bicorne', body='uniform', c1='#22305A', c2=BRASS, legs='#22305A'),
 'sailor':   dict(skin=0, hair='#8A6038', hstyle='short', beard='none', hat='sailorcap', body='sailor', c1='#22305A', c2=WHITE, legs='#22305A'),
 'jsoldier': dict(skin=1, hair='#1C1814', hstyle='short', beard='none', hat='peaked', body='uniform', c1='#22305A', c2='#C0392B', legs='#22305A'),
 'rsoldier': dict(skin=0, hair='#6B4A2E', hstyle='short', beard='full', hat='peaked', body='uniform', c1='#5E7A52', c2='#C0392B', legs='#2B2219'),
 'guide':    dict(skin=2, hair='#2B2219', hstyle='curly', beard='none', hat='beret', body='coat', c1='#E07A2E', c2=CREAM, legs='#2F3A5A', glasses=True, size=.95),
}
# face states: lid, brow tilt (+ angry), brow raise, pupil size, mouth open, smile, eyes closed
EXPR = dict(normal=(.12, 0, 0, 5.5, 0, .25, False), talk=(.12, 0, .2, 5.5, 0, .2, False), happy=(0, 0, .3, 5.5, 0, .9, True),
            wide=(0, -.2, .9, 4.0, .25, .1, False), scared=(0, -.6, 1.0, 3.2, .35, -.5, False), angry=(.32, 1.0, -.4, 5.5, .12, -.45, False),
            sad=(.38, -.7, .2, 5.0, 0, -.55, False), deadpan=(.5, 0, 0, 5.0, 0, -.1, False), smug=(.45, .3, -.2, 5.0, 0, .55, False))

def _hat(c, hat, t):
    if hat == 'crown':
        shape(c, poly([(-52, -96), (-60, -150), (-30, -122), (0, -160), (30, -122), (60, -150), (52, -96)]), '#F2C230')
        for x, y in ((-60, -150), (0, -160), (60, -150)): shape(c, ell(x, y, 9, 9), '#C0392B', False, 5)
    elif hat == 'monomakh':
        shape(c, rr(-74, -122, 74, -84, 18), '#7A5230')
        shape(c, spline([(-58, -118), (-40, -170), (0, -186), (40, -170), (58, -118)]), '#F2C230')
        for k in (-28, 0, 28): shape(c, ell(k, -144, 7, 7), '#C0392B', False, 4)
        line(c, [(0, -184), (0, -220)], 9, '#F2C230'); line(c, [(-14, -206), (14, -206)], 9, '#F2C230')
    elif hat == 'boyar':
        shape(c, spline([(-66, -90), (-72, -150), (-50, -205), (0, -218), (52, -205), (72, -150), (66, -90)]), '#6A4A34')
        for k in range(-44, 50, 22): line(c, [(k, -200), (k + 4, -100)], 3, '#4A3020')
    elif hat == 'kolpak':
        shape(c, spline([(-64, -96), (-50, -170), (30, -190), (64, -96)]), '#B03A3A'); shape(c, rr(-70, -112, 70, -84, 12), '#4A3020')
        line(c, [(30, -186), (70, -240)], 6, CREAM)
    elif hat == 'tiara':
        shape(c, poly([(-46, -100), (-30, -130), (-12, -110), (0, -138), (12, -110), (30, -130), (46, -100)]), '#EDE6D6', False, 5)
    elif hat == 'bow':
        for sx in (-1, 1): shape(c, spline([(0, -106), (sx * 40, -132), (sx * 44, -92)]), '#F4A6C6', False, 5)
    elif hat == 'sailor':
        shape(c, rr(-66, -116, 66, -84, 14), WHITE, True); c.drawRect(skia.Rect(-62, -100, 62, -90), flat('#2F4E8C'))
    elif hat == 'sailorcap':
        shape(c, ell(0, -102, 66, 22), WHITE)
    elif hat == 'bicorne':
        shape(c, spline([(-112, -86), (-60, -170), (0, -186), (60, -170), (112, -86), (0, -100)]), '#1E1E26'); shape(c, ell(0, -140, 11, 11), BRASS, False, 4)
    elif hat == 'peaked':
        shape(c, spline([(-68, -96), (-62, -150), (0, -164), (62, -150), (68, -96)]), '#3B3540')
        c.drawRect(skia.Rect(-66, -112, 66, -98), flat('#C0392B')); shape(c, spline([(-20, -96), (96, -92), (70, -74), (-10, -80)]), '#1E1E26', False, 5)
    elif hat == 'kasa':
        shape(c, spline([(-130, -80), (0, -170), (130, -80), (0, -92)]), '#D9B97A')
    elif hat == 'eboshi':
        shape(c, spline([(-40, -100), (-34, -200), (10, -226), (44, -100)]), '#1E1E26')
    elif hat == 'klobuk':
        shape(c, rr(-68, -170, 68, -84, 20), '#1C1C1C'); shape(c, spline([(-68, -110), (-96, 60), (-62, 60)]), '#1C1C1C', False)
    elif hat == 'chef':
        shape(c, spline([(-50, -96), (-70, -150), (-30, -190), (20, -196), (66, -150), (50, -96)]), WHITE)
    elif hat == 'beret':
        shape(c, spline([(-84, -84), (-70, -128), (0, -146), (70, -124), (86, -90), (0, -100)]), '#C0392B'); line(c, [(0, -140), (6, -160)], 6)

def _head(c, spec, expr, talk, t, look):
    sk, sks = SKIN[spec['skin']]; hair = spec['hair']; hs = spec['hstyle']
    lid, btilt, braise, pup, mo, sm, closed = EXPR.get(expr, EXPR['normal'])
    if hs == 'long': shape(c, spline([(-96, -40), (-80, -110), (0, -128), (70, -100), (60, 40), (20, 150), (-90, 150)]), hair)
    if hs == 'bun': shape(c, ell(-50, -106, 34, 32), hair)
    shape(c, ell(-74, 8, 17, 25), sk, sks)                                            # ear (back side)
    HD = spline([(-10, -100), (55, -95), (85, -55), (90, 10), (82, 65), (50, 98), (0, 104), (-48, 88), (-80, 40), (-86, -25), (-58, -85)])
    shape(c, HD, sk, sks)
    if hs in ('short', 'curly', 'bowl', 'topknot', 'long', 'bun'):
        top = spline([(-90, 10), (-92, -50), (-60, -100), (0, -116), (62, -102), (88, -60), (60, -70), (10, -78), (-40, -60), (-62, -10)]) if hs != 'bowl' else \
              spline([(-92, 20), (-92, -50), (-60, -104), (0, -118), (64, -104), (94, -40), (92, -20), (30, -30), (-30, -26), (-70, 20)])
        shape(c, top, hair)
        if hs == 'topknot': shape(c, rr(-20, -150, 24, -108, 12), hair)
        if hs == 'curly':
            for k in range(6): shape(c, ell(-70 + k * 28, -104 + 8 * (k % 2), 20, 18), hair, False, 5)
    if hs == 'bald': shape(c, spline([(-90, 20), (-88, -20), (-70, -10), (-72, 30)]), hair, False, 5)
    bd = spec['beard']
    if bd in ('full', 'long', 'trim'):
        L = dict(full=150, long=210, trim=118)[bd]
        shape(c, spline([(-70, 30), (-40, 60), (20, 70), (88, 40), (78, 90), (40, L * .9), (0, L), (-50, L * .8), (-82, 70)]), hair)
    if bd == 'sideburns': shape(c, spline([(-78, -20), (-60, -20), (-50, 60), (-74, 70)]), hair, False, 5)
    jit = (_h(int(t * 12)) - .5) * 4 if expr == 'scared' else 0
    blink = (not closed) and (t % 3.7) < .1
    ey = -10 - braise * 4
    eye(c, 4, ey, 31, 34, 1 if blink else lid, look, pup, sk, closed, jit)
    eye(c, 54, ey - 2, 24, 29, 1 if blink else lid, look, pup * .9, sk, closed, jit)
    if spec.get('glasses'):
        for ex, rx in ((4, 38), (54, 30)): c.drawPath(ell(ex, ey, rx, rx), ink(c, 6))
    by = -54 - braise * 14; bc = hair if hair != '#B0A08A' else '#7A6A5A'
    c.drawPath(_open([(-26, by - btilt * 9), (4, by - 6), (32, by + btilt * 9)]), ink(c, 10, bc))      # back brow: inner end at the right
    c.drawPath(_open([(36, by + btilt * 9 - 2), (56, by - 8), (78, by - 2 - btilt * 9)]), ink(c, 9, bc))
    shape(c, spline([(34, -6), (48, 22), (72, 38), (64, 56), (40, 52), (30, 38)]), sk, sks, 6)  # nose
    if talk: k = int(t * 12); o = .12 + .5 * _h(k); wv = .8 + .3 * _h(k + 9)
    else: o, wv = mo, 1.0
    mouth(c, 42, 78, 60, o, wv, sm, 0)
    if bd in ('mustache', 'full', 'long', 'trim', 'sideburns'):
        shape(c, spline([(10, 66), (40, 58), (74, 66), (80, 76), (42, 70), (6, 78)]), hair, False, 5)
    if expr == 'scared': sweat(c, -40, -60); sweat(c, 92, -40, .8)

POSES = {  # (back hand, front hand) relative to the shoulders, face right; y up negative
 'idle': ((-20, 120), (20, 120)), 'point': ((-20, 120), (150, -60)), 'wave': ((-20, 120), (70, -150)), 'shrug': ((-110, -10), (110, -10)),
 'cross': ((50, 70), (-30, 70)), 'hold': ((20, 70), (60, 70)), 'up': ((-80, -170), (80, -170)), 'sad': ((-6, 128), (6, 128)),
 'fist': ((-20, 120), (120, -40)), 'facepalm': ((-20, 120), (40, -70)), 'present': ((-20, 120), (160, 20))}

def person(c, x, y, s, spec, t, pose='idle', expr='normal', talk=False, face=1, a=1.0, lift=0.0, look=(.35, 0), seed=0, walk=0.0):
    """a sitcom-toon person, feet at (x, y), about 480 px tall at s=1. animates on twos."""
    if a <= 0: return
    tick(t); tq = on_twos(t + seed * .37); sz = spec.get('size', 1.0); sk, sks = SKIN[spec['skin']]
    if a < 1: c.saveLayerAlpha(None, int(255 * a))
    c.save(); c.translate(x, y - 40 * lift)
    if expr == 'scared': c.translate((_h(int(t * 12) + 3) - .5) * 6 * s, (_h(int(t * 12) + 7) - .5) * 4 * s)
    br = 1 + .012 * math.sin(tq * 2.4 + seed)
    c.scale(s * sz * face, s * sz * br)
    hand = POSES.get(pose, POSES['idle'])
    if pose == 'wave': hand = (hand[0], (70 + 30 * math.sin(tq * 14), -150))
    if spec['body'] != 'dress':
        for sxd, ph in ((-1, 0), (1, math.pi)):
            k = 26 * math.sin(tq * 10 + ph) if walk else 0
            noodle(c, [(sxd * 24, -150), (sxd * 26 + k * .5, -80), (sxd * 24 + k, -16)], 30, spec['legs'])
            shape(c, spline([(sxd * 24 + k - 22, -2), (sxd * 24 + k - 18, -26), (sxd * 24 + k + 30, -24), (sxd * 24 + k + 40, -2)]), '#2A2226', False, 6)
    else:
        for sxd in (-1, 1): shape(c, ell(sxd * 26, -8, 26, 12), '#2A2226', False, 6)
    shy = -250
    def arm(sx, tgt):
        ax, ay = sx * 50, shy + 16; hx, hy = ax + tgt[0], ay + tgt[1]
        noodle(c, [(ax, ay), ((ax + hx) / 2, (ay + hy) / 2 + 22), (hx, hy)], 30, spec['c1'])
        shape(c, ell(hx, hy, 19, 19), sk, sks, 6)
    arm(-1, hand[0])
    b = spec['body']; c1, c2 = spec['c1'], spec['c2']
    if b in ('robe', 'kimono'):
        T = spline([(-54, -262), (0, -272), (56, -262), (72, -150), (84, -40), (0, -30), (-82, -40), (-70, -150)])
        shape(c, T, c1)
        if b == 'robe': c.drawRect(skia.Rect(-10, -262, 10, -36), flat(c2)); c.drawRect(skia.Rect(-82, -66, 84, -46), flat(c2)); c.drawPath(T, ink(c, 7))
        else:
            line(c, [(-30, -262), (8, -190), (34, -262)], 12, c2); line(c, [(-30, -262), (8, -190), (34, -262)], 3)
            shape(c, rr(-70, -180, 72, -150, 6), c2, False, 5)
        if b == 'robe' and spec.get('hat') in ('monomakh', 'boyar'): shape(c, rr(-62, -276, 62, -246, 14), '#6A4A34', False, 6)
    elif b == 'dress':
        T = spline([(-46, -266), (0, -272), (48, -266), (62, -170), (96, -20), (40, -4), (-40, -4), (-96, -20), (-62, -170)])
        shape(c, T, c1); c.drawRect(skia.Rect(-88, -44, 92, -30), flat(c2)); c.drawPath(T, ink(c, 7))
    else:
        T = spline([(-54, -262), (0, -272), (56, -262), (64, -190), (60, -130), (0, -122), (-58, -130), (-64, -190)])
        shape(c, T, c1)
        if b == 'uniform':
            for k in range(4): shape(c, ell(10, -244 + k * 30, 6, 6), BRASS, False, 4)
            c.drawRect(skia.Rect(-60, -168, 62, -152), flat('#3A2A1A')); shape(c, rr(30, -276, 74, -258, 6), c2, False, 5)
        elif b == 'sailor':
            line(c, [(-40, -264), (8, -212), (46, -264)], 14, c2); line(c, [(-40, -264), (8, -212), (46, -264)], 3)
        else:
            line(c, [(8, -266), (8, -128)], 4)
            for k in range(3): dot(c, 18, -236 + k * 34, 5, c2)
    shape(c, rr(-20, -296, 26, -262, 8), sk, False, 6)                                  # neck
    c.save(); c.translate(6, -380 + (3 * math.sin(tq * 14) if talk else 0))
    _head(c, spec, expr, talk, t, look); c.translate(0, 16); _hat(c, spec['hat'], t); c.restore()
    arm(1, hand[1])
    c.restore()
    if a < 1: c.restore()

def guide(c, x, y, s, t, pose='point', expr='normal', talk=False, face=1, a=1.0, watch=True, look=(.35, 0)):
    """QUILL: the time-travelling historian (orange coat, red beret, round glasses) holding the portal watch"""
    person(c, x, y, s, SPEC['guide'], t, pose, expr, talk, face, a, look=look)
    if watch and a > 0:
        k = s * .95; hd = POSES.get(pose, POSES['idle'])[1]
        if pose == 'wave': hd = (70 + 30 * math.sin(on_twos(t) * 14), -150)
        hx = x + face * k * (50 + hd[0]); hy = y + k * (-234 + hd[1])
        c.save(); c.translate(hx, hy - 6 * k); c.scale(k, k)
        shape(c, ell(0, 0, 22, 22), BRASS, True, 6); c.drawCircle(0, 0, 13, flat(PORTAL[1])); c.drawPath(ell(0, 0, 13, 13), ink(c, 4))
        c.restore()

def blob(c, x, y, w, path, h, t, expr='normal', talk=False, a=1.0, legs=True, arms=None, look=(0, 0)):
    """a country outline as a character: flat fill, shadow band, boiling ink, big eyes, mouth, noodle limbs. arms=(left deg, right deg), 0 = hanging down, 180 = up"""
    tick(t); tq = on_twos(t); b = path.computeTightBounds(); sc = w / b.width(); hh = b.height() * sc
    c.save(); c.translate(x, y + (abs(math.sin(tq * 6)) * -10 if talk else 0))
    if expr == 'scared': c.translate((_h(int(t * 12)) - .5) * 8, 0)
    if legs:
        for k in (-1, 1): noodle(c, [(k * w * .12, -hh * .35), (k * w * .14, 10), (k * w * .13 + 6 * math.sin(tq * 6 + k), 66)], 20, INK)
    if arms:
        for k, ang in zip((-1, 1), arms):
            ax, ay = k * w * .34, -hh * .45; r = math.radians(ang)
            hx, hy = ax + 110 * math.sin(r) * k, ay + 110 * math.cos(r)
            noodle(c, [(ax, ay), ((ax + hx) / 2, (ay + hy) / 2 + 14), (hx, hy)], 22, h); shape(c, ell(hx, hy, 18, 18), h, False, 6)
    c.save(); c.scale(sc, sc); c.translate(-b.centerX(), -b.bottom()); shape(c, path, h); c.restore()
    lid, btilt, braise, pup, mo, sm, closed = EXPR.get(expr, EXPR['normal'])
    cx, cy = 0, -hh * .55; r = max(24, min(44, w * .07))
    for k, rx in ((-r * .95, r), (r * .95, r * .85)):
        eye(c, cx + k, cy, rx, rx * 1.15, lid, look, 6, h, closed, (_h(int(t * 12)) - .5) * 3 if expr == 'scared' else 0)
    if btilt:
        for k in (-1, 1): c.drawPath(_open([(cx + k * r * 2.1, cy - r * 1.5 - btilt * 8), (cx + k * r * .4, cy - r * 1.2 + btilt * 8)]), ink(c, 9))
    o = (.15 + .5 * _h(int(t * 12))) if talk else mo
    mouth(c, cx, cy + r * 1.9, r * 1.6, o, 1, sm)
    c.restore()

# ------------------------------------------------------------------ sets: flat colour bands, panel lines, boiling ink
def bands(c, cols, y0=0, y1=None):
    y1 = H if y1 is None else y1; n = len(cols); hgt = (y1 - y0) / n
    for i, h in enumerate(cols): c.drawRect(skia.Rect(0, y0 + i * hgt, W, y0 + (i + 1) * hgt + 1), flat(h))
def wall(c, kind='warm', t=0.0):
    """plain backdrop for real images: flat colour, a skirting band and panel lines"""
    tick(t)
    K_ = dict(warm=('#E9D3A8', '#D8BE8E'), dark=('#2E2A3A', '#24212E'), cool=('#BFD6CF', '#A9C4BC'), red=('#C9705A', '#B45F4A'), night=('#1E2350', '#181C42'))[kind]
    c.drawRect(skia.Rect(0, 0, W, H), flat(K_[0])); c.drawRect(skia.Rect(0, H * .82, W, H), flat(K_[1]))
    c.drawPath(_open([(0, H * .82), (W, H * .82)]), ink(c, 6))
    for x in range(160, W, 320): c.drawPath(_open([(x, 0), (x, H * .82)]), ink(c, 4, darker(K_[0], .85)))
def room(c, kind='palace', t=0.0):
    tick(t)
    K_ = dict(palace=('#E8C46A', '#D9B055', '#B97A3A', '#C0392B'), cabin=('#B98A5A', '#A87A4A', '#7A5230', '#6E93D6'),
              hall=('#CDBFA4', '#BFB094', '#8C7A62', '#9C3B2B'), basement=('#57606B', '#4C545E', '#34393F', '#2B2F34'),
              monastery=('#EDE3D0', '#E0D5C0', '#A8977A', '#2E5E8C'), office=('#A9C9B5', '#9DBDA9', '#6E8070', '#3A5A48'))[kind]
    wall1, wall2, floor, acc = K_; fy = H * .74
    c.drawRect(skia.Rect(0, 0, W, fy * .62), flat(wall1)); c.drawRect(skia.Rect(0, fy * .62, W, fy), flat(wall2))
    c.drawRect(skia.Rect(0, fy, W, H), flat(floor)); c.drawRect(skia.Rect(0, fy + 70, W, H), flat(darker(floor, .9)))
    c.drawPath(_open([(0, fy), (W, fy)]), ink(c, 7)); c.drawPath(_open([(0, fy * .62), (W, fy * .62)]), ink(c, 4, darker(wall1, .7)))
    for x in range(140, W, 300): c.drawPath(_open([(x, 0), (x, fy)]), ink(c, 4, darker(wall1, .8)))
    if kind in ('palace', 'hall', 'monastery'):
        for x in (380, 1540):
            shape(c, spline([(x - 100, 560), (x - 100, 250), (x - 60, 170), (x, 150), (x + 60, 170), (x + 100, 250), (x + 100, 560)]), '#9FC6E8' if kind != 'hall' else '#E9DCBC', False)
            c.drawPath(_open([(x, 160), (x, 560)]), ink(c, 4)); c.drawPath(_open([(x - 100, 380), (x + 100, 380)]), ink(c, 4))
            if kind == 'palace':
                for d in (-1, 1): shape(c, spline([(x + d * 120, 120), (x + d * 170, 120), (x + d * 180, 620), (x + d * 120, 620)]), acc)
    if kind == 'basement':
        shape(c, spline([(560, fy), (560, 330), (700, 170), (960, 120), (1220, 170), (1360, 330), (1360, fy)]), '#4A5159', False)
        c.drawPath(_open([(960, 0), (960, 150)]), ink(c, 4)); shape(c, ell(960, 168, 18, 22), '#FFE7A0', False, 5)
    if kind == 'office':
        for x in (300, 1600): shape(c, rr(x - 120, 200, x + 120, 480, 8), '#D7E9F2'); c.drawPath(_open([(x, 200), (x, 480)]), ink(c, 4))
def outdoor(c, t, kind='field'):
    tick(t)
    S_ = dict(field=('#7EC4E8', '#9CD3EE', '#BCE2F3'), snow=('#A9C4D8', '#BFD3E2', '#D6E3EC'), night=('#14193A', '#1C2350', '#252E63'),
              sea=('#7EC4E8', '#9CD3EE', '#BCE2F3'), shore=('#7EC4E8', '#9CD3EE', '#BCE2F3'), dawn=('#F2A65A', '#F6BE7C', '#F9D6A0'))[kind]
    hy = H * .58 if kind in ('sea', 'shore') else H * .66
    bands(c, list(S_), 0, hy)
    if kind == 'night':
        for i in range(50):
            x, y = (i * 397) % W, (i * 211) % int(hy * .9); r = 3 + 3 * _h(i)
            c.drawPath(spline([(x, y - r * 2), (x + r * .5, y - r * .5), (x + r * 2, y), (x + r * .5, y + r * .5), (x, y + r * 2), (x - r * .5, y + r * .5), (x - r * 2, y), (x - r * .5, y - r * .5)]), flat('#FFF3C0'))
        shape(c, ell(1620, 190, 70, 70), '#FFF3C0', False); c.drawCircle(1652, 168, 62, flat(S_[0]))
    else:
        for k in range(3):
            cx = (k * 640 + t * 14) % (W + 500) - 250; cy = 120 + (k % 2) * 90
            shape(c, spline([(cx - 130, cy + 30), (cx - 110, cy - 10), (cx - 50, cy - 50), (cx + 20, cy - 60), (cx + 90, cy - 30), (cx + 130, cy + 30)]), '#FFFFFF', False, 5)
    if kind in ('sea', 'shore'):
        c.drawRect(skia.Rect(0, hy, W, H), flat('#3E86C2')); c.drawRect(skia.Rect(0, hy + 180, W, H), flat('#3478B2'))
        c.drawPath(_open([(0, hy), (W, hy)]), ink(c, 6))
        for j in range(7):
            yy = hy + 40 + j * 62
            for x0 in range(int((j * 137 + t * 30) % 240) - 240, W, 240): c.drawPath(_open([(x0, yy), (x0 + 30, yy - 8), (x0 + 60, yy)]), ink(c, 4, '#BFE0F5'))
        if kind == 'shore':
            shape(c, spline([(W * .44, H + 20), (W * .52, H * .86), (W * .66, H * .79), (W * .84, H * .76), (W + 40, H * .75), (W + 40, H + 20)]), '#EBCF8E')
        return
    g = dict(field=('#8BC46A', '#7AB45A'), snow=('#F2F6FA', '#E2EAF2'), night=('#25304F', '#1E2843'), dawn=('#C8A86A', '#B8985A'))[kind]
    c.drawRect(skia.Rect(0, hy, W, H), flat(g[0])); c.drawRect(skia.Rect(0, hy + 150, W, H), flat(g[1]))
    c.drawPath(_open([(0, hy), (W, hy)]), ink(c, 7))
    for k in range(8):
        x = 90 + k * 250 + (k % 2) * 50; yb = hy + 4
        noodle(c, [(x, yb), (x + 2, yb - 40)], 22, '#6A4A2E')
        shape(c, spline([(x - 70, yb - 40), (x - 60, yb - 120), (x, yb - 200), (x + 60, yb - 120), (x + 70, yb - 40)]), '#3E7A4A' if kind != 'night' else '#18223E')
        if kind == 'snow': c.drawPath(spline([(x - 40, yb - 150), (x, yb - 196), (x + 40, yb - 150)], False), ink(c, 8, WHITE))

# ------------------------------------------------------------------ props
def _at(c, x, y, s, fn, a=1.0):
    if a <= 0: return
    if a < 1: c.saveLayerAlpha(None, int(255 * a))
    c.save(); c.translate(x, y); c.scale(s, s); fn(); c.restore()
    if a < 1: c.restore()
def throne(c, x, y, s, t, empty=True, web=False):
    tick(t)
    def f():
        shape(c, spline([(-90, -60), (-96, -330), (-60, -420), (0, -440), (60, -420), (96, -330), (90, -60)]), '#B0302A')
        shape(c, ell(0, -380, 30, 30), '#F2C230'); shape(c, rr(-128, -170, 128, -46, 18), '#F2C230')
        for k in (-104, 104): shape(c, rr(k - 16, -60, k + 16, 0, 6), '#9A6A20')
        if web:
            for k in range(5): c.drawPath(_open([(90, -420), (90 - 140 * math.cos(k * .35), -420 + 140 * math.sin(k * .35))]), ink(c, 2.5, WHITE))
            for r_ in (45, 90, 135): p = skia.Path(); p.addArc(skia.Rect(90 - r_, -420 - r_, 90 + r_, -420 + r_), 90, 90); c.drawPath(p, ink(c, 2.5, WHITE))
    _at(c, x, y, s, f)
def house(c, x, y, s, t, lit=True):
    tick(t)
    def f():
        shape(c, rr(-330, -270, 330, 0, 4), '#E8E0CF'); shape(c, poly([(-360, -270), (0, -380), (360, -270)]), '#6B7B8C')
        for k in range(-260, 300, 130): shape(c, rr(k - 36, -220, k + 36, -140, 4), '#FFE07A' if lit and k == 130 else '#2B3550', False, 6)
        shape(c, rr(-60, -116, 60, 0, 4), '#5A4030', False, 6)
        for k in range(-400, 410, 28): shape(c, rr(k, -130, k + 22, 0, 3), '#7A5A3A', False, 4)
    _at(c, x, y, s, f)
def monastery(c, x, y, s, t=0):
    tick(t)
    def f():
        shape(c, rr(-380, -200, 380, 0, 4), '#F4F0E6')
        for k, hh in ((-200, 260), (0, 360), (200, 260)):
            shape(c, rr(k - 60, -hh, k + 60, -196, 4), '#F4F0E6')
            shape(c, spline([(k - 64, -hh), (k - 50, -hh - 80), (k, -hh - 110), (k + 50, -hh - 80), (k + 64, -hh)]), '#F2C230')
            c.drawPath(_open([(k, -hh - 106), (k, -hh - 150)]), ink(c, 6)); c.drawPath(_open([(k - 14, -hh - 132), (k + 14, -hh - 132)]), ink(c, 6))
        shape(c, rr(-40, -100, 40, 0, 20), '#5A4030', False)
    _at(c, x, y, s, f)
def ship(c, x, y, s, t, kind='sail', face=1, smoke=True):
    tick(t); tq = on_twos(t); bob = math.sin(tq * 2.4) * 6
    def f():
        c.rotate(math.sin(tq * 1.8) * 2)
        if kind == 'black':
            for k in (-140, 110): c.drawPath(_open([(k, -60), (k, -240)]), ink(c, 7, '#4A3420'))
            shape(c, rr(-50, -170, 6, -60, 4), '#2B2B30'); c.drawRect(skia.Rect(-50, -158, 6, -144), flat('#C0392B'))
            shape(c, spline([(-210, -64), (210, -64), (170, 0), (-176, 0)]), '#1E1E26')
            shape(c, ell(-90, -40, 34, 34), '#3A3A42', False, 6)
            for k in (40, 120): shape(c, ell(k, -32, 8, 8), BRASS, False, 4)
        else:
            c.drawPath(_open([(0, -60), (0, -300)]), ink(c, 9, '#6A4A2A'))
            shape(c, spline([(-6, -290), (-150, -230), (-150, -110), (-6, -86)]), '#FBF0D4')
            shape(c, spline([(-210, -64), (210, -64), (170, 0), (-176, 0)]), '#9A6234')
    if kind == 'black' and smoke:
        for k in range(5):
            ph = (on_twos(t) * .6 + k / 5) % 1
            c.save(); c.translate(x - (22 + ph * 170) * s * face, y + bob - (180 + ph * 140) * s)
            c.scale(s * (.5 + 1.2 * ph), s * (.5 + 1.2 * ph)); shape(c, ell(0, 0, 34, 30), '#8A8A94', False, 5, int(255 * (1 - ph))); c.restore()
    c.save(); c.translate(x, y + bob); c.scale(s * face, s); f(); c.restore()
def door(c, x, y, s, open_u, h='#8C5A30', sign=None, t=0):
    tick(t)
    def f():
        shape(c, rr(-140, -410, 140, 0, 6), '#1E1A1C', False)
        w = 280 * (1 - .86 * _sm(open_u))
        shape(c, rr(-140, -410, -140 + w, 0, 6), h); shape(c, ell(-140 + w - 28, -200, 11, 11), BRASS, False, 4)
        if sign and open_u < .2:
            shape(c, rr(-116, -340, 116, -250, 8), CREAM, False, 6)
            f_ = font(LILITA, 52); c.drawString(sign, -f_.measureText(sign) / 2, -276, f_, flat('#C0392B'))
    _at(c, x, y, s, f)

# ------------------------------------------------------------------ type, cards, real images
def bubble(c, s, x, y, t, t0, tail=(0, 80), sz=50, dur=None):
    """speech bubble: white, boiling ink, pops in on twos with a small overshoot. bubble(c, 'text', x, y, t, t0)"""
    tick(t); u = _clamp((on_twos(t) - t0) / .25); u *= (1 if dur is None else 1 - _clamp((t - t0 - dur) / .15))
    if u <= 0: return
    f = font(LILITA, sz); lines = s.split('\n'); w = max(f.measureText(l) for l in lines) + 70; h = len(lines) * sz * 1.12 + 40
    k = (1 + .12 * math.sin(u * math.pi)) * min(1, .4 + u)
    c.save(); c.translate(x, y); c.scale(k, k)
    body = spline([(-w / 2, -h * .5), (-w * .42, -h), (0, -h * 1.06), (w * .42, -h), (w / 2, -h * .5), (w * .44, -4), (0, 4), (-w * .44, -4)])
    tl = poly([(-20, -10), (tail[0], tail[1]), (22, -8)])
    pth = skia.Op(body, tl, skia.PathOp.kUnion_PathOp) or body
    shape(c, pth, WHITE, False, 7)
    for i, l in enumerate(lines): c.drawString(l, -f.measureText(l) / 2, -h + 30 + sz * (i + .82) * 1.08, f, flat(INK))
    c.restore()
def tag(c, s, x, y, t, t0, sz=42, rot=-2, h=CREAM, ink_h=INK):
    tick(t); u = _clamp((on_twos(t) - t0) / .17)
    if u <= 0: return
    f = font(LILITA, sz); w = f.measureText(s) + 44
    c.save(); c.translate(x, y); c.rotate(rot); k = 1.25 - .25 * u; c.scale(k, k)
    shape(c, rr(-w / 2, -sz * 1.0, w / 2, sz * .5, 12), h, True, 6)
    c.drawString(s, -w / 2 + 22, sz * .12, f, flat(ink_h)); c.restore()
def photo_card(c, im, rect, t, t0, rot=-1.5, caption=None, credit=None, push=1.06, dur=4.0, focus=(.5, .5), a=1.0):
    """a REAL painting or photo in a thick boiling ink frame, slow push inside, caption tag underneath"""
    tick(t); u = eout(K(t, t0, .3))
    if u <= 0: return
    x0, y0, x1, y1 = rect; cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    c.save(); c.translate(cx, cy + 50 * (1 - u)); c.rotate(rot); c.scale(.92 + .08 * u, .92 + .08 * u); c.translate(-cx, -cy)
    shape(c, rr(x0 - 22, y0 - 22, x1 + 22, y1 + 22, 10), '#FFF8EA', True, 8)
    c.save(); c.clipRect(skia.Rect(x0, y0, x1, y1))
    from history import draw_cover
    z = 1 + (push - 1) * _sm(_clamp((t - t0) / dur)); draw_cover(c, im, rect, focus, z, 255 * a); c.restore()
    c.drawRect(skia.Rect(x0, y0, x1, y1), ink(c, 6))
    c.restore()
    if caption: tag(c, caption, cx, y1 + 56, t, t0 + .2, 36, -rot * .5)
    if credit: text(c, credit, W - 40, H - 22, 15, MED, '#3A3040', 230 * u, 'right')
def _text_path(f, s, x=0, y=0):
    p = skia.Path(); gl = f.textToGlyphs(s); pos = f.getPos(gl) if hasattr(f, 'getPos') else None
    xx = x
    for i, g in enumerate(gl):
        gp = f.getPath(g)
        if gp is not None: gp.offset(xx, y); p.addPath(gp)
        xx += f.getWidths([g])[0]
    return p
def title_card(c, t, t0, top, big, sub=None, h='#E5533C', bg=('#2E2A5C', '#352F68', '#2E2A5C')):
    """chunky display title popped in on twos: cream letters, a coloured offset, thick ink, the portal ring orbiting it"""
    tick(t); bands(c, list(bg))
    for i in range(18):
        x, y = (i * 467) % W, (i * 283) % H; r = 5 + 5 * _h(i)
        c.drawPath(spline([(x, y - r * 2), (x + r * .4, y - r * .4), (x + r * 2, y), (x + r * .4, y + r * .4), (x, y + r * 2), (x - r * .4, y + r * .4), (x - r * 2, y), (x - r * .4, y - r * .4)]), flat('#F6D870'))
    u = _clamp((on_twos(t) - t0) / .25)
    if u > 0:
        f1 = font(LILITA, 62); p1 = _text_path(f1, top); w1 = f1.measureText(top)
        c.save(); c.translate(W / 2 - w1 / 2, 330); c.drawPath(p1, flat(CREAM, int(255 * u))); c.restore()
    u2 = _clamp((on_twos(t) - t0 - .25) / .25)
    if u2 > 0:
        f2 = font(LILITA, 250 if len(big) < 8 else 190); w = f2.measureText(big); k = 1 + .35 * (1 - u2) - .08 * math.sin(u2 * math.pi)
        c.save(); c.translate(W / 2, 640); c.rotate(-3); c.scale(k, k)
        ring = ell(0, -80, w * .62, 160); c.drawPath(ring, ink(c, 26, PORTAL[0], 170, 0)); c.drawPath(ring, ink(c, 9, PORTAL[1]))
        pth = _text_path(f2, big, -w / 2, 0)
        c.save(); c.translate(10, 12); c.drawPath(pth, flat(h)); c.drawPath(pth, ink(c, 10)); c.restore()
        c.drawPath(pth, flat(CREAM)); c.drawPath(pth, ink(c, 10))
        c.restore()
    if sub:
        u3 = _clamp((t - t0 - .8) / .3)
        if u3 > 0: f3 = font(LILITA, 50); c.drawString(sub, W / 2 - f3.measureText(sub) / 2, 880, f3, flat('#F6D870', int(255 * u3)))

# ------------------------------------------------------------------ the travel device: time portal
def portal(c, x, y, r, t, a=1.0):
    """lumpy rim, rotating spiral arms, pale core, orbiting sparks, flat translucent glow rings. the ONLY glowing thing"""
    if r <= 1: return
    tick(t); n = 16; tq = on_twos(t)
    rim = spline([(x + r * (1 + .08 * math.sin(i * 2.3 + tq * 5)) * math.cos(i / n * 6.283), y + r * 1.12 * (1 + .08 * math.cos(i * 1.7 + tq * 4)) * math.sin(i / n * 6.283)) for i in range(n)])
    c.drawCircle(x, y, r * 1.55, flat(PORTAL[0], int(40 * a))); c.drawCircle(x, y, r * 1.28, flat(PORTAL[0], int(55 * a)))
    c.drawPath(rim, flat(PORTAL[2], int(255 * a)))
    c.save(); c.clipPath(rim, skia.ClipOp.kIntersect, True)
    for k in range(4):
        ang0 = t * 3.2 + k * 1.571
        pts = [(x + r * (i / 14) * math.cos(ang0 + i * .42), y + r * 1.1 * (i / 14) * math.sin(ang0 + i * .42)) for i in range(15)]
        c.drawPath(spline(pts, False), ink(c, max(6, r * .16), PORTAL[0], int(255 * a), 0))
    c.drawCircle(x, y, r * .32, flat(PORTAL[1], int(255 * a))); c.drawCircle(x, y, r * .16, flat(WHITE, int(255 * a)))
    c.restore(); c.drawPath(rim, ink(c, 8, INK, int(255 * a)))
    for k in range(7):
        ang = t * 2 + k * .9; rr_ = r * (1.2 + .15 * math.sin(k)); dot(c, x + rr_ * math.cos(ang), y + rr_ * 1.1 * math.sin(ang), 6, PORTAL[1], int(255 * a))
def portal_wipe(c, v, cuts, d=.42):
    """call at the END of every scene's draw: around each cut time the portal rushes open to fill the frame, then shrinks away"""
    for tc in cuts:
        if tc - d <= v < tc: u = (v - (tc - d)) / d; portal(c, W / 2, H / 2, 40 + 1500 * u ** 2.2, v)
        elif tc <= v < tc + d: u = 1 - (v - tc) / d; portal(c, W / 2, H / 2, 40 + 1500 * u ** 2.2, v)
def closeup(c, fx, fy, z, shake=0.0, t=0.0):
    """reaction close-up / push: everything drawn after this is zoomed on (fx, fy); ink keeps its screen width. pair with c.restore()"""
    c.save(); dx = (_h(int(t * 24)) - .5) * shake; dy = (_h(int(t * 24) + 5) - .5) * shake
    c.translate(W / 2 + dx, H / 2 + dy); c.scale(z, z); c.translate(-fx, -fy)
def panel(c, inner): inner(c)                          # kept for old edits: scenes are full-bleed now

def land(iso=None, year=None, name=None, lon=(-180, 180), min_area=0.0):
    """a country (Natural Earth iso) outline for blob(); keeps polygons whose middle lies in the longitude range and bigger than min_area"""
    import json
    from satmap import polity_eq, _eq_path, HERE as SH
    if not iso: return polity_eq(year, name)
    for f in json.load(open(os.path.join(SH, '..', 'assets', 'countries.json'))):
        if f['iso'] != iso: continue
        polys = f['coords'] if f['type'] == 'MultiPolygon' else [f['coords']]
        keep = []
        for poly_ in polys:
            xs = [q[0] for q in poly_[0]]; ys = [q[1] for q in poly_[0]]
            if not lon[0] <= (min(xs) + max(xs)) / 2 <= lon[1]: continue
            if (max(xs) - min(xs)) * (max(ys) - min(ys)) < min_area: continue
            keep.append(poly_[0])
        return _eq_path(keep)
def ship_icon(scale=.22, kind='black'):
    """route icon for SatMap routes: a little toon ship riding the head of the line"""
    def f(c, x, y, a, t): ship(c, x, y + 10, scale, t, kind, -1 if math.cos(a) < 0 else 1, smoke=False)
    return f

# ------------------------------------------------------------------ borrowed moves, redrawn in the toon look
def scribble_circle(c, x, y, rx, ry, t, t0, h='#E5533C', w=8, dur=.35):
    """TELESTRATOR (borrowed): a hand-drawn loop scrawled onto a real photo, drawn on in dur seconds"""
    u = _clamp((t - t0) / dur)
    if u <= 0: return
    tick(t); n = 40
    pts = [(x + rx * (1 + .06 * math.sin(i * .9)) * math.cos(-1.9 + i / n * 7.3), y + ry * (1 + .06 * math.cos(i * .7)) * math.sin(-1.9 + i / n * 7.3)) for i in range(n + 1)]
    p = spline(pts, False); pa = ink(c, w, h)
    if u < .999:
        e = skia.TrimPathEffect.Make(0, max(.002, u))
        if e: pa.setPathEffect(skia.PathEffect.MakeCompose(e, skia.DiscretePathEffect.Make(12, 1.5, 7 + _B[0] * 31)) if hasattr(skia.PathEffect, 'MakeCompose') else e)
    c.drawPath(p, pa)
def scribble_arrow(c, x0, y0, x1, y1, t, t0, h='#E5533C', w=8, dur=.3):
    """TELESTRATOR arrow: a curved hand-drawn arrow with a two-stroke head"""
    u = _clamp((t - t0) / dur)
    if u <= 0: return
    tick(t); mx, my = (x0 + x1) / 2 - (y1 - y0) * .2, (y0 + y1) / 2 + (x1 - x0) * .2
    p = skia.Path(); p.moveTo(x0, y0); p.quadTo(mx, my, x1, y1); pa = ink(c, w, h)
    if u < .999:
        e = skia.TrimPathEffect.Make(0, max(.002, u))
        if e: pa.setPathEffect(e)
    c.drawPath(p, pa)
    if u >= .999:
        a = math.atan2(y1 - my, x1 - mx)
        for d in (2.6, -2.6): c.drawPath(_open([(x1, y1), (x1 + 34 * math.cos(a + d), y1 + 34 * math.sin(a + d))]), ink(c, w, h))
def light_cone(c, x, y_top, w_top, w_bot, y_bot, dark=170, warm='#FFE7A0'):
    """DARK-DOCUMENTARY light (borrowed): one hard-edged cone of light from a bulb, everything outside it sinks into shadow"""
    cone = poly([(x - w_top / 2, y_top), (x + w_top / 2, y_top), (x + w_bot / 2, y_bot), (x - w_bot / 2, y_bot)])
    floor = ell(x, y_bot, w_bot / 2, 46); lit = skia.Op(cone, floor, skia.PathOp.kUnion_PathOp) or cone
    c.save(); c.clipPath(lit, skia.ClipOp.kDifference, True); c.drawRect(skia.Rect(0, 0, W, H), flat('#0C0A14', dark)); c.restore()
    c.drawPath(lit, flat(warm, 34))

RULER_FACE = {   # mini portrait heads for the family-tree line (they reuse the cast's head drawing)
 'beard': dict(skin=0, hair='#6B4A2E', hstyle='short', beard='full', hat='crown'), 'long': dict(skin=0, hair='#8A6A4A', hstyle='short', beard='long', hat='crown'),
 'clean': dict(skin=0, hair='#7A5636', hstyle='short', beard='mustache', hat='crown'), 'boy': dict(skin=0, hair='#9A6A3E', hstyle='bowl', beard='none', hat='crown'),
 'woman': dict(skin=0, hair='#9A6A3E', hstyle='bun', beard='none', hat='crown'), 'bald': dict(skin=0, hair='#7A6A5A', hstyle='bald', beard='mustache', hat='crown'),
 'trim': dict(skin=0, hair='#7A5636', hstyle='short', beard='trim', hat='crown')}
class Bloodline:
    """TRANSIT-MAP family tree (borrowed), drawn as a toon wall chart: one thick line runs through every ruler of the dynasty;
    each ruler is a station with a little toon portrait and a name tag; the crown rides the tip of the line; rulers who were
    killed get a red X; the line ENDS at the last one. rulers: [dict(name, years, face='beard'|'clean'|'woman'|..., fate=None|'killed')]"""
    def __init__(self, rulers, cols=6, gap=270, row=260, x0=285, y0=300, h='#C0392B'):
        self.r = rulers; self.h = h; self.pts = []
        for i, _ in enumerate(rulers):
            rw, k = divmod(i, cols); k = k if rw % 2 == 0 else cols - 1 - k
            self.pts.append((x0 + k * gap, y0 + rw * row))
        self.path = skia.Path(); self.path.moveTo(*self.pts[0]); self.st = [0.0]; pm = None
        for i, ((ax, ay), (bx, by)) in enumerate(zip(self.pts, self.pts[1:])):
            if ay == by: self.path.lineTo(bx, by)
            else:
                sgn = 1 if ((i + 1) // cols) % 2 == 1 else -1; ox = ax + sgn * 130
                self.path.lineTo(ox - sgn * 50, ay); self.path.quadTo(ox, ay, ox, ay + 50); self.path.lineTo(ox, by - 50); self.path.quadTo(ox, by, ox - sgn * 50, by); self.path.lineTo(bx, by)
            self.st.append(skia.PathMeasure(self.path, False).getLength())
        self.L = self.st[-1]
    def tip(self, t, t0, t1):
        u = _clamp((t - t0) / max(.01, t1 - t0)); u = u * u * (3 - 2 * u); d = self.L * u
        pos = skia.PathMeasure(self.path, False).getPosTan(max(.1, min(self.L - .1, d)))
        return d, (pos[0] if pos else self.pts[0])
    def draw(self, c, t, t0, t1, board=True, end_t=None):
        tick(t); head, (hx, hy) = self.tip(t, t0, t1)
        if board:
            shape(c, rr(120, 120, W - 120, H - 150, 18), '#FFF6E2', True, 8)
            f = font(LILITA, 40); s = 'THE ROMANOV LINE'; c.drawString(s, W / 2 - f.measureText(s) / 2, 190, f, flat(INK))
        if head > 1:
            fr = head / self.L
            for wdt, colr in ((30, INK), (17, self.h)):
                p = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style, StrokeWidth=wdt / _sc(c), Color=col(colr), StrokeJoin=skia.Paint.kRound_Join, StrokeCap=skia.Paint.kRound_Cap)
                if fr < .999:
                    e = skia.TrimPathEffect.Make(0, max(.002, fr))
                    if e: p.setPathEffect(e)
                c.drawPath(self.path, p)
        for i, ((x, y), r) in enumerate(zip(self.pts, self.r)):
            if head + 2 < self.st[i]: continue
            k = _clamp((head - self.st[i]) / 70 + .35); k = 1 + .25 * math.sin(k * math.pi) if k < 1 else 1
            c.save(); c.translate(x, y); c.scale(.34 * k, .34 * k)
            dead = r.get('fate') == 'killed' and (head > self.st[i] + 60 or (end_t is not None and t > end_t))
            spec = dict(RULER_FACE.get(r.get('face', 'beard'))); _head(c, spec, 'sad' if dead else 'normal', False, t, (0, 0)); c.translate(0, 16); _hat(c, 'crown', t)
            c.restore()
            if dead and (i < len(self.r) - 1 or (end_t is not None and t > end_t)):
                for a_, b_ in (((-34, -44), (34, 30)), ((34, -44), (-34, 30))): c.drawPath(_open([(x + a_[0], y + a_[1]), (x + b_[0], y + b_[1])]), ink(c, 11, '#E5533C'))
            f = font(LILITA, 26); nm = r['name']; ty = y + 78
            c.drawString(nm, x - f.measureText(nm) / 2, ty, f, flat(INK))
            f2 = font(LILITA, 20); c.drawString(r['years'], x - f2.measureText(r['years']) / 2, ty + 26, f2, flat('#8A6A5A'))
        if head < self.L - 1 and head > 1:
            c.save(); c.translate(hx, hy - 40); c.scale(.55, .55); _hat(c, 'crown', t); c.restore()
