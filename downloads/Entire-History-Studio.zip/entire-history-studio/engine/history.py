"""Entire History Studio: the era skins and history devices, on top of the MMH kit (kit.py) and moves (moves.py).

Era skins (adapted from the Lemo-Opuscar style library; grammar, not full looks):
  engraved(path)      ENGRAVING: any painting/photo re-cut as an intaglio plate (tone made only of line families) on cream paper
  plate()             shows an engraved image as a printed plate on the sheet (plate mark, ruled border, caption)
  LightTable          ARCHIVE LIGHT TABLE: real photos on a glowing table, a loupe dives in, counted marks in one red
  newsreel()          NEWSREEL: 1.37:1 gate, silver grade, weave, flicker, dust; type stays sharp outside the picture layer
  scroll()            UKIYO-E handscroll: a real woodblock print on fibre paper, the camera unrolls along it
  gilded_title()      GILDED ILLUMINATION: lapis field, vermilion rules, gold leaf letters that only shine when light passes
  chapter_card()      the same gilded look, small: PART ONE · THE BOY TSAR
  Bloodline           TRANSIT MAP as a family line: 8-direction line drawn by a glowing pen tip, a station per ruler,
                      the crown rides the tip, murdered/overthrown rulers struck out in red
  HistMap             MAP EXPLAINER with real historical borders (historical-basemaps), crossfading between years
  evidence()          VISUAL INVESTIGATION: dark layout, one clock/date readout, evidence frames, uncertainty drawn
"""
import json, math, os, urllib.request
import numpy as np
from kit import *
from moves import mapx, MapCam, _merc, geo, mascot, giant_number, _stroke, _clamp, _sm, hand_path, hand_ellipse, _trim

HERE = os.path.dirname(os.path.abspath(__file__)); ASSETS = os.path.join(HERE, '..', 'assets')
CACHE = os.path.expanduser(os.environ.get('EHS_CACHE', '~/.entire-history-studio/cache')); os.makedirs(CACHE, exist_ok=True)

def _vf(name, w):
    tf = skia.Typeface.MakeFromFile(os.path.join(ASSETS, 'fonts', name))
    C = skia.FontArguments.VariationPosition.Coordinate
    fa = skia.FontArguments(); fa.setVariationDesignPosition(skia.FontArguments.VariationPosition(skia.FontArguments.VariationPosition.Coordinates([C(0x77676874, float(w))])))
    return tf.makeClone(fa)
CINZEL = _vf('Cinzel-Variable.ttf', 700); CINZEL_B = _vf('Cinzel-Variable.ttf', 900)
GARA = _vf('CormorantGaramond-Variable.ttf', 600); GARA_I = _vf('CormorantGaramond-Italic-Variable.ttf', 500)
MONO = skia.Typeface.MakeFromFile(os.path.join(ASSETS, 'fonts', 'IBMPlexMono-Medium.ttf'))
PAPER, INKE, GOLD, LAPIS, VERM, SIG = '#F1E8D2', '#1C1510', '#D4A93C', '#15284F', '#B2341E', '#E0312B'

def spaced(c, s, x, y, sz, tf, h, a=255, track=.12, align='center'):
    """letter-spaced caps (documentary type)"""
    f = font(tf, sz); ws = [f.measureText(ch) for ch in s]; total = sum(ws) + track * sz * (len(s) - 1)
    x0 = x - total / 2 if align == 'center' else (x - total if align == 'right' else x)
    p = fp(h, a)
    for ch, w in zip(s, ws): c.drawString(ch, x0, y, f, p); x0 += w + track * sz
    return total

def _load(path):
    return skia.Image.MakeFromEncoded(skia.Data.MakeFromFileName(path))
_IMG = {}
def img(path):
    if path not in _IMG: _IMG[path] = _load(path)
    return _IMG[path]

def draw_cover(c, im, rect, focus=(.5, .5), zoom=1.0, a=255):
    """draw image to fill rect (cover), zoomed around focus (fractions of the image)"""
    x0, y0, x1, y1 = rect; rw, rh = x1 - x0, y1 - y0; iw, ih = im.width(), im.height()
    s = max(rw / iw, rh / ih) * zoom; vw, vh = rw / s, rh / s
    sx = min(max(focus[0] * iw - vw / 2, 0), iw - vw); sy = min(max(focus[1] * ih - vh / 2, 0), ih - vh)
    p = skia.Paint(AntiAlias=True); p.setAlphaf(a / 255)
    c.drawImageRect(im, skia.Rect(sx, sy, sx + vw, sy + vh), skia.Rect(x0, y0, x1, y1), skia.SamplingOptions(skia.FilterMode.kLinear), p)

def paper(c, rect=(0, 0, W, H), tone=PAPER, seed=3):
    """laid paper with fibres (world-space, so it zooms with the camera)"""
    x0, y0, x1, y1 = rect; c.drawRect(skia.Rect(x0, y0, x1, y1), fp(tone))
    r = np.random.default_rng(seed)
    for y in np.arange(y0, y1, 9): c.drawLine(x0, y, x1, y, _stroke('#8A7A5C', .6, 18, cap=False))
    for _ in range(220):
        x, y = r.uniform(x0, x1), r.uniform(y0, y1); a = r.uniform(0, 6.3); L = r.uniform(6, 26)
        c.drawLine(x, y, x + L * math.cos(a), y + L * math.sin(a), _stroke('#7A6A4C', .7, 30))
    for _ in range(14):
        x, y = r.uniform(x0, x1), r.uniform(y0, y1); c.drawCircle(x, y, r.uniform(2, 9), fp('#A07840', 22, 4))

# ------------------------------------------------------------------ ENGRAVING
def engraved(path, width=1600, color_wash=0.0):
    """Re-cut an image as an engraving: light = bare paper, half-tone = one line family, shadow = a crossing family,
    deepest dark = a third (lozenges); lines swell where tone is darker; contours cut heavier. Cached as PNG."""
    key = os.path.join(CACHE, 'eng_%d_%d_%s.png' % (width, int(color_wash * 100), os.path.basename(path)))
    if os.path.exists(key): return img(key)
    from PIL import Image, ImageFilter, ImageOps
    src = Image.open(path).convert('RGB'); hgt = int(src.height * width / src.width); src = src.resize((width, hgt), Image.LANCZOS)
    g = np.asarray(ImageOps.autocontrast(src.convert('L'), cutoff=1).filter(ImageFilter.GaussianBlur(1.6)), dtype=np.float32) / 255
    dark = np.clip(1 - g, 0, 1) ** 1.35                                # keep lights open: engravings are mostly paper
    yy, xx = np.mgrid[0:hgt, 0:width].astype(np.float32)
    sp = 7.0
    def fam(angle, thr, gain):
        a = math.radians(angle); d = (xx * math.cos(a) + yy * math.sin(a)) % sp
        d = np.minimum(d, sp - d)                                      # distance to the line centre
        w = np.clip((dark - thr) * gain, 0, 1) * (sp * .42)              # line half-width swells with darkness
        return np.clip(w - d + .6, 0, 1)
    ink = np.maximum.reduce([fam(30, .22, 1.5), fam(-30, .50, 1.8), fam(90, .74, 2.4)])
    edges = np.asarray(Image.fromarray((g * 255).astype(np.uint8)).filter(ImageFilter.FIND_EDGES), dtype=np.float32) / 255
    ink = np.maximum(ink, np.clip(edges * 2.2 - .25, 0, 1) * .9)
    pap = np.array([241, 232, 210], np.float32); ik = np.array([28, 21, 16], np.float32)
    out = pap[None, None, :] * (1 - ink[..., None]) + ik[None, None, :] * ink[..., None]
    if color_wash > 0:                                                   # hand-laid watercolour after printing, ink stays on top
        col_ = np.asarray(src.filter(ImageFilter.GaussianBlur(6)), np.float32)
        wash = pap * (1 - color_wash) + col_ * color_wash
        out = (wash * (1 - ink[..., None]) + ik * ink[..., None])
    Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save(key)
    return img(key)

def plate(c, t, t0, im, rect, focus=(.5, .5), z0=1.0, z1=1.12, dur=6.0, caption=None, credit=None, a=255):
    """an engraved image shown as a printed plate: sheet, bevelled plate mark, ruled border, slow push"""
    x0, y0, x1, y1 = rect; u = _clamp((t - t0) / dur)
    c.save(); c.drawRect(skia.Rect(x0 - 34, y0 - 34, x1 + 34, y1 + 60), fp('#000000', 60 * a / 255, 18))
    paper(c, (x0 - 34, y0 - 34, x1 + 34, y1 + 60))
    c.drawRect(skia.Rect(x0 - 14, y0 - 14, x1 + 14, y1 + 14), _stroke('#BFAF8E', 3, 200 * a / 255, cap=False))   # plate mark
    c.save(); c.clipRect(skia.Rect(x0, y0, x1, y1)); draw_cover(c, im, rect, focus, z0 + (z1 - z0) * _sm(u), a); c.restore()
    c.drawRect(skia.Rect(x0, y0, x1, y1), _stroke(INKE, 2, a, cap=False))
    if caption: text(c, caption, (x0 + x1) / 2, y1 + 44, 30, GARA_I, INKE, a * K(t, t0 + .3, .5), 'center')
    if credit: text(c, credit, x1 + 30, y1 + 54, 15, MONO, '#6E6350', a * .9, 'right')
    c.restore()

# ------------------------------------------------------------------ ARCHIVE LIGHT TABLE
class LightTable:
    """objects: {name: dict(path, x, y, w, rot)} in table units (1920x1080 world). cam keys: [(t, x, y, zoom)].
    loupe: [(t_on, t_off, name, fx, fy, mag)] - a loupe lands on an object and magnifies it.
    marks: [(t, name, fx, fy, label)] - counted red marks on an object; dots: [(t, x, y)] - free counted dots."""
    def __init__(self, objects, cam, loupe=(), marks=(), dots=(), off=None):
        self.o, self.cam, self.loupe, self.marks, self.dots, self.off = objects, cam, loupe, marks, dots, off
    def _cam(self, t):
        k = self.cam
        if t <= k[0][0]: return k[0][1:]
        for p, q in zip(k, k[1:]):
            if t <= q[0]: u = ease((t - p[0]) / (q[0] - p[0])); return tuple(p[i] + (q[i] - p[i]) * u for i in (1, 2, 3))
        return k[-1][1:]
    def _rect(self, ob):
        im = img(ob['path']); w = ob['w']; h = w * im.height() / im.width(); return skia.Rect(ob['x'] - w / 2, ob['y'] - h / 2, ob['x'] + w / 2, ob['y'] + h / 2)
    def obj_xy(self, name, fx, fy):
        ob = self.o[name]; r = self._rect(ob); x, y = r.left() + fx * r.width() - ob['x'], r.top() + fy * r.height() - ob['y']
        a = math.radians(ob.get('rot', 0)); return ob['x'] + x * math.cos(a) - y * math.sin(a), ob['y'] + x * math.sin(a) + y * math.cos(a)
    def draw(self, c, t):
        cx, cy, z = self._cam(t)
        lit = 1.0 if self.off is None else 1 - .9 * ease(K(t, self.off, .9))
        c.clear(col('#0E0F12'))
        c.save(); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-cx, -cy)
        tab = skia.Rect(-400, -300, W + 400, H + 300)
        p = skia.Paint(); p.setShader(skia.GradientShader.MakeRadial((W / 2, H / 2), 1500, [col('#F4F7FA', 255 * lit), col('#C9D0D8', 255 * lit)]))
        c.drawRect(tab, fp('#111215')); c.drawRect(tab, p)
        for name, ob in self.o.items():
            if t < ob.get('t0', -1e9): continue
            u = eout(K(t, ob.get('t0', -1e9), .5)); r = self._rect(ob)
            c.save(); c.translate(ob['x'], ob['y'] + 30 * (1 - u)); c.rotate(ob.get('rot', 0)); c.translate(-ob['x'], -ob['y'])
            c.drawRect(r.makeOutset(14, 14), fp('#FFFFFF', 210 * u * lit))                # glow: light passes the paper edge
            gl = fp('#FFF6E2', 120 * u * lit, 22); c.drawRect(r.makeOutset(10, 10), gl)
            c.drawRect(r.makeOutset(9, 9), fp('#E9E1CF', 255 * u))                        # photo mount
            pp = skia.Paint(AntiAlias=True); pp.setAlphaf(u * (.25 + .75 * lit))
            c.drawImageRect(img(ob['path']), r, skia.SamplingOptions(skia.FilterMode.kLinear), pp)
            if ob.get('label'): text(c, ob['label'], r.left(), r.bottom() + 34, 20, MONO, '#3A3F47', 255 * u * lit)
            c.restore()
        for (t0, name, fx, fy, lab) in self.marks:                                      # counted marks, one red
            u = eout(K(t, t0, .35))
            if u <= 0: continue
            x, y = self.obj_xy(name, fx, fy); fade = (1 - .7 * (1 - lit))
            c.drawCircle(x, y, 26 * u, _stroke(SIG, 5, 255 * fade, cap=False))
            if lab: text(c, lab, x, y - 38, 22, MONO, SIG, 255 * u * fade, 'center')
        for (t0, x, y) in self.dots:
            u = eout(K(t, t0, .3))
            if u > 0: c.drawCircle(x, y, 14 * u, fp(SIG, 255)); c.drawCircle(x, y, 22 * u, _stroke(SIG, 2, 120, cap=False))
        c.restore()
        for (t_on, t_off, name, fx, fy, mag) in self.loupe:                              # the loupe is the door
            a = ease(K(t, t_on, .45)) * (1 - ease(K(t, t_off - .35, .35)))
            if a <= 0: continue
            wx, wy = self.obj_xy(name, fx, fy); X, Y = W / 2 + (wx - cx) * z, H / 2 + (wy - cy) * z
            R = 190 * (.85 + .15 * a); ob = self.o[name]; im = img(ob['path']); r = self._rect(ob)
            c.save(); pth = skia.Path(); pth.addCircle(X, Y, R); c.clipPath(pth, doAntiAlias=True)
            c.drawCircle(X, Y, R, fp('#000000')); s = z * mag
            c.translate(X, Y); c.scale(s, s); c.translate(-wx, -wy); c.translate(ob['x'], ob['y']); c.rotate(ob.get('rot', 0)); c.translate(-ob['x'], -ob['y'])
            c.drawImageRect(im, r, skia.SamplingOptions(skia.FilterMode.kLinear), skia.Paint(AntiAlias=True))
            c.restore()
            c.drawCircle(X, Y, R, _stroke('#1A1C20', 18, 255 * a, cap=False)); c.drawCircle(X, Y, R + 9, _stroke('#8E949C', 3, 255 * a, cap=False))
            sh = skia.Paint(); sh.setShader(skia.GradientShader.MakeRadial((X - R * .4, Y - R * .5), R * 1.2, [col('#FFFFFF', 60 * a), col('#FFFFFF', 0)])); c.drawCircle(X, Y, R, sh)

# ------------------------------------------------------------------ NEWSREEL gate
def newsreel(c, t, im, focus=(.5, .5), z0=1.0, z1=1.08, t0=0.0, dur=5.0, a=1.0):
    """picture layer in a 1.37:1 projected gate with one silver grade, weave, flicker, dust and scratches"""
    c.clear(col('#000000')); gw, gh = 1480, 1080; x0 = (W - gw) / 2
    wx = 1.6 * math.sin(t * 7.3) + .8 * math.sin(t * 13.1); wy = 1.2 * math.sin(t * 5.1)
    fl = .9 + .06 * math.sin(t * 47) + .04 * math.sin(t * 91)
    rr = skia.RRect.MakeRectXY(skia.Rect(x0, 0, x0 + gw, gh), 26, 26)
    c.save(); c.clipRRect(rr, doAntiAlias=True); c.translate(wx, wy)
    u = _clamp((t - t0) / dur)
    gray = skia.ColorFilters.Matrix([.3 * fl, .59 * fl, .11 * fl, 0, 0, .3 * fl, .59 * fl, .11 * fl, 0, 0, .3 * fl, .59 * fl, .11 * fl, 0, 0, 0, 0, 0, a, 0])
    c.saveLayer(None, skia.Paint(ColorFilter=gray)); draw_cover(c, im, (x0 - 10, -10, x0 + gw + 10, gh + 10), focus, z0 + (z1 - z0) * _sm(u)); c.restore()
    r = np.random.default_rng(int(t * 24))
    for _ in range(14): c.drawCircle(x0 + r.uniform(0, gw), r.uniform(0, gh), r.uniform(.6, 2.4), fp('#FFFFFF' if r.random() < .5 else '#000000', r.uniform(60, 170)))
    if r.random() < .5: sx = x0 + r.uniform(0, gw); c.drawLine(sx, 0, sx + r.uniform(-8, 8), gh, _stroke('#FFFFFF', 1, 70, cap=False))
    v = skia.Paint(); v.setShader(skia.GradientShader.MakeRadial((W / 2, H / 2), 900, [col('#000000', 0), col('#000000', 170)], [.55, 1])); c.drawRect(skia.Rect(0, 0, W, H), v)
    c.restore()
    return (x0, 0, x0 + gw, gh)

# ------------------------------------------------------------------ UKIYO-E handscroll
def scroll(c, t, t0, dur, im, x_from=0.0, x_to=1.0, zoom=1.2, fy=.5):
    """a real woodblock print on fibre paper; the camera unrolls along it like a handscroll (no drift)"""
    paper(c, (0, 0, W, H), '#EFE6D2', 11)
    u = _sm(_clamp((t - t0) / dur)); fx = x_from + (x_to - x_from) * u
    m = 70; draw_cover(c, im, (m, m, W - m, H - m), (fx, fy), zoom)
    c.drawRect(skia.Rect(m, m, W - m, H - m), _stroke('#3B2A1A', 3, 160, cap=False))
    p = skia.Paint(); p.setShader(skia.GradientShader.MakeRadial((W / 2, H / 2), 1200, [col('#000000', 0), col('#2A1A0A', 90)], [.6, 1])); c.drawRect(skia.Rect(0, 0, W, H), p)

def seal(c, x, y, s, t, t0, lines=('EDICT', '1635')):
    """vermilion seal stamp, lands with a press"""
    u = K(t, t0, .25)
    if u <= 0: return
    k = 1.3 - .3 * eout(u); c.save(); c.translate(x, y); c.scale(k, k); c.rotate(-4)
    c.drawRoundRect(skia.Rect(-s / 2, -s / 2, s / 2, s / 2), 10, 10, fp(VERM, 235 * min(1, u * 2)))
    c.drawRoundRect(skia.Rect(-s / 2 + 10, -s / 2 + 10, s / 2 - 10, s / 2 - 10), 6, 6, _stroke('#F6E7D2', 4, 220, cap=False))
    for i, l in enumerate(lines): spaced(c, l, 0, -s * .06 + i * s * .3, s * .2, CINZEL_B, '#F6E7D2', 255, .06)
    c.restore()

# ------------------------------------------------------------------ GILDED ILLUMINATION
def _gold_paint(x0, x1, t, t_sweep):
    p = skia.Paint(AntiAlias=True)
    u = _clamp((t - t_sweep) / 1.4); sx = x0 - 300 + (x1 - x0 + 600) * u
    cols = [col('#C8973A'), col('#E7C062'), col('#FFF4C8') if 0 < u < 1 else col('#F0CF72'), col('#E7C062'), col('#C8973A')]
    p.setShader(skia.GradientShader.MakeLinear([(sx - 260, 0), (sx + 260, 0)], cols, [0, .35, .5, .65, 1], skia.TileMode.kClamp))
    return p
def gilded_frame(c, t, a=1.0):
    c.drawRect(skia.Rect(0, 0, W, H), fp(LAPIS, 255 * a))
    r = np.random.default_rng(5)
    for _ in range(160): c.drawCircle(r.uniform(0, W), r.uniform(0, H), r.uniform(.8, 2.2), fp('#E8D9A8', r.uniform(20, 70) * a))
    for inset, w, h in ((40, 10, VERM), (58, 3, GOLD), (70, 2, '#E8D9A8')):
        c.drawRect(skia.Rect(inset, inset, W - inset, H - inset), _stroke(h, w, 255 * a, cap=False))
    for (x, y) in ((70, 70), (W - 70, 70), (70, H - 70), (W - 70, H - 70)):
        c.save(); c.translate(x, y); c.rotate(45); c.drawRect(skia.Rect(-14, -14, 14, 14), fp(GOLD, 255 * a)); c.drawRect(skia.Rect(-6, -6, 6, 6), fp(VERM, 255 * a)); c.restore()
        for k in range(5): c.drawCircle(x + (1 if x < W / 2 else -1) * (30 + k * 16), y, 2.6, fp('#F4ECD2', 220 * a))
def gilded_title(c, t, t0, kicker, title, sub=None, a=1.0):
    """gold leaf lettering laid square by square, then a light passes and only then does it shine"""
    gilded_frame(c, t, a)
    spaced(c, kicker, W / 2, H * .36, 40, CINZEL, '#E8D9A8', 255 * a * K(t, t0, .4), .3)
    sz = 132
    while tw(title, CINZEL_B, sz) * 1.08 > W - 260: sz -= 4
    lay = K(t, t0 + .2, .9)
    f = font(CINZEL_B, sz); total = f.measureText(title) + .04 * sz * (len(title) - 1); x = W / 2 - total / 2; y = H * .55
    gp = _gold_paint(x, x + total, t, t0 + 1.0)
    for i, ch in enumerate(title):
        k = _clamp(lay * len(title) * 1.3 - i)
        if k > 0:
            gp2 = skia.Paint(gp); gp2.setAlphaf(min(1, k) * a)
            c.drawString(ch, x, y + 10 * (1 - min(1, k)), f, gp2)
        x += f.measureText(ch) + .04 * sz
    c.drawLine(W / 2 - 260 * lay, y + 50, W / 2 + 260 * lay, y + 50, _stroke(VERM, 4, 255 * a, cap=False))
    if sub: spaced(c, sub, W / 2, y + 120, 34, GARA, '#E8D9A8', 255 * a * K(t, t0 + 1.2, .5), .08)
def chapter_card(c, t, t0, part, name, year=None, a=1.0):
    gilded_frame(c, t, a)
    spaced(c, part, W / 2, H * .40, 38, CINZEL, GOLD, 255 * a * K(t, t0, .4), .35)
    sz = 104; f = font(CINZEL_B, sz); tot = f.measureText(name); gp = _gold_paint(W / 2 - tot / 2, W / 2 + tot / 2, t, t0 + .4)
    gp.setAlphaf(a * K(t, t0 + .15, .5)); c.drawString(name, W / 2 - tot / 2, H * .56, f, gp)
    if year: spaced(c, year, W / 2, H * .66, 36, GARA, '#E8D9A8', 255 * a * K(t, t0 + .6, .4), .2)

# ------------------------------------------------------------------ BLOODLINE (transit-map family line)
class Bloodline:
    """rulers: [dict(name, years, fate=None|'killed'|'overthrown', branch=None)]. The line runs on a sheet in
    eight directions (horizontal runs, 45-degree jogs); a glowing pen tip draws it; each ruler is a station; the crown
    rides the tip; killed or overthrown rulers are struck out in red."""
    def __init__(self, rulers, cols=6, gap=280, row=230, x0=230, y0=300):
        self.r = rulers; self.pts = []
        for i, _ in enumerate(rulers):
            rw, k = divmod(i, cols); k = k if rw % 2 == 0 else cols - 1 - k
            self.pts.append((x0 + k * gap, y0 + rw * row))
        self.path = skia.Path(); self.path.moveTo(*self.pts[0]); self.st = [0.0]; L = 0.0
        for (ax, ay), (bx, by) in zip(self.pts, self.pts[1:]):
            if ay == by: self.path.lineTo(bx, by); L += abs(bx - ax)
            else:                                                     # row change: out past the end station, 45-degree turns, down, back
                sgn = 1 if (len(self.st) // cols) % 2 == 1 else -1; ox = ax + sgn * 120; d = by - ay
                for px_, py_ in ((ox - sgn * 40, ay), (ox, ay + 40), (ox, by - 40), (ox - sgn * 40, by), (bx, by)): self.path.lineTo(px_, py_)
                L += 80 + 40 * 1.414 * 2 + (d - 80) + abs(ox - sgn * 40 - bx)
            self.st.append(L)
        self.L = L
    def draw(self, c, t, t0, t1, a=1.0, z=1.0, fx=None, fy=None, sheet=True):
        u = _clamp((t - t0) / max(.01, t1 - t0)); u = u * u * (3 - 2 * u); head = self.L * u
        c.save()
        if fx is not None: c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-fx, -fy)
        if sheet: paper(c, (-300, -200, W + 300, H + 300), '#F3EEE2', 7)
        p = _stroke('#7A1F1F', 16, 255 * a); p.setStrokeJoin(skia.Paint.kRound_Join)
        if head > 0:
            fr = head / self.L
            if fr < .999: p.setPathEffect(skia.TrimPathEffect.Make(0, max(.0001, fr)))
            c.drawPath(self.path, p)
        pm = skia.PathMeasure(self.path, False)
        for i, ((x, y), r) in enumerate(zip(self.pts, self.r)):
            if head + 1 < self.st[i]: continue
            k = eout(_clamp((head - self.st[i]) / 60 + .3))
            c.drawCircle(x, y, 17 * k, fp('#FFFFFF', 255 * a)); c.drawCircle(x, y, 17 * k, _stroke('#1C1C1C', 6, 255 * a, cap=False))
            up = (i % 2 == 0)
            nm = r['name']; yy = y - 40 if up else y + 62; yr_y = y - 74 if up else y + 94
            text(c, nm, x, yy, 30, BOLD, '#1C1C1C', 255 * a * k, 'center')
            text(c, r['years'], x, yr_y, 20, MONO, '#5A5A5A', 255 * a * k, 'center')
            if r.get('fate') and (head > self.st[i] + 40 or t > t1 + .25):
                s = eout(_clamp((head - self.st[i] - 40) / 80)) if head < self.L - 1 else eout(K(t, t1 + .25, .4)); w_ = tw(nm, BOLD, 30)
                c.drawLine(x - w_ / 2 - 6, yy - 10, x - w_ / 2 - 6 + (w_ + 12) * s, yy - 10, _stroke(SIG, 5, 255 * a))
        if 0 < u < 1:
            pos = pm.getPosTan(head)
            if pos:
                (hx, hy), _ = pos; c.drawCircle(hx, hy, 26, fp('#FFD23F', 120, 10)); c.drawCircle(hx, hy, 10, fp('#FFF6C8'))
                crown(c, hx, hy - 50, 1.0)
        c.restore()
def crown(c, x, y, s=1.0, h=GOLD):
    p = skia.Path(); w = 34 * s
    p.moveTo(x - w, y + 16 * s); p.lineTo(x - w, y - 10 * s); p.lineTo(x - w / 2, y + 4 * s); p.lineTo(x, y - 20 * s); p.lineTo(x + w / 2, y + 4 * s); p.lineTo(x + w, y - 10 * s); p.lineTo(x + w, y + 16 * s); p.close()
    c.drawPath(p, fp(h)); c.drawPath(p, _stroke('#5A3E10', 3, cap=False))
    for dx in (-w, 0, w): c.drawCircle(x + dx, y - (10 if dx else 20) * s, 5 * s, fp(VERM))

# ------------------------------------------------------------------ HISTORICAL MAP
_HB = {}
def hb_year(year):
    """borders for a year from historical-basemaps (A. Ourednik, GPL-3; data, downloaded once and cached)"""
    if year in _HB: return _HB[year]
    fn = os.path.join(CACHE, 'world_%d.geojson' % year)
    if not os.path.exists(fn):
        urllib.request.urlretrieve('https://raw.githubusercontent.com/aourednik/historical-basemaps/master/geojson/world_%d.geojson' % year, fn)
    d = json.load(open(fn)); out = {}
    for f in d['features']:
        n = f['properties'].get('NAME'); g = f['geometry']
        if not n or not g: continue
        polys = g['coordinates'] if g['type'] == 'MultiPolygon' else [g['coordinates']]
        p = out.get(n, skia.Path())
        for poly in polys:
            for ring in poly:
                for i, (lo, la) in enumerate(ring):
                    x, y = _merc(lo, la); (p.moveTo if i == 0 else p.lineTo)(x, -y)
                p.close()
        out[n] = p
    _HB[year] = out; return out
class HistMap:
    """the house map with a polity's real borders, crossfading between years.
    states: [(t, year, name)] - from t on, show `name` as it was in `year`."""
    def __init__(self, cam, states, h=ACC): self.cam, self.states, self.h = cam, states, h
    def draw(self, c, t, routes=(), pins=(), label=None, year_counter=None):
        mapx(c, t, self.cam, routes=(), pins=())                              # base: lit land, sea by depth
        lo, la, z = self.cam.at(t); cx, cy = _merc(lo, la)
        cur = [s for s in self.states if s[0] <= t] or self.states[:1]
        c.save(); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-cx, cy)
        for j, (ts, yr, nm) in enumerate(cur[-2:]):
            a = 1.0 if j == len(cur[-2:]) - 1 else 1.0
            k = ease(K(t, ts, .9)) if j == len(cur[-2:]) - 1 and len(cur) > 1 else 1.0
            if j == 0 and len(cur) > 1: k = 1 - ease(K(t, cur[-1][0], .9))
            p = hb_year(yr).get(nm)
            if p is None: continue
            g = skia.Paint(AntiAlias=True, Color=col(self.h, 150 * k)); g.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 14 / z)); c.drawPath(p, g)
            c.drawPath(p, fp('#E9A57E', 215 * k)); c.drawPath(p, skia.Paint(AntiAlias=True, Color=col('#8E3B12', 255 * k), Style=skia.Paint.kStroke_Style, StrokeWidth=2.4 / z))
        c.restore()
        if routes or pins: _overlay(c, t, (lo, la, z), routes, pins)
        if label:
            s, t0 = label; u = eout(K(t, t0, .5))
            if u > 0:
                s = s.upper(); w = tw(s, CINZEL_B, 54) + 80; y = H - 110 + 20 * (1 - u); r = skia.Rect(W / 2 - w / 2, y - 60, W / 2 + w / 2, y + 22)
                c.drawRRect(skia.RRect.MakeRectXY(r, 14, 14), fp('#0F1217', 215 * u)); text(c, s, W / 2, y, 54, CINZEL_B, '#F4ECD2', 255 * u, 'center')
        if year_counter:
            y0, y1, ta, tb = year_counter; u = _sm(K(t, ta, tb - ta)); yr = int(round(y0 + (y1 - y0) * u))
            if t >= ta - .3:
                r = skia.Rect(70, 70, 370, 170); c.drawRRect(skia.RRect.MakeRectXY(r, 14, 14), fp('#0F1217', 210))
                text(c, str(yr), 220, 147, 76, CINZEL_B, '#F4ECD2', 255, 'center')
def _overlay(c, t, cam, routes, pins):
    from moves import _to_xy
    lo, la, z = cam
    for r in routes:
        u = _clamp((t - r['t0']) / r.get('dur', 1.5))
        if u <= 0: continue
        pts = [_to_xy(a, b, cam) for a, b in r['pts']]
        path = skia.Path(); path.moveTo(*pts[0])
        for i in range(1, len(pts)):
            (x0, y0), (x1, y1) = pts[i - 1], pts[i]; path.quadTo((x0 + x1) / 2, (y0 + y1) / 2 - .15 * math.hypot(x1 - x0, y1 - y0), x1, y1)
        h = r.get('h', '#FFD23F')
        g = _trim(_stroke(h, 16, 110), eout(u)); g.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 10)); c.drawPath(path, g)
        c.drawPath(path, _trim(_stroke(h, 5, 255), eout(u)))
        if r.get('arrow') and u > .95:
            pm = skia.PathMeasure(path, False); pos = pm.getPosTan(pm.getLength())
            if pos:
                (hx, hy), (tx, ty) = pos; ang = math.atan2(ty, tx)
                for dd in (2.6, -2.6): c.drawLine(hx, hy, hx + 26 * math.cos(ang + dd), hy + 26 * math.sin(ang + dd), _stroke(h, 6))
    for pn in pins:
        u = eout(K(t, pn['t0'], .4))
        if u <= 0: continue
        x, y = _to_xy(pn['lon'], pn['lat'], cam); ph = (t - pn['t0']) % 1.6 / 1.6
        c.drawCircle(x, y, 10 + 40 * ph, _stroke('#FFFFFF', 3, 200 * (1 - ph))); c.drawCircle(x, y, 11 * u, fp('#FFFFFF')); c.drawCircle(x, y, 6 * u, fp(VERM))
        if pn.get('label'):
            s = pn['label']; w = tw(s, BOLD, 32) + 34; dx = pn.get('dx', 22); r = skia.Rect(x + dx, y - 56, x + dx + w, y - 8) if dx > 0 else skia.Rect(x + dx - w, y - 56, x + dx, y - 8)
            c.drawRRect(skia.RRect.MakeRectXY(r, 10, 10), fp('#0F1217', 220 * u)); text(c, s, r.left() + 17, y - 21, 32, BOLD, '#FFFFFF', 255 * u)

# ------------------------------------------------------------------ VISUAL INVESTIGATION
def investigation_bg(c):
    c.clear(col('#0B0D10'))
    for x in range(0, W, 120): c.drawLine(x, 0, x, H, _stroke('#FFFFFF', 1, 10, cap=False))
def readout(c, x, y, big, small, t, t0, a=1.0):
    u = K(t, t0, .3)
    if u <= 0: return
    text(c, small, x, y - 70, 24, MONO, '#8A929C', 255 * u * a); text(c, big, x, y, 70, MONO, '#F2F4F6', 255 * u * a)
def evidence(c, t, t0, im, rect, label, focus=(.5, .5), z=1.0, dashed=False, a=1.0, dim=0.0):
    """a source shown flat as evidence: thin frame, catalogue label, never re-drawn"""
    u = eout(K(t, t0, .4))
    if u <= 0: return
    x0, y0, x1, y1 = rect
    c.save(); c.clipRect(skia.Rect(x0, y0, x1, y1)); p = skia.Paint();
    gray = skia.ColorFilters.Matrix([.3, .59, .11, 0, 0, .3, .59, .11, 0, 0, .3, .59, .11, 0, 0, 0, 0, 0, u * a, 0])
    c.saveLayer(None, skia.Paint(ColorFilter=gray)); draw_cover(c, im, rect, focus, z); c.restore()
    if dim: c.drawRect(skia.Rect(x0, y0, x1, y1), fp('#000000', 255 * dim))
    c.restore()
    s = _stroke('#C9CED6', 2, 255 * u * a, cap=False)
    if dashed: s.setPathEffect(skia.DashPathEffect.Make([14, 10], 0))
    c.drawRect(skia.Rect(x0, y0, x1, y1), s)
    text(c, label, x0, y1 + 36, 22, MONO, '#C9CED6', 255 * u * a)

def name_card(c, t, t0, x, y, name, sub, a=1.0, dark=False):
    """documentary name card beside a portrait"""
    u = eout(K(t, t0, .45))
    if u <= 0: return
    h1, h2 = ('#F4ECD2', '#C9BC9A') if dark else (INKE, '#5C4F3A')
    c.drawLine(x, y - 70, x, y - 70 + 120 * u, _stroke(VERM, 5, 255 * a, cap=False))
    text(c, name, x + 24, y, 58, CINZEL_B, h1, 255 * u * a); text(c, sub, x + 26, y + 44, 30, GARA_I, h2, 255 * u * a)

def credit_line(c, s, dark=True):
    text(c, s, W - 40, H - 24, 15, MONO, '#9AA0A8' if dark else '#6E6350', 220, 'right')


def woodblock_title(c, t, t0, kicker, title, sub=None, seal_lines=None):
    """UKIYO-E title: fibre paper, a vermilion sun that presses in, carved black lettering, a seal"""
    paper(c, (0, 0, W, H), '#EFE6D2', 21)
    u = eout(K(t, t0, .7)); c.drawCircle(W * .5, H * .44, 300 * (.9 + .1 * u), fp(VERM, 235 * u))
    spaced(c, kicker, W / 2, H * .13, 38, CINZEL, INKE, 255 * K(t, t0 + .2, .4), .3)
    sz = 128
    while tw(title, CINZEL_B, sz) > W - 300: sz -= 4
    k = eout(K(t, t0 + .35, .5)); f = font(CINZEL_B, sz); tw_ = f.measureText(title)
    c.save(); c.translate(W / 2, H * .56); c.scale(1.12 - .12 * k, 1.12 - .12 * k)
    c.drawString(title, -tw_ / 2 + 4, 4, f, fp('#F4ECD2', 200 * k)); c.drawString(title, -tw_ / 2, 0, f, fp(INKE, 255 * k)); c.restore()
    if sub: spaced(c, sub, W / 2, H * .82, 34, GARA, INKE, 255 * K(t, t0 + .8, .4), .15)
    if seal_lines: seal(c, W - 230, H - 210, 150, t, t0 + 1.0, seal_lines)
