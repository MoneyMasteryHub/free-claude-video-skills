"""render an MMH tutorial project.
usage: python render.py PROJECT_DIR OUT.mp4            (full render)
       STILLS=3.2,10.5 python render.py PROJECT_DIR x  (png stills at voiceover times, for checking)
PROJECT_DIR/edit.py must: load_words(...), register scenes with S()/HD(), and set
  VO = 'voice.wav' (48 kHz stereo or mono), MUSIC = 'music.wav' or None,
  optional SEGS = [('V', v0, v1), ('H', 0, len, v_hold), (KEY, src_start, src_end), ...]
  optional INSERTS = {KEY: ('video.mp4', 'video_audio.wav', 'full'|'phone')}"""
import sys, os, subprocess, importlib
ENG = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, ENG)
proj = os.path.abspath(sys.argv[1]); out = os.path.abspath(sys.argv[2]); os.chdir(proj); sys.path.insert(0, proj)
import kit, timeline
from kit import *
E = importlib.import_module('edit'); timeline.finish()
import soundfile as sf
END = kit.WORDS[-1][1] + 1.0
SEGS = getattr(E, 'SEGS', None) or [('V', 0.0, getattr(E, 'END', END))]
INS = getattr(E, 'INSERTS', {})
surf = skia.Surface(W, H); c = surf.getCanvas()
if os.environ.get('STILLS'):
    for v in [float(x) for x in os.environ['STILLS'].split(',')]:
        timeline.frame(c, v); surf.makeImageSnapshot().save(f'{out}_{v:07.2f}.png', skia.kPNG)
    sys.exit()
OUTS = []; o = 0.0
for sg in SEGS: OUTS.append((o, sg)); o += sg[2] - sg[1]
TOT = o
enc = subprocess.Popen([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgra', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', out + '.v.mp4'], stdin=subprocess.PIPE)
cur = None; xc = None
for n in range(int(TOT * FPS)):
    Tt = n / FPS; o0, sg = [x for x in OUTS if x[0] <= Tt + 1e-9][-1]; kind = sg[0]; L = sg[2] - sg[1]
    if (o0, sg) != cur:
        cur = (o0, sg)
        if xc: xc.close(); xc = None
        if kind in INS: xc = Clip(INS[kind][0], sg[1], 1.0, 1080 if INS[kind][2] == 'phone' else 1920, dur=L + 1)
    if kind in INS:
        img = xc.at(int((Tt - o0) * FPS))
        if INS[kind][2] == 'phone': draw_bg2(c, Tt); phone(c, img, cx=W / 2, cy=540, h=960)
        else:
            c.clear(col('#000000')); c.drawImageRect(img, skia.Rect(0, 0, W, H))
            f = max(K(Tt, o0 + L - .35, .35), 1 - K(Tt, o0, .3))
            if f > 0: c.drawRect(skia.Rect(0, 0, W, H), fp('#000000', 255 * f))
    elif kind == 'B': c.clear(col('#000000'))
    else:
        vv = sg[3] + ((Tt - o0) * sg[4] if len(sg) > 4 else 0) if kind == 'H' else sg[1] + (Tt - o0)
        try: timeline.frame(c, vv)
        except Exception as e:                                         # never lose a whole render to one frame
            import traceback; print('frame', round(vv, 3), 'failed, retrying a hair later:', e); traceback.print_exc(limit=4)
            timeline.frame(c, vv + 0.002)
    enc.stdin.write(surf.makeImageSnapshot().toarray(colorType=skia.kBGRA_8888_ColorType).tobytes())
enc.stdin.close(); enc.wait()
SR = 48000
def rd(p):
    a, sr = sf.read(p)
    if a.ndim == 1: a = np.stack([a, a], 1)
    if sr != SR:
        import scipy.signal as ss; a = ss.resample_poly(a, SR, sr, axis=0)
    return a
vo = rd(E.VO); mu = rd(E.MUSIC) if getattr(E, 'MUSIC', None) else None
AUD = {k: rd(v[1]) for k, v in INS.items() if v[1]}
N = int(TOT * SR) + 1; outa = np.zeros((N, 2)); bed = np.zeros((N, 2)); env = np.zeros(N); mpos = 0; gate = np.zeros(N)
for o0, sg in OUTS:
    kind, a0, a1 = sg[:3]; i0 = int(o0 * SR); n = min(int((a1 - a0) * SR), N - i0)
    if kind in AUD:
        seg = AUD[kind][int(a0 * SR):int(a0 * SR) + n].copy(); fb = int(.5 * SR); fa = int(.05 * SR)
        if len(seg) > fb + fa: seg[-fb:] *= np.linspace(1, 0, fb)[:, None]; seg[:fa] *= np.linspace(0, 1, fa)[:, None]
        outa[i0:i0 + len(seg)] += seg
    elif kind in ('V', 'H'):
        seg = vo[int(a0 * SR):int(a0 * SR) + n] if kind == 'V' else np.zeros((n, 2))
        if len(seg) < n: seg = np.vstack([seg, np.zeros((n - len(seg), 2))])
        outa[i0:i0 + n] += seg; gate[i0:i0 + n] = 1; env[i0:i0 + n] = np.abs(seg).mean(1)
        if mu is not None: idx = (mpos + np.arange(n)) % len(mu); bed[i0:i0 + n] += mu[idx]; mpos = (mpos + n) % len(mu)
from scipy.signal import lfilter
k = int(.5 * SR); gate = np.convolve(gate, np.ones(k) / k, 'same'); tail = min(N, int(2.5 * SR)); gate[-tail:] *= np.linspace(1, 0, tail)
env = lfilter([1 - .9995], [1, -.9995], env); env = env / (env.max() + 1e-9)
outa += bed * (getattr(E, 'MUSIC_GAIN', 0.085) * gate * (1 - .5 * np.clip(env * 3, 0, 1)))[:, None]          # music bed, ducked under the voice
CLICK = np.random.default_rng(1).standard_normal(int(.006 * SR)) * np.exp(-np.arange(int(.006 * SR)) / SR * 900) * .05
def vt2o(v):
    for o0, sg in OUTS:
        if sg[0] == 'V' and sg[1] <= v < sg[2]: return o0 + v - sg[1]
for kind, t in kit.SFX:                                                              # soft clicks only, never over the voice
    oo = vt2o(t)
    if oo is None: continue
    i0 = int(oo * SR); g = 1.0 if kind == 'pop' else .5; m = min(len(CLICK), N - i0)
    if m > 0: outa[i0:i0 + m] += (CLICK[:m] * g)[:, None]
sf.write(out + '.wav', outa.astype(np.float32), SR)
subprocess.run([FF, '-v', 'error', '-y', '-i', out + '.v.mp4', '-i', out + '.wav', '-map', '0:v', '-map', '1:a', '-af', 'loudnorm=I=-14:TP=-1.5,aresample=48000', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', out], check=True)
os.remove(out + '.v.mp4'); os.remove(out + '.wav'); print('wrote', out, f'{TOT:.1f}s')
