"""scene registry: every scene is a function f(c, v, a, b) drawn while voiceover time v is in [a, b)"""
from kit import *
SC, HEADS = [], []
DARK = []   # [(t0, t1)] windows where the headline is hidden (giant-number beats, full-bleed maps)
def S(t0, head=None, keys=()):
    """register a scene starting at t0 with an optional word-timed headline (keys = words in accent colour)"""
    def deco(f):
        SC.append((t0, f))
        if head is not None: HEADS.append((t0, head, list(keys)))
        return f
    return deco
def HD(t0, head, keys=()): HEADS.append((t0, head, list(keys)))
def finish():
    SC.sort(key=lambda s: s[0]); HEADS.sort(key=lambda h: h[0])
def scene(c, v):
    i = max([j for j, s in enumerate(SC) if s[0] <= v + 1e-6] or [0]); a = SC[i][0]; b = SC[i + 1][0] if i + 1 < len(SC) else 1e9
    c.save(); SC[i][1](c, v, a, b); c.restore()
def frame(c, v, head_y=128):
    draw_bg2(c, v); scene(c, v)
    if not any(d0 <= v < d1 for d0, d1 in DARK): headline(c, v, HEADS, y=head_y)
