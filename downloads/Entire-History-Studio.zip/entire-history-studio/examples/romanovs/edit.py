"""DEMO: The Entire History of the Romanovs (dynasty mode, ~81 s). SITCOM TOON cartoon + real satellite map + real photos and paintings."""
import sys, os
ENG = os.environ.get('EHS_ENGINE', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'engine')); sys.path.insert(0, ENG)
from kit import *
load_words('words.json')
from timeline import S as _S
from moves import _clamp, _sm, _stroke, _trim, MapCam
from history import img
from satmap import SatMap, caption_card, year_tag
from toon import *
from toon import _hat

VO = 'vo.wav'; MUSIC = 'score.wav'; MUSIC_GAIN = 0.5; M = 'media/'
CHAP = 1000.0                                                   # chapter card on its own clock (a silent hold)
SEGS = [('V', 0.0, 33.95), ('H', 0, 2.6, CHAP, 1.0), ('V', 33.95, 78.6)]
WAR, MOS, KOS, EKB, OKH = (21.0, 52.23), (37.62, 55.75), (40.93, 57.77), (60.6, 56.84), (143.3, 59.36)
SM = SatMap()
def cred(c, s, dark=False): text(c, s, W - 40, H - 22, 15, MED, '#E8EEF4' if dark else '#3A3040', 220, 'right')
CUTS = [31.0, 33.95, 63.5]
def end(c, v): portal_wipe(c, v, CUTS + [CHAP, CHAP + 2.6], .32)
def S(t0):                                     # every scene ends by drawing the time-portal wipe if a cut is near
    def d(fn):
        def g(c, v, a, b): fn(c, v, a, b); end(c, v)
        g.__name__ = fn.__name__; return _S(t0)(g)
    return d
BG = '#7B6A57'

# 1 ── night, a lit window, a date
@S(0.0)
def _(c, v, a, b):
    def inner(c):
        outdoor(c, v, 'night'); house(c, 1100, 900, 1.25, v, lit=True)
        person(c, 420, 1000, .9, SPEC['guard'], v, 'idle', 'normal', face=1, seed=1); person(c, 600, 1000, .9, SPEC['guard'], v, 'cross', 'normal', seed=3)
        tag(c, 'July 17, 1918', 330, 170, v, 1.4, 60, -3)
        tag(c, 'just after midnight', 360, 260, v, .5, 40, 2)
    panel(c, inner)

# 2 ── satellite: where
cam1 = MapCam([(4.4, 52, 57, 9), (6.6, 60.6, 56.8, 34)])
@S(4.4)
def _(c, v, a, b):
    SM.draw(c, v, cam1, fills=[dict(iso='RUS', t0=4.5, t1=6.2)], pins=[dict(lon=EKB[0], lat=EKB[1], label='Yekaterinburg', t0=5.9)], label=('The Ural Mountains', 5.6))
    cred(c, 'Imagery: NASA Blue Marble  ·  Map: Natural Earth', True)

# 3 ── woken, told to dress, taken down
@S(6.9)
def _(c, v, a, b):
    def inner(c):
        room(c, 'palace' if v < 9.4 else 'basement', v)
        if v < 9.4:
            person(c, 1250, 1000, 1.05, SPEC['guard'], v, 'point', 'angry', talk=v > 7.4, face=-1)
            person(c, 640, 1000, 1.05, SPEC['nicholas'], v, 'idle', 'wide'); person(c, 840, 1000, 1.0, SPEC['alexandra'], v, 'sad', 'scared', seed=2)
            bubble(c, 'Get dressed.\nYou\'re moving.', 1050, 380, v, 7.5, tail=(150, 110))
        else:
            for i, k in enumerate(['nicholas', 'alexandra', 'daughter', 'daughter', 'son']):
                x = 380 + i * 230 - 180 * (1 - eout(K(v, 9.4 + i * .12, .6)))
                person(c, x, 1010, .95, SPEC[k], v, 'sad', 'scared', seed=i, face=-1 if i % 2 else 1)
            person(c, 1650, 1010, 1.0, SPEC['guard'], v, 'cross', 'angry', face=-1)
            light_cone(c, 960, 186, 70, 1100, 1010)
            tag(c, 'the basement', 340, 160, v, 10.6, 52)
    if v < 11.0: inner(c)
    else:
        room(c, 'basement', v); closeup(c, 1300, 640, 2.6, 0, v)
        person(c, 1300, 1010, .95, SPEC['son'], v, 'sad', 'scared', seed=4, face=-1); c.restore()
        light_cone(c, 1150, 0, 260, 900, 1080, 150)

# 4 ── the real family, named face by face
FACES = [('Nicholas, father', .633, .355, 12.2), ('Alexandra, mother', .44, .42, 13.2), ('Olga', .50, .163, 14.3), ('Tatiana', .617, .157, 14.4),
         ('Maria', .32, .28, 14.5), ('Anastasia', .81, .45, 14.6), ('Alexei, 13', .40, .755, 15.5)]
@S(11.9)
def _(c, v, a, b):
    wall(c, 'warm', v); R = (413, 70, 1507, 960)
    photo_card(c, img(M + 'family.jpg'), R, v, 11.9, -1, None, None, 1.0, 5.0)
    x0, y0, x1, y1 = R
    for (s, fx, fy, t0) in FACES:
        u = eout(K(v, t0, .3))
        if u <= 0: continue
        x, y = x0 + fx * (x1 - x0), y0 + fy * (y1 - y0)
        scribble_circle(c, x, y, 66, 72, v, t0)
        tag(c, s, x, y + 112, v, t0, 30, -2)
    cred(c, 'Boasson and Eggler, c.1914 / Wikimedia Commons / public domain')

# 5 ── four more people
@S(16.9)
def _(c, v, a, b):
    def inner(c):
        room(c, 'basement', v)
        for i, (k, nm) in enumerate([('doctor', 'the doctor'), ('maid', 'the maid'), ('cook', 'the cook'), ('servant', 'the footman')]):
            t0 = 17.3 + i * .3; x = 420 + i * 360
            person(c, x, 1000 + 60 * (1 - eout(K(v, t0, .35))), 1.0, SPEC[k], v, 'idle', 'sad', seed=i, a=K(v, t0, .2))
            tag(c, nm, x, 300, v, t0 + .1, 40, -2 + i)
    panel(c, inner)

# 6 ── the real room
@S(19.4)
def _(c, v, a, b):
    wall(c, 'dark', v)
    photo_card(c, img(M + 'cellar.jpg'), (360, 110, 1560, 900), v, 19.4, 1, 'The basement room, photographed 1918-19', None, 1.12, 2.5)
    c.drawRect(skia.Rect(0, 0, W, H), fp('#000000', 120 * K(v, 20.6, .6))); cred(c, 'Unknown, 1918-19 / Wikimedia Commons / public domain', True)

# 7 ── the father: Nicholas II
@S(21.4)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'nicholas.jpg'), (620, 70, 1300, 900), v, 21.4, -2, 'Nicholas II, c.1909', None, 1.1, 4.5, (.5, .3))
    tag(c, 'the last Tsar of Russia', 1500, 520, v, 23.9, 46, 3, '#E5533C', CREAM)
    cred(c, 'Boissonnas & Eggler, c.1909 / Wikimedia Commons / public domain')

# 8 ── the family tree as a transit line: 304 years, 18 rulers, and it ENDS with him
RULERS = [dict(name='Michael', years='1613', face='boy'), dict(name='Alexis', years='1645', face='beard'), dict(name='Feodor III', years='1676', face='clean'),
          dict(name='Ivan V', years='1682', face='clean'), dict(name='Peter I', years='1682', face='clean'), dict(name='Catherine I', years='1725', face='woman'),
          dict(name='Peter II', years='1727', face='boy'), dict(name='Anna', years='1730', face='woman'), dict(name='Ivan VI', years='1740', face='boy', fate='killed'),
          dict(name='Elizabeth', years='1741', face='woman'), dict(name='Peter III', years='1762', face='clean', fate='killed'), dict(name='Catherine II', years='1762', face='woman'),
          dict(name='Paul I', years='1796', face='bald', fate='killed'), dict(name='Alexander I', years='1801', face='clean'), dict(name='Nicholas I', years='1825', face='clean'),
          dict(name='Alexander II', years='1855', face='long', fate='killed'), dict(name='Alexander III', years='1881', face='beard'), dict(name='Nicholas II', years='1894', face='trim', fate='killed')]
BL = Bloodline(RULERS, y0=300, row=225)
@S(26.0)
def _(c, v, a, b):
    wall(c, 'red', v)
    d, (hx, hy) = BL.tip(v, 26.2, 28.9)
    z = 1.55 + (1.0 - 1.55) * _sm(_clamp((v - 28.7) / .6)); fx = hx + (W / 2 - hx) * _sm(_clamp((v - 28.7) / .6)); fy = hy + (H / 2 - 40 - hy) * _sm(_clamp((v - 28.7) / .6))
    fx = max(W / 2 / z, min(W - W / 2 / z, fx)); fy = max(H / 2 / z, min(H - H / 2 / z, fy))
    closeup(c, fx, fy, z, 0, v); BL.draw(c, v, 26.2, 28.9, end_t=29.5); c.restore()
    if v > 29.5:
        x, y = BL.pts[-1]; tag(c, 'END OF THE LINE', x - 60, y + 150, v, 29.6, 54, -4, '#E5533C', CREAM)
    tag(c, '304 years', 1560, 110, v, 28.8, 64, 3, '#E5533C', CREAM)
    year_tag(c, 1613, 1917, 26.3, 28.9, v)

# 9 ── title, then the chapter card (silent hold)
@S(31.0)
def _(c, v, a, b): title_card(c, v, 31.0, 'THE ENTIRE HISTORY OF THE', 'ROMANOVS', '1613 to 1917', '#B0302A'); guide(c, 1680, 1060, 1.0, v, 'wave', 'happy')
@S(CHAP)
def _(c, v, a, b):
    title_card(c, v, CHAP, 'CHAPTER ONE', 'THE BOY', 'nobody wanted the job', '#2E5E8C')

# 10 ── another boy; 1613; an empty throne
@S(33.95)
def _(c, v, a, b):
    def inner(c):
        room(c, 'palace', v); throne(c, 1150, 930, 1.05, v, web=True)
        guide(c, 420, 1020, 1.0, v, 'point', 'normal', talk=v < 36.0 or 39.3 < v < 40.4)
        bubble(c, 'Hello? Anyone?', 520, 380, v, 39.3, tail=(-40, 100))
        tag(c, '1613', 300, 160, v, 36.6, 90, -4)
    if v < 39.1: inner(c)
    else:
        room(c, 'palace', v); closeup(c, 450, 620, 2.4, 0, v)
        guide(c, 420, 1020, 1.0, v, 'shrug', 'deadpan', talk=39.3 < v < 40.4); c.restore()
        bubble(c, 'Hello?\nAnyone?', 1150, 420, v, 39.3, tail=(-160, 90))

# 11 ── the old line gone: real painting of Moscow then
@S(41.1)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'heralds.jpg'), (260, 90, 1660, 880), v, 41.1, -1.2, 'Moscow, early 1600s (Apollinary Vasnetsov)', None, 1.1, 2.5)
    cred(c, 'Apollinary Vasnetsov / Wikimedia Commons / public domain')

# 12 ── satellite: the Poles driven out of Moscow
cam2 = MapCam([(43.5, 30, 54, 14), (46.4, 36, 55.5, 22)])
@S(43.5)
def _(c, v, a, b):
    SM.draw(c, v, cam2, fills=[dict(year=1600, name='Tsardom of Muscovy', t0=43.6)],
            routes=[dict(pts=[WAR, (29, 55.5), MOS], t0=43.8, dur=1.0, h='#FFFFFF'), dict(pts=[MOS, (29, 53.2), WAR], t0=45.5, dur=1.0, h='#FFC93C', arrow=True)],
            pins=[dict(lon=MOS[0], lat=MOS[1], label='Moscow', t0=44.0), dict(lon=WAR[0], lat=WAR[1], label='Poland', t0=43.9, dx=-26)],
            label=('Polish troops driven out', 45.4))
    cred(c, 'Imagery: NASA Blue Marble  ·  Borders: historical-basemaps', True)

@S(46.6)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'minin.jpg'), (330, 100, 1590, 880), v, 46.6, 1.5, 'Minin and Pozharsky, who freed Moscow in 1612', None, 1.08, 2.0)
    cred(c, 'Wikimedia Commons / public domain')

# 13 ── the assembly argues, then picks a sixteen-year-old
@S(48.9)
def _(c, v, a, b):
    def inner(c):
        room(c, 'hall', v)
        for i, k in enumerate(['boyar', 'boyar2', 'boyar3', 'monk']):
            person(c, 260 + i * 250, 1000, 1.0, SPEC[k], v, ['shrug', 'point', 'cross', 'idle'][i] if v < 52.2 else 'point', 'angry' if v < 51.3 else 'happy', talk=(48.9 + i * .6) < v < (49.9 + i * .6), seed=i)
        bubble(c, 'Not him!', 300, 330, v, 49.0, dur=1.1); bubble(c, 'Who, then?!', 820, 300, v, 50.2, dur=1.1)
        u = eout(K(v, 52.2, .4)); mx = 1550
        person(c, mx, 1000, 1.0, SPEC['michael'], v, 'idle', 'scared' if v > 52.4 else 'normal', a=K(v, 51.6, .3), face=-1)
        if v > 52.5:
            c.save(); c.translate(mx + 5, 560 - 20 * math.sin(on_twos(v) * 3)); c.scale(.9, .9); _hat(c, 'monomakh', v); c.restore()
        tag(c, 'Michael Romanov, 16', mx, 260, v, 53.8, 48, -3, '#E5533C', CREAM)
    if v < 54.5: inner(c)
    else:
        room(c, 'hall', v); closeup(c, 1550, 640, 2.5, 8 * (v < 54.8), v)
        person(c, 1550, 1000, 1.0, SPEC['michael'], v, 'up', 'scared', face=-1); c.restore()
        bubble(c, 'ME?!', 1050, 380, v, 54.6, tail=(180, 90), sz=80)

# 14 ── satellite: the messengers ride to Kostroma
cam3 = MapCam([(55.6, 38.5, 56.6, 30), (58.6, 40.2, 57.3, 60)])
def rider(c, x, y, a, t): person(c, x, y + 30, .3, SPEC['messenger'], t, 'run', 'normal')
@S(55.6)
def _(c, v, a, b):
    SM.draw(c, v, cam3, routes=[dict(pts=[MOS, (39.6, 57.0), KOS], t0=56.0, dur=2.6, icon=rider)],
            pins=[dict(lon=MOS[0], lat=MOS[1], label='Moscow', t0=55.7, dx=-26), dict(lon=KOS[0], lat=KOS[1], label='Kostroma', t0=58.9)],
            label=('The messengers ride north', 56.0))
    cred(c, 'Imagery: NASA Blue Marble', True)

# 15 ── the monastery: real photo, real name
@S(59.6)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'monastery_photo.jpg'), (300, 100, 1620, 880), v, 59.6, -1, 'Kostroma, today', None, 1.1, 2.2)
    tag(c, 'IPATIEV Monastery', 960, 220, v, 61.4, 80, -3, '#E5533C', CREAM)
    cred(c, 'Wikimedia Commons / CC BY-SA')

@S(62.3)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'vocation.jpg'), (300, 90, 1620, 880), v, 62.3, 1.2, 'The envoys beg Michael to take the crown (Grigory Ugryumov, c.1800)', None, 1.08, 1.4)
    cred(c, 'Grigory Ugryumov / Wikimedia Commons / public domain')

# 16 ── 305 years later: the same name, twice (red string)
@S(63.5)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'monastery_1613.jpg'), (110, 170, 860, 760), v, 63.5, -3, 'Ipatiev Monastery, 1613', None, 1.05, 5)
    photo_card(c, img(M + 'ipatiev_house.jpg'), (1060, 170, 1810, 760), v, 64.9, 3, 'Ipatiev House, 1918', None, 1.05, 5)
    u = eout(K(v, 66.6, .8))
    if u > 0:
        p = skia.Path(); p.moveTo(780, 300); p.quadTo(960, 460, 1140, 300); c.drawPath(p, _trim(_stroke('#C8463A', 7), u))
        for x in (780, 1140): c.drawCircle(x, 300, 14, fp('#C8463A')); c.drawCircle(x, 300, 14, _stroke(INKC, 3, cap=False))
    tag(c, '305 years later', 960, 940, v, 63.7, 64, -2)
    tag(c, 'same name', 960, 520, v, 67.9, 50, 3, '#E5533C', CREAM)
    cred(c, 'Monastery: engraving, public domain  ·  House: A. Nametkin / CC BY-SA 4.0')

# 17 ── the nervous teenager on the throne
@S(69.4)
def _(c, v, a, b):
    def inner(c):
        room(c, 'palace', v); throne(c, 960, 930, 1.05, v)
        person(c, 960, 870, .95, SPEC['michael'], v, 'idle', 'scared' if v < 71.5 else 'happy')
        bubble(c, 'um... hi?', 1350, 380, v, 70.0, dur=1.4)
        tag(c, 'Tsar Michael I', 960, 200, v, 69.6, 56, -2)
    if v < 70.9: inner(c)
    else:
        room(c, 'palace', v); closeup(c, 990, 560, 2.6, 0, v); throne(c, 960, 930, 1.05, v)
        person(c, 960, 870, .95, SPEC['michael'], v, 'idle', 'scared'); c.restore()

@S(71.6)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'yermak.jpg'), (220, 110, 1700, 880), v, 71.6, -1, 'Cossacks push into Siberia (Vasily Surikov)', None, 1.08, 2.2)
    cred(c, 'Vasily Surikov / Wikimedia Commons / public domain')

# 18 ── satellite: across Siberia to the Pacific
cam4 = MapCam([(73.6, 62, 58, 9), (78.6, 96, 58, 8)])
def boat(c, x, y, a, t): ship(c, x, y + 8, .14, t, 'sail', -1 if math.cos(a) < 0 else 1)
@S(73.6)
def _(c, v, a, b):
    SM.draw(c, v, cam4, fills=[dict(year=1600, name='Tsardom of Muscovy', t0=73.6, t1=74.6), dict(year=1650, name='Tsardom of Muscovy', t0=74.4)],
            routes=[dict(pts=[MOS, (68.25, 58.2), (92.2, 58.45), (129.7, 62.0), OKH], t0=74.4, dur=2.4, icon=boat)],
            pins=[dict(lon=MOS[0], lat=MOS[1], label='Moscow', t0=73.7, dx=-26), dict(lon=OKH[0], lat=OKH[1], label='The Pacific, 1639', t0=76.7, dx=-26)],
            year=(1613, 1639, 73.9, 76.6))
    cred(c, 'Imagery: NASA Blue Marble  ·  Borders: historical-basemaps (A. Ourednik)', True)
