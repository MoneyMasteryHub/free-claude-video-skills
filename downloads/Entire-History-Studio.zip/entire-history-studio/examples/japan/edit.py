"""DEMO: The Entire History of Japan (hook, ~30 s). SITCOM TOON cartoon + real satellite map + real prints, time-portal wipes between eras."""
import sys, os
ENG = os.environ.get('EHS_ENGINE', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'engine')); sys.path.insert(0, ENG)
from kit import *
load_words('words.json')
from timeline import S
from moves import _clamp, _sm, _stroke, MapCam
from history import img
from satmap import SatMap, year_tag
from toon import *

VO = 'vo.wav'; MUSIC = 'score.wav'; MUSIC_GAIN = 0.5; M = 'media/'
END = 30.6
EDO = (139.75, 35.45)
SM = SatMap()
JPN = land('JPN', min_area=1.0); RUS = land('RUS', lon=(20, 179), min_area=4.0)
CUTS = [12.3, 21.2, 26.8]                          # era jumps go through the time portal
def end(c, v): portal_wipe(c, v, CUTS, .32)
def mapcred(c): text(c, 'Imagery: NASA Blue Marble', W - 40, H - 22, 15, MED, '#E8EEF4', 200, 'right')

# 1 ── satellite: the islands, the closed years start counting
cam1 = MapCam([(0.0, 137.5, 36.5, 30), (2.7, 137.5, 36.8, 44)])
@S(0.0)
def _(c, v, a, b):
    SM.draw(c, v, cam1, fills=[dict(iso='JPN', t0=.3)], pins=[dict(lon=EDO[0], lat=EDO[1], label='Edo', t0=1.4)],
            label=('Japan', 1.9), year=(1639, 1853, .4, 2.6)); mapcred(c)

# 2 ── Japan slams the door on the world; Quill's deadpan
@S(2.7)
def _(c, v, a, b):
    outdoor(c, v, 'sea')
    if v < 4.3:
        sh = 14 * (1 - _clamp((v - 3.45) / .3)) if v > 3.45 else 0
        closeup(c, W / 2, H / 2, 1.0, sh, v)
        door(c, 1180, 960, 1.35, 1 - _clamp((v - 2.9) / .55), '#8C5A30', 'CLOSED', v)
        blob(c, 760, 900, 380, JPN, '#D8322A', v, 'angry' if v > 3.45 else 'normal', arms=(150 if v < 3.45 else 30, 60))
        guide(c, 1720, 1010, .95, v, 'idle', 'wide', face=-1, look=(-.4, 0))
        c.restore()
    else:
        outdoor(c, v, 'sea'); closeup(c, 1700, 640, 2.3, 0, v)
        guide(c, 1720, 1010, .95, v, 'idle', 'deadpan', talk=4.5 < v < 5.2, face=-1, look=(.4, 0))
        c.restore()
        bubble(c, 'Two hundred years.\nShut.', 760, 420, v, 4.45, tail=(160, 90))
    end(c, v)

# 3 ── foreign ships turned away; the samurai yells
@S(5.4)
def _(c, v, a, b):
    if v < 6.7:
        outdoor(c, v, 'shore')
        ship(c, 640 - 120 * _sm(_clamp((v - 5.9) / .8)), 690, 1.15, v, 'sail', -1 if v > 6.1 else 1)
        person(c, 1330, 1020, 1.0, SPEC['samurai'], v, 'point', 'angry', talk=v > 5.7, face=-1)
        person(c, 1640, 1020, .95, SPEC['shogun'], v, 'cross', 'deadpan', face=-1, seed=2)
        tag(c, 'Sakoku: "the closed country"', 520, 140, v, 5.5, 46)
    else:
        outdoor(c, v, 'shore'); closeup(c, 1310, 640, 2.4, 10 * (v < 7.0), v)
        person(c, 1330, 1020, 1.0, SPEC['samurai'], v, 'point', 'angry', talk=True, face=-1); c.restore()
        bubble(c, 'TURN. AROUND.', 660, 400, v, 6.75, tail=(170, 80), sz=64)
    end(c, v)

# 4 ── real print: Edo itself, Quill points at it
@S(7.6)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'nihonbashi.jpg'), (150, 110, 1370, 860), v, 7.6, -1.5, 'Edo, inside the closed country', 'Utagawa Hiroshige, Nihonbashi, c.1833 / The Met, CC0', 1.1, 2.5)
    guide(c, 1690, 1060, 1.0, v, 'point', 'normal', face=-1)
    end(c, v)

# 5 ── leave, and you can never come home
@S(9.6)
def _(c, v, a, b):
    if v < 11.45:
        outdoor(c, v, 'shore')
        x = 360 + 330 * _sm(_clamp((v - 9.6) / 1.5))
        ship(c, x, 760, .6, v, 'sail'); person(c, x - 40, 730, .42, SPEC['fisher'], v, 'wave', 'happy')
        person(c, 1500, 1020, 1.05, SPEC['samurai'], v, 'cross', 'angry', talk=v > 10.0, face=-1)
        bubble(c, 'You left?\nThen stay out.', 1230, 400, v, 10.0, tail=(170, 110))
    else:
        outdoor(c, v, 'shore'); closeup(c, x := 690 - 40, 640, 3.2, 0, v)
        ship(c, 690, 760, .6, v, 'sail'); person(c, 650, 730, .42, SPEC['fisher'], v, 'sad', 'scared'); c.restore()
        tag(c, 'PENALTY: DEATH', 960, 170, v, 11.45, 76, -4, '#E5533C', CREAM)
    end(c, v)

# 6 ── portal to 1853: the man who knocked
@S(12.3)
def _(c, v, a, b):
    wall(c, 'cool', v)
    photo_card(c, img(M + 'perry_portrait.jpg'), (560, 90, 1300, 860), v, 12.3, 2, 'Commodore Matthew Perry, US Navy', 'Photograph c.1855-56 / Library of Congress / public domain', 1.12, 3.0, (.5, .3))
    tag(c, '1853', 330, 230, v, 14.0, 120, -6, '#E5533C', CREAM)
    scribble_circle(c, 935, 330, 150, 170, v, 13.0)
    scribble_arrow(c, 1450, 560, 1110, 420, v, 13.35)
    guide(c, 1650, 1060, 1.0, v, 'point', 'wide', face=-1)
    end(c, v)

# 7 ── satellite: four warships into Edo Bay
cam2 = MapCam([(15.3, 150, 31, 14), (17.4, 141, 34.6, 30), (19.6, 140.0, 35.2, 52)])
@S(15.3)
def _(c, v, a, b):
    rts = [dict(pts=[(166.0, 25.0 + k * 1.4), (148.0, 31.0 + k * .5), (EDO[0] + .1 * k, EDO[1] - .4 + .1 * k)], t0=15.5 + k * .22, dur=2.4, icon=ship_icon(.22)) for k in range(4)]
    SM.draw(c, v, cam2, fills=[dict(iso='JPN', t0=15.3)], routes=rts, pins=[dict(lon=EDO[0], lat=EDO[1], label='Edo Bay', t0=17.6)],
            label=('Four American warships', 15.7), year=(1853, 1853, 15.3, 15.4)); mapcred(c)

# 8 ── forced open, and Japan's face
@S(19.6)
def _(c, v, a, b):
    if v < 20.55:
        outdoor(c, v, 'sea'); ship(c, 330, 700, .9, v, 'black')
        sh = 16 * (1 - _clamp((v - 19.95) / .3)) if v > 19.95 else 0
        closeup(c, W / 2, H / 2, 1.0, sh, v)
        door(c, 1080, 960, 1.35, _clamp((v - 19.9) / .2), '#8C5A30', 'CLOSED', v)
        person(c, 720, 1020, 1.05, SPEC['perry'], v, 'fist' if v < 19.95 else 'point', 'angry', talk=v > 20.0)
        blob(c, 1520, 920, 330, JPN, '#D8322A', v, 'scared', arms=(150, 150))
        c.restore()
        bubble(c, 'KNOCK KNOCK.', 640, 380, v, 19.7, tail=(40, 110))
    else:
        outdoor(c, v, 'sea'); closeup(c, 1520, 760, 2.6, 6, v)
        blob(c, 1520, 920, 330, JPN, '#D8322A', v, 'scared', arms=(150, 150)); c.restore()
    end(c, v)

# 9 ── portal: fifty years of catching up (real images)
@S(21.2)
def _(c, v, a, b):
    wall(c, 'warm', v)
    photo_card(c, img(M + 'meiji.jpg'), (150, 160, 820, 840), v, 21.3, -3, 'Emperor Meiji, 1873', None, 1.08, 2.0, (.5, .35))
    photo_card(c, img(M + 'fleet.jpg'), (900, 230, 1760, 860), v, 22.4, 2.5, 'The new navy, 1902', 'Meiji: Uchida Kuichi, 1873 / Fleet: Royal Museums Greenwich / public domain', 1.08, 2.0)
    year_tag(c, 1853, 1904, 21.4, 23.0, v)
    end(c, v)

# 10 ── the closed island beats the Russian Empire
@S(23.9)
def _(c, v, a, b):
    if v < 25.45:
        outdoor(c, v, 'field')
        hit = _clamp((v - 25.1) / .1); sh = 18 * (1 - _clamp((v - 25.1) / .35)) if v > 25.1 else 0
        closeup(c, W / 2, H / 2, 1.0, sh, v)
        blob(c, 1270 + 120 * hit, 960, 900, RUS, '#4A78B0', v, 'scared' if hit > 0 else 'smug', talk=24.6 < v < 25.1, arms=(20, 20))
        blob(c, 470 + 260 * _sm(_clamp((v - 24.7) / .4)), 900, 270, JPN, '#D8322A', v, 'angry', arms=(30, 175 if v > 24.9 else 60))
        c.restore()
        tag(c, 'Japan', 470, 360, v, 24.0, 52); tag(c, 'Russian Empire', 1270, 300, v, 24.6, 52, 2)
        if 25.1 < v < 25.45: shape(c, spline([(980 + 90 * math.cos(i * .785) * (1.6 if i % 2 else .8), 700 + 90 * math.sin(i * .785) * (1.6 if i % 2 else .8)) for i in range(8)]), '#FFE14A', False, 7)
    else:
        outdoor(c, v, 'field'); closeup(c, 1390, 690, 2.2, 0, v)
        blob(c, 1390, 960, 900, RUS, '#4A78B0', v, 'scared', arms=(20, 20)); c.restore()
        bubble(c, 'Ow?!', 1000, 330, v, 25.5, tail=(120, 90), sz=70)
    end(c, v)

@S(25.9)
def _(c, v, a, b):
    wall(c, 'red', v)
    photo_card(c, img(M + 'liaoyang.jpg'), (250, 110, 1670, 860), v, 25.9, -1.5, 'Battle of Liaoyang, 1904', 'Ogata Gessan, 1904 / public domain', 1.06, 1.2)
    end(c, v)

# 11 ── title
@S(26.8)
def _(c, v, a, b):
    title_card(c, v, 26.95, 'THE ENTIRE HISTORY OF', 'JAPAN', 'from the first emperors to today')
    guide(c, 1680, 1070, 1.0, v, 'wave', 'happy', talk=v > 28.6)
    end(c, v)
