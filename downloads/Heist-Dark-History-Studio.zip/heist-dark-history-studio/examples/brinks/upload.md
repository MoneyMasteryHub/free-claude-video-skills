# Upload kit (90-second preview of the Brink's Robbery)

**Titles**
1. They Stole $2.7 Million Without Firing a Shot (The Brink's Robbery)
2. The Brink's Robbery: 11 Men, 20 Minutes, and the Keys Nobody Noticed
3. How a Gang Copied Every Lock in Boston's Brink's Building

**Description**
On January 17, 1950, seven men in pea coats, chauffeur's caps and rubber Halloween masks walked into the Brink's building in Boston's North End and walked out about twenty minutes later with more than $2.7 million, over $1.2 million of it in cash. No shots, no tunnel, no safecracker: they had spent months copying the building's keys. The FBI chased them for six years. Then one of the gang talked.

Footage: "Your FBI" (FBI film, National Archives, RG 65, public domain). Photos: FBI (public domain); Tim Pierce, CC BY 3.0 (Wikimedia Commons). Animated scenes and newspaper are recreations.
Sources: Smithsonian Magazine; Boston Globe (Jan 18, 1950) and contemporary reports as summarized on Wikipedia; FBI history pages.

**Tags**
brinks robbery, great brinks robbery, heist documentary, biggest robbery, boston 1950, fbi history, true crime, how they stole, crime of the century, specs okeefe

**Thumbnail ideas**
1. The real chauffeur's cap on black, red stencil stamp "STILL MISSING".
2. Seven faceless figures in caps walking out of a lit door at night, text "NO GUNS".
3. A gold key on a blueprint, red stamp "$2.7 MILLION".
