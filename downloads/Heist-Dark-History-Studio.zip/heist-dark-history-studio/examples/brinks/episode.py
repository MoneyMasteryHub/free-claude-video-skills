"""The Brink's Robbery, Boston 1950. 90-second test in the documentary style.
Worlds: the desk (footage, newspaper, evidence, ledger, map) -> the blueprint (the plan, the heist rooms)
-> the FBI case board (the hunt) -> back to the desk (the confession, the deadline, the verdict, the money)."""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'engine'))
from board import *
from world import _once as once

D = os.path.dirname(os.path.abspath(__file__)); P = lambda *a: os.path.join(D, *a)
film = Film(__file__, vo='vo.wav', words='words.json', mood='noir')
T, E = film.cue, film.end
CH1, CH2 = film.chapter_at('THE PLAN'), film.chapter_at('THE HUNT')   # 2.2 s pauses in the voice for the chapter cards
FBI = 'FBI film "Your FBI" · National Archives'

desk = World(film, 'desk'); plan = World(film, 'blueprint'); case = World(film, 'board')
SPECS = dict(skin='#C9AE90', skin_d='#A88E72', suit='#2C2A28', suit_d='#1E1C1B', shirt='#CFC8B8', tie='#3A2622', hair='slick', hair_col='#1C1814', glasses=True)
HOOVER = dict(skin='#C9AE90', skin_d='#A88E72', suit='#24262C', suit_d='#18191D', shirt='#DCD6C8', tie='#4A1E22', hair='slick', hair_col='#1C1814')
JUDGE = dict(skin='#C9AE90', skin_d='#A88E72', suit='#121216', suit_d='#0A0A0D', shirt='#DCD6C8', tie='#121216', hair='bald', hair_col='#555555')

def sack(c, x, y, s=1.0, v='#6E6250'):
    c.save(); c.translate(x, y); c.scale(s, s)
    p = skia.Path(); p.moveTo(-40, 60); p.cubicTo(-58, 0, -40, -40, -14, -48); p.lineTo(14, -48); p.cubicTo(40, -40, 58, 0, 40, 60); p.close()
    shape(c, p, v, 4); c.drawLine(-16, -40, 16, -40, ink(6, '#3A3226')); c.restore()

# =============================================================== scenes (noir puppets)
def street_scene(c, t):
    sky(c, 'night'); facade(c, 'plain', mode='night', lit=(2, 1)); ground(c, 'street', mode='night')
    rect(c, 300, 560, 560, 880, '#1A1814', LW); c.drawRect(skia.Rect(310, 570, 550, 870), fp('#C9A86A', 120))
    street_lamp(c, 1250, 880, 330)
    t0 = T('seven men') - .3
    for i in range(7):
        ti = t0 + i * .5; u = K(t, ti, 6.0)
        if t < ti: continue
        x = lerp(430, 1900 + 120, u) - i * 0; y = 1010 + (i % 2) * 18
        spec = NOIR_GANG if i % 2 else NOIR_GANG2
        draw_char3(c, x, y, .62, spec, face=.8, eyes='dot', mouth='none', arms=('down', 'hold'), legs=walk_legs(t * 9 + i * 1.3))
        sack(c, x + 50, y - 120, .7); sack(c, x - 46, y - 100, .62)
    light(c, 'dark', [(430, 700, 420, .9), (1250, 360, 600, .95), (1250, 900, 380, .5)])

def locks_scene(c, t):
    office(c, 'inside', wall='#3E4660', window=False)
    rect(c, 980, 180, 1420, 900, '#4A3A2A', LW); rect(c, 1010, 210, 1390, 520, '#56442F', LW * .6); rect(c, 1010, 560, 1390, 870, '#56442F', LW * .6)
    a, b_, d = T('pulled out'), T('key cut'), T('put each lock back')
    out = ease(K(t, a + .2, .7)) * (1 - ease(K(t, d + .2, .7)))
    cx, cy = lerp(1060, 860, out), lerp(560, 600, out)
    rect(c, 1035, 530, 1085, 590, '#2A2A30', LW * .6); circ(c, cx, cy, 30, '#C9A64A', LW * .6); c.drawLine(cx - 4, cy - 14, cx + 4, cy + 14, ink(5))
    draw_char3(c, 700, 1000, 1.05, NOIR_GANG, face=.6, eyes='half', mouth='none', arms=('down', 'present'))
    if t >= b_:
        k = back(K(t, b_, .4), 1.6); c.save(); c.translate(640, 430); c.rotate(-10); c.scale(.5 * k, .5 * k)
        ring = skia.Path(); ring.addCircle(-170, 0, 95); ring.addCircle(-170, 0, 45); ring.setFillType(skia.PathFillType.kEvenOdd); shape(c, ring, '#C9A64A', 7)
        rect(c, -80, -22, 230, 22, '#C9A64A', 7); rect(c, 140, 10, 170, 52, '#C9A64A', 5); c.restore()
    light(c, 'dark', [(1000, 560, 520, .95), (700, 600, 380, .5)])

def room_scene(c, t):
    """Blueprint lines wipe away into the real counting room; the crew comes in, then leaves with the bags."""
    office(c, 'inside', wall='#3A3F4C', window=False)
    rect(c, 1240, 230, 1760, 880, '#4A4E58', LW); circ(c, 1500, 560, 190, '#6A6E78', LW); circ(c, 1500, 560, 52, '#3A3E48', LW * .6)
    for k in range(6): a = k * math.pi / 3; c.drawLine(1500 + 70 * math.cos(a), 560 + 70 * math.sin(a), 1500 + 160 * math.cos(a), 560 + 160 * math.sin(a), ink(6, '#2A2E36'))
    rect(c, 640, 760, 1120, 820, '#3A3026', LW); [sack(c, 700 + i * 90, 730, .7) for i in range(5) if t < T('they were gone') - .6]
    rect(c, 120, 300, 380, 900, '#2A241C', LW)
    tin = T('they went in') - .3; tout = T('they were gone') - 1.6
    for i, spec in enumerate((NOIR_GANG, NOIR_GANG2, NOIR_GANG)):
        ui = K(t, tin + i * .35, 2.2); uo = K(t, tout + i * .25, 1.8)
        if t < tin + i * .35: continue
        x = lerp(250, 560 + i * 230, ease(ui)); x = lerp(x, 150, ease(uo))
        if uo >= 1: continue
        draw_char3(c, x, 1060, 1.0, spec, face=(-.7 if uo > 0 else .5), eyes='dot', mouth='none', arms=('down', 'hold' if uo > 0 else 'down'), legs=walk_legs(t * 9 + i) if 0 < ui < 1 or 0 < uo < 1 else None)
        if uo > 0: sack(c, x - 60, 950, .9)
    light(c, 'dark', [(900, 520, 820, .95), (1500, 560, 420, .6)])
    # blueprint overlay wiping off to the right
    wp = ease(K(t, T('On January 17th') + .8, 1.6))
    if wp < 1:
        x0 = lerp(-300, W + 300, wp)
        c.save(); pth = skia.Path(); pth.moveTo(x0, 0); pth.lineTo(W + 400, 0); pth.lineTo(W + 400, H); pth.lineTo(x0 - 260, H); pth.close(); c.clipPath(pth)
        c.drawRect(skia.Rect(0, 0, W, H), fp('#0F2A4A'))
        for gx in range(0, W, 40): c.drawLine(gx, 0, gx, H, ink(1.2, '#163558'))
        for gy in range(0, H, 40): c.drawLine(0, gy, W, gy, ink(1.2, '#163558'))
        L = ink(5, '#CFE3F7'); c.drawRect(skia.Rect(100, 160, 1820, 940), L); c.drawRect(skia.Rect(1240, 230, 1760, 880), L)
        c.drawCircle(1500, 560, 190, L); c.drawRect(skia.Rect(640, 760, 1120, 820), L); c.drawRect(skia.Rect(120, 300, 380, 900), L)
        txt(c, 'COUNTING ROOM', 960, 230, 44, MONO, '#CFE3F7', 'center'); txt(c, 'VAULT', 1500, 840, 40, MONO, '#CFE3F7', 'center')
        c.restore(); c.drawLine(x0, 0, x0 - 260, H, ink(5, '#CFE3F7'))

def hoover_scene(c, t):
    office(c, 'inside', wall='#3E414A')
    draw_char3(c, 960, 1080, 1.15, HOOVER, face=-.2, eyes='half', mouth='flat', brow=-.3, arms=('hip', 'down'))
    light(c, 'dark', [(960, 500, 760, .95)])

def interro_scene(c, t):
    c.drawRect(skia.Rect(-100, -100, W + 100, H + 100), fp('#2A2D33')); c.drawRect(skia.Rect(-100, 760, W + 100, H + 100), fp('#1C1E22'))
    draw_char3(c, 700, 1120, 1.2, SPECS, face=.35, eyes='half', mouth='flat', brow=-.4, brow_tilt=.25, arms=('down', 'down'))
    rect(c, 300, 760, 1620, 840, '#3A3026', LW); rect(c, 360, 840, 400, 1080, '#3A3026', LW * .6); rect(c, 1520, 840, 1560, 1080, '#3A3026', LW * .6)
    c.drawLine(960, -100, 960, 160, ink(4, '#111111'))
    p = skia.Path(); p.moveTo(880, 220); p.lineTo(1040, 220); p.lineTo(1000, 160); p.lineTo(920, 160); p.close(); shape(c, p, '#2A2A2A', 4)
    c.save(); c.translate(1230, 735); c.rotate(-4); c.drawRect(skia.Rect(-250, -170, 250, 40), fp('#E6DECB'))
    txt(c, 'STATEMENT', -220, -125, 30, COURIER, '#222222')
    type_on(c, t, T('he talked'), 'I wish to state that...', -220, -70, 30, '#222222', ELITE, cps=14)
    c.restore()
    cash_u = 1 - .8 * ease(K(t, T('cheated') + .2, .8))
    c.save(); c.translate(1500, 735); c.scale(cash_u, cash_u)
    for k in range(3): tool(c, 'cash', 0, -k * 26, 0, 1.0)
    c.restore()
    light(c, 'dark', [(960, 700, 780, 1.0)], extra=[('path', cone_path(960, 220, 160, 1200, 900), .6, 40)])

def court_scene(c, t):
    hearing(c, seal=True)
    draw_char3(c, 960, 640, .7, JUDGE, face=0, eyes='half', mouth='flat')
    hearing_bench(c, mics=(960,))
    for i in range(8): draw_char3(c, 270 + i * 197, 1150, .62, NOIR_GANG if i % 2 else NOIR_GANG2, face=.9, eyes='dot', mouth='none')
    light(c, 'inside', [(960, 400, 700, .9)])

def suspect_draw(n):
    def draw(c, t, w, h):
        c.drawRect(skia.Rect(-w / 2 + 30, -h / 2 + 30, w / 2 - 30, h / 2 - 110), fp('#1E2026'))
        c.save(); c.clipRect(skia.Rect(-w / 2 + 30, -h / 2 + 30, w / 2 - 30, h / 2 - 110))
        draw_char3(c, 0, 330, .62, NOIR_GANG, face=0, eyes='dot', mouth='none'); c.restore()
        txt(c, f'SUSPECT {n}', 0, h / 2 - 50, 40, COURIER, '#222222', 'center')
    return draw

# =============================================================== WORLD 1: the desk
desk.item(0.0, 'clip', 'truck', 1000, 900, 1280, 720, src=P('clips/truck_night.mp4'), t_play=0.0, speed=.75, credit=FBI, fy=.45, pop=False)

def paper_draw(c, t, w, h):
    txt(c, 'EVENING EDITION', 0, -h / 2 + 150, 92, PLAYFAIR, '#151515', 'center')
    c.drawLine(-w / 2 + 50, -h / 2 + 185, w / 2 - 50, -h / 2 + 185, ink(5, '#222222')); c.drawLine(-w / 2 + 50, -h / 2 + 198, w / 2 - 50, -h / 2 + 198, ink(2, '#222222'))
    txt(c, "BRINK'S ROBBED", 0, -h / 2 + 400, 230, BEBAS, '#121212', 'center')
    txt(c, 'BIGGEST CASH HOLDUP IN U.S. HISTORY', 0, -h / 2 + 490, 62, OSWALD, '#222222', 'center')
    c.drawRect(skia.Rect(-680, -h / 2 + 520 + 0, 680, -h / 2 + 520 + 760), fp('#2A2A2A'))
    for k in range(6):
        for col_ in (-1, 0, 1):
            c.drawLine(col_ * 460 - 210, -h / 2 + 1330 + k * 38, col_ * 460 + 210 - (k % 2) * 60, -h / 2 + 1330 + k * 38, ink(7, '#8A8478'))
    txt(c, 'RECREATION', w / 2 - 60, h / 2 - 40, 30, MONO, '#7A7468', 'right')
    u = K(t, T('No one in America') + .9, .8)
    if u > 0:
        ring = skia.Path(); ring.addArc(skia.Rect(-640, -h / 2 + 430, 640, -h / 2 + 520), -170, 356 * ease(u)); c.drawPath(ring, ink(10, BLOOD))

desk.item(0.0, 'paper', 'paper', 2900, 1100, 1500, 1900, draw=paper_draw, pop=False, rot=1.5)
desk.item(0.0, 'scene', 'street', 2900 + 0, 150 + 520 + 380, 1360, 765, draw=street_scene, frame=False, pop=False, rot=1.5)

def rope_draw(c, t, w, h):
    c.drawRect(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), fp('#1E1F22'))
    for k in range(5): r = 120 - k * 20; c.drawCircle(-10 + k * 4, 10 - k * 3, r, ink(16, '#A89470')); c.drawCircle(-10 + k * 4, 10 - k * 3, r, ink(3, '#5A4C34'))
    txt(c, 'EXHIBIT 1  ·  ROPE', -w / 2 + 24, h / 2 - 24, 30, MONO, BONE)
def tape_draw(c, t, w, h):
    c.drawRect(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), fp('#1E1F22'))
    c.drawCircle(0, -10, 120, fp('#C9C0A2')); c.drawCircle(0, -10, 120, ink(5)); c.drawCircle(0, -10, 62, fp('#1E1F22')); c.drawCircle(0, -10, 62, ink(5))
    txt(c, 'EXHIBIT 2  ·  TAPE', -w / 2 + 24, h / 2 - 24, 30, MONO, BONE)
desk.item(T('a rope') - .2, 'paper', 'rope', 4350, 700, 560, 420, draw=rope_draw, rot=-3, pop=False)
desk.item(T('some tape'), 'paper', 'tape', 5000, 760, 560, 420, draw=tape_draw, rot=2.5)
desk.item(T("one chauffeur's") - .3, 'photo', 'cap', 4650, 1450, 1000, 562, src=P('media/cap.jpg'), pop=False, credit="EXHIBIT 3 · the cap left at the scene · Photo: FBI (public domain)", rot=-1.5)

def ledger_draw(c, t, w, h):
    txt(c, "BRINK'S, INC.  ·  BOSTON", -w / 2 + 60, -h / 2 + 90, 44, COURIER, '#222222')
    txt(c, 'Loss of January 17, 1950', -w / 2 + 60, -h / 2 + 140, 34, ELITE, '#333333')
    c.drawLine(-w / 2 + 60, -h / 2 + 170, w / 2 - 60, -h / 2 + 170, ink(3, '#555555'))
    rows = [(T('1 .2'), 'Cash', '$1,218,211.29'), (T('1 .2') + .6, 'Checks, money orders, securities', '$1,557,183.83'), (T('2 .7'), 'TOTAL', '$2,775,395.12')]
    for i, (t0, a, b_) in enumerate(rows):
        y = -h / 2 + 260 + i * 90 + (60 if i == 2 else 0)
        if i == 2: c.drawLine(-w / 2 + 60, y - 60, w / 2 - 60, y - 60, ink(3, '#555555'))
        type_on(c, t, t0, a, -w / 2 + 60, y, 36, '#222222', ELITE, cps=30)
        type_on(c, t, t0 + .3, b_, w / 2 - 60, y, 40 if i < 2 else 48, '#7A1A1E' if i == 0 else '#222222', COURIER, 'right', cps=30)
desk.item(T('taken about') - 1.0, 'paper', 'ledger', 6400, 1000, 1150, 640, draw=ledger_draw, rot=-1, pop=False)
desk.item(T('1 .2') + .2, 'clip', 'counting', 6450, 1880, 960, 540, src=P('clips/counting.mp4'), speed=.5, credit=FBI, rot=1.2)

def map_draw(c, t, w, h):
    c.drawRect(skia.Rect(-w / 2, -h / 2, w / 2, h / 2), fp('#D8CDB0'))
    water = skia.Path(); water.moveTo(-w / 2, -h / 2 + 200); water.cubicTo(-200, -h / 2 + 120, 200, -h / 2 + 400, w / 2, -h / 2 + 300); water.lineTo(w / 2, -h / 2); water.lineTo(-w / 2, -h / 2); water.close()
    c.drawPath(water, fp('#A9B6B8')); water2 = skia.Path(); water2.moveTo(w / 2 - 500, h / 2); water2.cubicTo(w / 2 - 300, 100, w / 2 - 100, 0, w / 2, -100); water2.lineTo(w / 2, h / 2); water2.close(); c.drawPath(water2, fp('#A9B6B8'))
    r = random.Random(5)
    for i in range(-10, 11): c.drawLine(i * 110 + r.uniform(-20, 20), -h / 2 + 250, i * 110 + 60 + r.uniform(-20, 20), h / 2, ink(3, '#B8AC8E'))
    for j in range(0, 12): c.drawLine(-w / 2, -h / 2 + 300 + j * 100, w / 2 - 400, -h / 2 + 330 + j * 100, ink(3, '#B8AC8E'))
    txt(c, 'BOSTON', -w / 2 + 80, h / 2 - 80, 90, BEBAS, '#4A4436')
    txt(c, 'BOSTON HARBOR', w / 2 - 80, -h / 2 + 90, 40, MONO, '#5E6A6C', 'right')
desk.item(T('No shots') - 1.2, 'paper', 'map', 2700, 3400, 2300, 1450, draw=map_draw, rot=-1, pop=False, shadow=True)
PIN = (2700 + 220 + 0, 3400 + 20)

# ---- the portal into the blueprint world, sitting on the pin
desk.item(T('They had keys') - .1, 'scene', 'plan_mini', PIN[0], PIN[1] + 100, 192, 108, draw=portal(plan), noir=False, vig=False, frame=False, shadow=False, pop=False)

@desk.layer
def map_pin(c, t):
    t0 = T('They had keys') - .1
    if t < t0: return
    fade = 1 - K(t, CH1 - .6, .5)
    if fade <= 0: return
    k = back(K(t, t0, .4), 1.6); c.save(); c.translate(PIN[0], PIN[1] - 20); c.scale(k, k)
    c.drawCircle(0, 0, 70, ink(8, BLOOD, 255 * fade)); c.drawCircle(0, 0, 22, fp(BLOOD, 255 * fade)); c.restore()
    txt(c, "BRINK'S BUILDING", PIN[0] + 120, PIN[1] - 6, 44, MONO, '#2A2418', a=min(1, (t - t0) * 3) * fade)

# ---- back on the desk later: confession, deadline, verdict, money
desk.item(T('Then one of the gang') - 1, 'scene', 'interro', 6300, 3300, 1280, 720, draw=interro_scene, credit=None)

def cal_draw(c, t, w, h):
    t0 = T('The arrests came')
    txt(c, 'STATUTE OF LIMITATIONS', -w / 2 + 40, -h / 2 + 60, 40, MONO, '#3A3428')
    txt(c, '1956', w / 2 - 40, -h / 2 + 60, 40, MONO, '#3A3428', 'right')
    for i, d in enumerate(range(12, 18)):
        x = -w / 2 + 150 + i * (w - 300) / 5; y = 40
        rect(c, x - 95, y - 110, x + 95, y + 110, '#FBFAF2', 4)
        c.drawRect(skia.Rect(x - 95, y - 110, x + 95, y - 60), fp('#6A1A20')); txt(c, 'JAN', x, y - 72, 34, MONO, BONE, 'center')
        txt(c, str(d), x, y + 66, 110, OSWALD, '#1A1A1A', 'center')
        if d == 12 and t >= t0 + .3: c.drawCircle(x, y + 20, 116, ink(10, BLOOD))
        if d == 17 and t >= t0 + 1.4: txt(c, 'TIME RUNS OUT', x, y + 160, 30, MONO, BLOOD, 'center')
    if t >= t0 + .3: txt(c, 'ARRESTS', -w / 2 + 150, h / 2 - 20, 32, MONO, BLOOD, 'center')
desk.item(T('The arrests came') - 2, 'paper', 'cal', 6200, 4500, 1500, 520, draw=cal_draw, rot=.8, bg='#E6DECB')
desk.item(T('Eight men') - 2, 'scene', 'court', 8050, 3600, 1280, 720, draw=court_scene)

def bars_draw(c, t, w, h):
    t0 = T('The money'); a = ease(K(t, t0 + .3, .8)); b_ = ease(K(t, T('less than') + .2, .6))
    x0 = -w / 2 + 80; full = w - 160
    txt(c, 'STOLEN IN CASH', x0, -125, 40, MONO, '#222222')
    if a > .01: c.drawRect(skia.Rect(x0, -100, x0 + full * a, -30), fp('#9C7A2E'))
    if a > .9: txt(c, '$1,218,211', x0 + full - 16, -45, 52, OSWALD, BONE, 'right')
    txt(c, 'EVER RECOVERED', x0, 70, 40, MONO, '#222222')
    if b_ > .01: c.drawRect(skia.Rect(x0, 95, x0 + max(full * .048 * b_, 2), 165), fp(BLOOD))
    if b_ > .5: txt(c, 'UNDER $60,000', x0 + full * .048 + 30, 150, 52, OSWALD, BLOOD)
desk.item(T('The money') - 2, 'paper', 'bars', 8000, 4700, 1700, 460, draw=bars_draw, rot=-1, bg='#E6DECB')

@desk.screen
def desk_overlays(c, t):
    place_tag(c, t, .5, 'BOSTON, MASSACHUSETTS', 'JANUARY 17, 1950  ·  7:30 PM', until=T('seven men') - .3)
    big(c, t, T('14 canvas') + .1, '14 CANVAS BAGS', W - 120, 170, 96, BONE, align='right', until=T('Behind them'))
    big(c, t, T('2 .7') + .2, '$2,775,395', W / 2, 200, 150, BONE, until=T('1 .2') - .2)
    # ruled out, over the map
    a = T('No shots'); b = T('They had keys') - .2
    if a <= t < b + .3:
        al = min(1, (t - a) * 3, (b + .3 - t) * 3)
        c.drawRect(skia.Rect(0, 0, W, H), fp((0, 0, 0), 120 * al))
        for ph, s_, y in (('No shots', 'SHOTS FIRED', 400), ('No tunnel', 'A TUNNEL', 560), ('No safecracker', 'A SAFECRACKER', 720)):
            t0 = T(ph)
            if t < t0: continue
            u = K(t, t0, .4); txt(c, s_, W / 2, y, 130, OSWALD, BONE, 'center', al * min(1, u * 3))
            w_ = tw(s_, 130, OSWALD); strike(c, t, t0 + .45, W / 2 - w_ / 2, y - 45, W / 2 + w_ / 2)
    big(c, t, T('They had keys'), 'THEY HAD KEYS.', W / 2, H - 130, 130, AMBER, until=CH1 - .2)
    name_tag(c, t, T("O 'Keefe") + .2, "JOSEPH 'SPECS' O'KEEFE", 'GANG MEMBER', until=T('cheated') + 1.0)
    big(c, t, T('cheated') + .3, 'SHORT-CHANGED ON HIS SHARE', W / 2, 180, 84, BONE, until=T('Someone tried') - .1)
    big(c, t, T('Someone tried'), '1954: SHOT. HE SURVIVED.', W / 2, 180, 84, BONE, until=T('he talked') - .1)
    place_tag(c, t, T('he talked'), 'JANUARY 1956', 'HE TALKS TO THE FBI', until=T('The arrests came') + .4)
    big(c, t, T('five days') + .2, '5 DAYS LEFT', W / 2, 200, 130, AMBER, until=T('Eight men') - .3)
    if T('got life') <= t < T('The money') + .2: stamp2(c, t, T('got life') + .1, 'LIFE', W / 2 + 470, 380, -8, 200)
    a = T('and over a million')
    if t >= a:
        al = min(1, (t - a) * 2.5)
        c.drawRect(skia.Rect(0, H - 280, W, H), fp((0, 0, 0), 180 * al, blur=30))
        txt(c, 'STILL MISSING', W / 2, H - 170, 44, MONO, ASH, 'center', al, track=8)
        big(c, t, a + .4, 'OVER $1,000,000 IN CASH', W / 2, H - 70, 100, AMBER)

# =============================================================== WORLD 2: the blueprint
L = lambda w=5: ink(w, '#CFE3F7')
@plan.under
def floorplan(c, t):
    c.drawRect(skia.Rect(500, 380, 2500, 1620), L(6))
    for r_ in [(500, 380, 1100, 900), (1100, 380, 1900, 900), (1900, 380, 2500, 1620), (500, 900, 1900, 1620)]: c.drawRect(skia.Rect(*r_), L())
    txt(c, 'STAIRS', 800, 660, 36, MONO, '#CFE3F7', 'center'); txt(c, 'COUNTING ROOM', 1500, 560, 36, MONO, '#CFE3F7', 'center')
    txt(c, 'VAULT', 2200, 1000, 40, MONO, '#CFE3F7', 'center'); txt(c, 'GARAGE', 1100, 1300, 44, MONO, '#CFE3F7', 'center')
    txt(c, "BRINK'S, INC.  ·  SECOND FLOOR  ·  RECREATION", 500, 340, 30, MONO, '#9FC0E3')
    locks = [(800, 900), (1100, 640), (1500, 900), (1900, 640), (1900, 1100)]
    t0 = T('pulled out')
    for i, (x, y) in enumerate(locks):
        ti = t0 + i * .5
        if t < ti: continue
        g = .6 + .4 * math.sin((t - ti) * 4) ** 2
        c.drawCircle(x, y, 70, sp(radial(x, y, 70, [hx(AMBER, int(190 * g)), hx(AMBER, 0)]))); circ(c, x, y, 13, AMBER, 3)
    # practice route, drawn and called off five times
    route = [(560, 1580), (800, 900), (1100, 640), (1500, 640), (1900, 640), (2200, 900)]
    tp = T('Five times')
    for i in range(5):
        ti = tp + i * .42
        if t < ti - .3: continue
        u = min(1, (t - ti + .3) / .35); p = skia.Path(); p.moveTo(*route[0]); n = len(route) - 1; m = u * n
        for j in range(1, n + 1):
            if j <= m: p.lineTo(*route[j])
            else:
                a_, b_ = route[j - 1], route[j]; f_ = m - (j - 1); p.lineTo(lerp(a_[0], b_[0], f_), lerp(a_[1], b_[1], f_)); break
        if i == 4 or t < ti + .4:
            pa = ink(7, BLOOD); pa.setPathEffect(skia.DashPathEffect.Make([26, 18], 0)); c.drawPath(p, pa)
    for i in range(5):
        y = 470 + i * 110; ti = tp + i * .42
        if t < T('practiced'): continue
        txt(c, f'RUN {i + 1}', 2620, y, 44, MONO, '#CFE3F7')
        if t >= ti: strike(c, t, ti + .2, 2620, y - 14, 2620 + tw(f'RUN {i + 1}', 44), BLOOD, 6); txt(c, 'CALLED OFF', 2800, y, 30, MONO, BLOOD, a=min(1, (t - ti) * 3))

plan.item(T('the gang pulled') - .4, 'scene', 'locks', 1000, 1250, 768, 432, draw=locks_scene, title='FOR MONTHS')
@plan.layer
def lock_steps(c, t):
    stamp2(c, t, T('Nobody noticed'), 'NOBODY NOTICED', 1500, 1500, -6, 90)
    for t0, s_, y in ((T('pulled out') + .3, '1  PULL THE LOCK', 1080), (T('key cut'), '2  CUT A KEY', 1180), (T('put each lock back'), '3  PUT IT BACK', 1280)):
        if t >= t0: txt(c, s_, 1450, y, 64, OSWALD, BONE, a=min(1, (t - t0) * 3))
plan.item(T('On January 17th') - .8, 'scene', 'room', 1500, 640, 480, 270, draw=room_scene, frame=False)
plan.item(T('Twenty minutes') - .6, 'clip', 'cart', 2900, 1300, 640, 360, src=P('clips/cash_cart.mp4'), t_play=T('Twenty minutes') + .2, speed=.6, credit=FBI, pop=False)

@plan.screen
def plan_overlays(c, t):
    place_tag(c, t, T('On January 17th'), 'BRINK\'S, INC.  ·  NORTH END', 'JANUARY 17, 1950  ·  7:10 PM', until=T('they went in') - .3)
    for t0, s_, y in ((T('pea'), 'PEA COATS', 150), (T("chauffeur's", 2), "CHAUFFEUR'S CAPS", 250), (T('rubber'), 'RUBBER HALLOWEEN MASKS', 350)):
        if t0 <= t < T('Twenty minutes') - .2: txt(c, s_, 110, y, 74, OSWALD, BONE, a=min(1, (t - t0) * 3, (T('Twenty minutes') - .2 - t) * 4))
    clock_line(c, t, T('they went in') - .2, T('Twenty minutes') - .3, 10, 30, until=T('Twenty minutes') + .25)

# =============================================================== WORLD 3: the FBI case board
case.item(0, 'clip', 'cart', 1500, 1300, 960, 540, src=P('clips/cash_cart.mp4'), t_play=T('Twenty minutes') + .2, speed=.6, credit=FBI, pop=False, pin=True)
for i, (x, y) in enumerate(((2600, 900), (3100, 860), (2620, 1560), (3120, 1600))):
    case.item(T('The FBI chased') + .4 + i * .25, 'paper', f'sus{i}', x, y, 400, 520, draw=suspect_draw('ABCD'[i]), rot=(-3, 2, 2, -2)[i], pin=True)

def years_draw(c, t, w, h):
    t0 = T('The FBI chased'); u = ease(K(t, t0 + .5, 5.5))
    c.drawLine(-w / 2 + 120, 20, w / 2 - 120, 20, ink(6, '#222222'))
    for i, yv in enumerate(range(1950, 1957)):
        x = lerp(-w / 2 + 120, w / 2 - 120, i / 6); c.drawLine(x, 0, x, 40, ink(5, '#222222')); txt(c, str(yv), x, -30, 50, OSWALD, '#222222', 'center')
    xm = lerp(-w / 2 + 120, w / 2 - 120, u); c.drawLine(-w / 2 + 120, 20, xm, 20, ink(12, BLOOD)); circ(c, xm, 20, 18, BLOOD, 3)
case.item(T('The FBI chased') + .2, 'paper', 'years', 2300, 2450, 2200, 300, draw=years_draw, rot=-.5, pin=True)
case.item(T('Edgar Hoover') - .5, 'scene', 'hoover', 4300, 1150, 960, 540, draw=hoover_scene, pin=True, rot=1.2)
case.item(T('Then one of the gang') - .2, 'scene', 'specs', 4200, 2300, 960, 540, draw=interro_scene, pin=True, title="SUSPECT: GANG MEMBER", title_size=50)

@case.layer
def case_strings(c, t):
    string(c, t, T('The FBI chased') + 1.4, 1500, 1010, 2600, 620)
    string(c, t, T('The FBI chased') + 1.8, 2600, 620, 3100, 580)
    string(c, t, T('Edgar Hoover') + .2, 3100, 580, 4300, 860)
    string(c, t, T('Then one of the gang') + .3, 3120, 1320, 4200, 2010)
    stamp2(c, t, T('Nothing'), 'NO ARRESTS', 2300, 2480, -6, 110)

@case.screen
def case_overlays(c, t):
    name_tag(c, t, T('Edgar Hoover') + .3, 'J. EDGAR HOOVER', 'FBI DIRECTOR · TOOK CHARGE OF THE CASE', until=T('Nothing') - .2)

# =============================================================== camera paths
# One continuous camera inside each world; worlds connect through matching items (seamless).
# desk, part 1
desk.dive(0.0, 'truck', move=.5, drift=.006)
desk.dive(T('seven men') + .1, 'street', move=1.3, dip=.12, drift=.006)
desk.cam(T('Behind them') + .9, 4650, 1050, .56, move=1.6, dip=0)
desk.frame_box(T("chauffeur's") + 1.0, 'cap', move=1.0, pad=1.2, dip=.04)
desk.cam(T('taken about') + .5, 6400, 1000, .95, move=1.3)
desk.cam(T('1 .2') + .6, 6420, 1500, .68, move=1.1, dip=0)
desk.cam(T('No one in America') + .6, 2900, 620, .78, move=1.6)
desk.cam(T('No shots') + .1, 2700, 3400, .62, move=1.5)
desk.cam(T('They had keys') + .2, PIN[0], PIN[1] + 60, 1.6, move=.9, dip=0)
desk.dive(CH1 + .3, 'plan_mini', move=1.4)
SW1 = CH1 + .35
# blueprint
plan.cam(0, 1500, 1000, 1.0, move=.1, drift=0)
plan.cam(SW1, 1500, 1000, 1.0, move=.1, drift=0)
plan.cam(T('the gang pulled') + .2, 1320, 1180, 1.2, move=1.2, dip=.06)
plan.cam(T('Nobody noticed') - .2, 1500, 1050, .78, move=1.0, dip=0)
plan.cam(T('Then they practiced') + .5, 1700, 1000, .72, move=1.0, dip=0)
plan.dive(T('On January 17th') + .1, 'room', move=1.6)
plan.dive(T('Twenty minutes') + .5, 'cart', move=1.2, dip=.12)
SW2 = T('Twenty minutes') + .6
# case board
case.dive(0, 'cart')
case.dive(SW2, 'cart', move=.05)
case.cam(CH2 + 2.0, 2500, 1500, .5, move=1.6, dip=0)
case.frame_box(T('Edgar Hoover') + .2, 'hoover', move=1.1, pad=1.25, dip=.05)
case.cam(T('Nothing') + .05, 2300, 2380, .62, move=.9, dip=0)
case.dive(T("O 'Keefe") + .3, 'specs', move=1.5, dip=.08)
SW3 = T("O 'Keefe") + .4
# desk, part 2
desk.dive(SW3, 'interro', move=.05)
desk.cam(T('The arrests came') + .5, 6200, 4350, .7, move=1.4)
desk.dive(T('Eight men') + .3, 'court', move=1.1, dip=.08, drift=.006)
desk.frame_box(T('less than') + .1, 'bars', move=1.3, pad=1.12, dip=.08)
desk.cam(T('14 bags') + .6, 5000, 2600, .21, move=1.4, dip=0)
desk.frame_box(T('one cap') + .9, 'cap', move=1.6, pad=1.08, dip=0)

film.music = dict(
    pulse=[(T('For months') - 1, T('On January 17th')), (T('The arrests came') - .5, T('Eight men') + .8)],
    ticks=[(T('On January 17th'), SW2)],
    hits=[T('They had keys'), T('Nothing'), T('got life') + .1],
    drops=[(T('Nothing') - .1, T('Nothing') + .9), (SW3, T('The arrests came') - .3)])

Reel(film, [(0, desk), (SW1, plan), (SW2, case), (SW3, desk)]).render_chunks(8)
film.main()
