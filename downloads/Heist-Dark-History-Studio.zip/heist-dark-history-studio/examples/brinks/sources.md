# Brink's Robbery (Boston, 17 Jan 1950) - sources

Facts
- Entered 7:10 pm, left about 7:30 pm, about 20 minutes inside: Wikipedia "Great Brink's Robbery" (citing Boston Globe 18 Jan 1950; HISTORY.com; News & Observer 1960)
- $1,218,211.29 cash + $1,557,183.83 checks, money orders, securities (about $2.7M total): Smithsonian Magazine, Jan 2025 ("On this day in 1950..."); Wikipedia
- Largest cash robbery in US history at the time: Smithsonian
- Seven men went in; 11 involved in all: Smithsonian; Wikipedia
- Pea coats, gloves, chauffeur's caps, Halloween masks: Smithsonian; Wikipedia (Boston Globe)
- Locks removed one by one, key made, lock put back: Smithsonian; Wikipedia (FBI)
- Five aborted runs before 17 Jan: Wikipedia (St. Louis Post-Dispatch 1961)
- About 14 canvas bags: Wikipedia (HISTORY.com)
- Only rope, tape and a chauffeur's cap left at the scene: Smithsonian
- Hoover took over supervision: Wikipedia
- O'Keefe short-changed, survived a 1954 attempt on his life, confessed Jan 1956: Smithsonian
- Arrests 12 Jan 1956, five days before the statute of limitations ran out: Wikipedia
- Eight convicted, life sentences: Smithsonian; Wikipedia
- Less than $60,000 recovered (about $58,000): Wikipedia
- More than $1 million never accounted for: Smithsonian

Media (all free to use)
- FBI film "Your FBI" (National Archives NAID 12173, RG 65, federal government work), clips at 3:40-3:54: truck at night, counting, count room, cash cart. Credit: "FBI / National Archives"
- Chauffeur's cap photo: FBI via Wikimedia Commons, public domain. Credit: "FBI"
- North Terminal Garage photo: Tim Pierce, CC BY 3.0, Wikimedia Commons. Credit: "Photo: Tim Pierce, CC BY 3.0"

Named people: Pino and O'Keefe were convicted / pleaded guilty, so naming them is fine.
