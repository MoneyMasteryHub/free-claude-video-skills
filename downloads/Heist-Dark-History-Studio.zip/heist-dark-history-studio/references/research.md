# Finding topics people want

1. **Look at what is working right now.** Search YouTube (web search, or the user's browser if connected) for terms like "heist documentary", "biggest robbery", "how they stole", "dark history", "con man", "cover up", "unsolved", filtered to this month and sorted by views. Note videos that beat their channel's size (a channel with 10K subscribers getting 500K+ views). Those topics and angles have proven demand.
2. **Check the news.** Recent heists, frauds, art thefts, crypto hacks, prison escapes, and anniversaries of famous cases ("one year after…") give a "why now".
3. **Evergreen lists.** Famous heists (Antwerp diamonds 2003, Lufthansa 1978, Gardner Museum 1990, Great Train Robbery 1963, D.B. Cooper 1971), great cons (the man who sold the Eiffel Tower, Anna Sorokin, Frank Abagnale's claims vs the record), dark history (Radium Girls, the Dancing Plague of 1518, Typhoid Mary, the Great Stink, body snatchers).
4. **For every idea give:** title (bold, true), the one-line hook, why now or "evergreen", the demand proof you actually saw (title, channel size, views, age), the legal risk (low / medium / skip), and whether it fits Heist or Dark story.
5. **Prefer** stories with a clear timeline, a surprising ordinary method, a mistake, and an open question at the end. **Avoid** stories whose main draw is a living victim's suffering or that would need naming unconvicted people.

Never make up view counts, trends or search volumes. If you couldn't check, say "unverified".
