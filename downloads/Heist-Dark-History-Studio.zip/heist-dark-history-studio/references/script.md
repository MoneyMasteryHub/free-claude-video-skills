# Script formulas

Built from transcripts of videos that beat their own channel by 10x or more in 2025 and 2026 (a 2.5M-view heist explainer on a channel with 8K subscribers, a 1.4M-view dark-history long-form, multi-million "complete history" videos). Reuse the techniques, never anyone's wording.

## What made the biggest one win: precision
The weaker heist video used adjectives as proof ("impregnable fortress", "the unthinkable happened"). The 2.5M one used exact details with a named source: "93 cents", "3 minutes and 24 seconds", "4:20 and 59 seconds", "17 of them hold exactly 1,000 bitcoin". Precise, sourced detail is what makes people trust it and keep watching. Every claim gets a source; every number is exact or says "about".

## Mode A: Heist (8 to 15 minutes, ~150 words a minute)
1. **Cold open on a contrast between a tiny detail and a huge number.** "At 9:38 a camera zoomed in. By then, the room was empty." / "Someone paid 93 cents… 6.3 billion dollars was gone."
2. **Rule out what the viewer expects.** "No guns. No lasers. No tunnel." Then the real, ordinary method ("a furniture lift").
3. **Open a loop.** The first official story, then "that wasn't the whole story" or "catching them was the easy part".
4. **Promise three things** in one sentence: how it happened, who did it, the part nobody has answered.
5. **Teach one idea with an everyday comparison and plant it without announcing it.** ("A camera doesn't stop anything. A person watching it does.") It pays off later on its own. Never write "remember that".
6. **Backstory in about 30 seconds.** Only what makes the target matter. Cut visitor statistics and side history; get to the preparation fast.
7. **The preparation, with dates.** Days before: the fake appointment, the stolen vehicle, the rehearsal.
8. **The heist minute by minute.** Clock times drive the pace. Move with the questions the viewer is already asking ("Why a furniture lift?"), answered straight away.
9. **The moment it should have ended, and didn't.** The alarm, the pause, the 30 seconds.
10. **Why nobody stopped it.** The failures, each with its source. Old warnings are context, never presented as the cause unless a source says so.
11. **The mistakes.** What they dropped, left, or got wrong. "A helmet holds DNA."
12. **The race and the arrests.** Named, timestamped reactions. Suspects are never named unless convicted (see legal.md).
13. **The question still open.** Who they worked for, where the money or jewels are. Use named experts and say what is uncertain.
14. **The irony.** One line that flips the story ("The only piece France got back is the one they dropped").
15. **End on a callback to the opening** in three short fragments ("A furniture lift. Four minutes. A camera that zoomed in too late."). No generic channel line after it.

## Mode B: Dark story (12 to 30 minutes)
1. **Open inside the place or the moment** with a sensory detail and the belief everyone held ("The locals won't go near it, not even in daylight").
2. **Name the stakes** in one line and promise the full story, start to finish.
3. **Go back to the beginning** and move forward in chapters (eras, generations, attempts). Each chapter opens with a question and escalates.
4. **Evidence comes from real documents with dates:** letters, court records, ledgers, newspapers. Quote them briefly and say who wrote them. Never invent a document, a diary or a quote; if a detail is legend, say "according to local legend".
5. **One recurring motif** (a sound, an object, a phrase) that returns in every chapter.
6. **The turn:** the moment outsiders finally act, or the truth comes out.
7. **Where it stands now** and what is still unknown.
8. **Close on the opening image**, changed by everything the viewer now knows.

## Chapter cards (a pause in the voice)
Every act change gets a chapter card, and the narrator stops for it: put a line of its own in the script, between paragraphs:

    [CHAPTER: PART ONE | THE PLAN]

The free voice turns it into a 2.2-second silence and saves its time in `chapters.json`; the film shows the card in that silence (with a deep hit in the score), then the voice carries on. Nothing is said over a chapter card.
- Titles: 2 or 3 words, a noun phrase ("THE PLAN", "THE NIGHT", "THE HUNT", "THE CONFESSION", "THE MISSING MILLION").
- How many: one every 2 to 3 minutes in a full film (a 10-minute film has 4 or 5); a 90-second preview has 1 or 2.
- If the user records their own voice (ElevenLabs), tell them to add a 2-second pause at each marker (in ElevenLabs: `<break time="2s" />`); the engine finds the pauses and matches them to the markers in order.

## Lines
- Second person or plain narration; present tense for scenes. Short spoken sentences; fragments are fine.
- Every number gets an everyday comparison or a scale ("about four times the old record").
- One light joke after each heavy beat (about every 60 to 90 seconds), and every joke names its visual gag in your notes (e.g. "map pin drops on a town literally called LOUVRES").
- Questions are the transitions. Avoid "next", "now let's", "remember that", "sit with that", "here's the twist": the writing should create the effect without pointing at it.
- No tangents in the final third: once the emotional peak lands, every line narrows toward the ending.
- Say uncertainty out loud ("reportedly", "investigators haven't said", "they say there was a ringleader; investigators are sceptical").
- Write times and numbers the way they're spoken ("nine thirty-four", "eighty-eight million euros").
- No em dashes, no "not just X but Y", no filler. Run the humanizer.
- Optional call to action: one short line after the first big payoff ("If this is the kind of story you like, like the video so YouTube shows you more"), never at the very end.

## Timing map for 10 minutes (heist)
0:00 cold open · 0:45 promise · 1:00 the idea · 1:20 backstory · 1:50 preparation · 2:20 the heist minute by minute · 4:00 why nobody stopped it · 5:10 mistakes · 6:00 arrests · 7:00 the open question · 8:20 fallout and irony · 9:30 callback ending.
