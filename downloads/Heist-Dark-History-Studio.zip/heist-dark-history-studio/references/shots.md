# Puppets, sets and props (and the older shot-by-shot mode)

Episodes are written with worlds (references/board.md, examples/brinks/episode.py). This page is the reference for what goes inside scenes: puppets, sets, props. The `film.shot` mode below (one scene per shot, cut between them) still works for cut-heavy edits.

```python
import sys, os; sys.path.insert(0, '/path/to/heist-dark-history-studio/engine')
from film import *
from world import _once as once            # once('alarm', t, T('alarm goes')) logs a one-off sound effect
film = Film(__file__, vo='vo.mp3', words='words.json', mood='heist')   # mood: heist | dark | mystery
T, E = film.cue, film.end                  # T('phrase') = when it starts; E('phrase') = when it ends; T('x', 2) 2nd time; T('x', after=t)

@film.shot(T('The museum opens'), push=(1.0, 1.06), focus=(960, 540))
def opens(c, t, cam):                      # c = canvas in world space (1920x1080 frame), t = seconds into the film
    sky(c, 'morning'); facade(c, 'museum', mode='morning'); ground(c, 'square')
    draw_char3(c, 900, 1000, .6, civilian(3))
    light(c, 'morning', [(960, 500, 800, .5)])                     # lighting goes after the set and characters
    cam.over(lambda c: tag(c, t, T('The museum opens'), 'OPENING TIME · 09:00'))   # screen-space graphics

film.main()
```
A shot runs until the next shot starts. Options: `push=(z0, z1)` slow zoom · `focus=(x, y)` zoom centre · `rot=(r0, r1)` degrees · `camera=fn(t, u)->(zoom, fx, fy, rot)` · `shake=[t, ...]` · `whip=False` · `card=True` (black card, music cuts, low boom) · `cctv=dict(cam='CAM 14', clock=fn(t)->str, zoom=fn(t)->str)` turns the frame into grainy security footage · `vig` · `bloom` · `end=`.

Cue on **words, not digits** (`T('nine thirty-four')` may be transcribed "9.34"); check `words.json` printouts when a cue fails. When the user re-records the voice, only `words.json` changes.

## Characters
`draw_char3(c, x, y, s, spec, face=0, eyes='dot', mouth='smile', brow=0, brow_tilt=0, arms=('down','down'), tilt=0, bob=0, squash=0, sweat=-1, light=-1, legs=None, pupil=0, sparkle=0)`
- x, y = feet. s = 1 is a full-height character about 520 px tall; .5 to .7 for wide shots, 1.2 to 1.6 for close-ups (feet below the frame).
- face -1..1 turns 3/4 left/right. eyes: dot, half (smug), wide (shocked), closed. mouth: smile, smirk, flat, o, mid, open, none.
- arms: down, pocket, hip, present, gesture, chin, hat, hold, push; blend with `('down', 'push', K(t, t0, .3))` for a snappy pose change.
- walking: `legs=walk_legs(t * 11)` and move x with `lerp`.
- spec keys: skin, skin_d, suit, suit_d, shirt, tie, bowtie, hair (slick, bald, bob, long, bun, curly), hair_col, glasses, moustache, vest (hi-vis colour), stripes, badge, lanyard, mask (balaclava colour), hat (cap, helmet, beanie, hardhat, judge, top), hat_col, cap_badge.
- `civilian(seed, **overrides)` makes a varied passer-by. Make every film's cast original; real people are generic puppets plus a `lower_third` name tag.

## Sets (world.py)
`sky(c, mode)` · `far_city(c, base, mode)` · `facade(c, 'museum'|'bank'|'plain', lit=(col,row), mode)` returns window centres `g[(col,row)]` · `ground(c, 'street'|'quay'|'square')` · `street_lamp` · `gallery(c)` palace hall · `display_case(c, x, y, w, items, broken, gone)` · `control_room(c, screens, live, t, feed)` · `office(c)` · `airport(c, board)` · `hearing(c)` + `hearing_bench(c)` (draw people between) · `table(c)` top-down desk · `map_city(c, t, pins, route, u)` · `garage(c, open_u)` · `vault_door(c, x, y, r, u)`.
Modes for `light()` / sets: day, morning, dusk, night, inside, dark.

## Props
`truck_lift(c, x, y, ext, target)` returns the basket position, then `lift_basket_front(c, bx, by)` after the riders · `scooter(c, x, y, s, rider)` · `sofa` · `barrier` · `jewel(c, kind, x, y, s)` (tiara, necklace, earring, earrings, brooch, bow, crown, diamond, ring) · `tool(c, kind, x, y, rot, s)` (cutter, torch, helmet, vest, walkie, gloves, phone, passport, cuffs, cash, bag) · `newspaper(c, x, y, rot, masthead, headline, sub, circle_u)` · `document(c, x, y, rot, title, sub, lines, stamp_txt, stamp_u, highlight=(line, text))` · `screen_post(c, x, y, w, h, title, body)` · `evidence_tag(c, x, y, n, text, u)` · `sparks(c, x, y, t)`.

## Screen graphics (inside `cam.over(lambda c: ...)`; each logs its own sound effect)
`poplabel(c, t, t0, text, x, y, size, colour, rot)` · `stamp(c, t, t0, text, x, y, rot, size, colour)` · `tag(c, t, t0, text)` location/time lower left · `lower_third(c, t, t0, name, role)` · `clock_bar(c, now, a, b, marks)` heist timeline (seconds of the day; `hms()` formats) · `counter(c, t, t0, dur, value, x, y, prefix, suffix, label_txt=)` · `marker_circle(c, t, t0, x, y, rx, ry)` · `arrow(c, t, t0, x0, y0, x1, y1)` · `icon_row(c, t, t0, items, title=)` items pop in one by one with a running count · `timer_bars(c, t, t0, rows)` · `photo(c, t, t0, path, x, y, w, credit, caption)` real photo in a white frame · `card(c, t, t0, text, dur)` (in a `card=True` shot) · `polaroid(c, t, t0, draw_fn, line, ring)` ending.
Colours: LIME, CREAM, GOLD, RED. A label ending in " ✓" or " ✗" draws a tick or cross.

## Rules of thumb
- One idea per shot; hold the stage and build inside it. A new element every 1.5 to 3 s.
- Heists: show the clock (`clock_bar`) whenever the narration gives a time; CCTV look for the opening and its callback.
- Labels short (2 to 5 words), never more than 3 on screen at once. Keep text inside x 80..1840 and y 80..1000.
- Real objects or places that matter: a `photo` with credit beats a drawing.
- Check `stills` before rendering, every time.
