"""Setup check: draws one frame with every kind of element and saves selftest.png next to this file."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from world import *
surf = skia.Surface(W, H); c = surf.getCanvas()
sky(c, 'morning'); g = facade(c, 'museum', lit=(6, 0), mode='morning'); ground(c, 'quay')
wx, wy = g[(6, 0)]; bx, by = truck_lift(c, 1400, 880, 1.0, (wx - 80, wy + 130))
draw_char3(c, bx + 40, by + 40, .5, dict(skin='#D9A77A', skin_d='#B9875C', suit='#2B2B33', suit_d='#1E1E25', shirt='#2B2B33', tie='#2B2B33', vest='#E8C21A', hat='beanie', mask='#1E1E25'))
lift_basket_front(c, bx, by); light(c, 'morning', [(wx, wy, 330, .9)])
finish(surf); vignette(c); stamp(c, 1, 0, 'IT WORKS', 960, 300); tag(c, 1, 0, 'SETUP CHECK')
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'selftest.png'); surf.makeImageSnapshot().save(out); print('ok', os.path.abspath(out))
