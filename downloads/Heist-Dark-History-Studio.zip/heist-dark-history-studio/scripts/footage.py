"""Real archive footage, free to use: find it, download it, find the right seconds, cut clips.

usage:
  python3 scripts/footage.py search "brinks robbery 1950"        Internet Archive films marked public domain / no known copyright
  python3 scripts/footage.py get IDENTIFIER src/                  download the main video file of an Internet Archive item
  python3 scripts/footage.py scan src/film.mp4 "brink" "boston"   transcribe the film and print where the words are said,
                                                                  plus a contact sheet of frames around each hit (src/film_scan_*.jpg)
  python3 scripts/footage.py sheet src/film.mp4 210 30            frames from 210 s for 30 s, one per second, in one sheet
  python3 scripts/footage.py cuts src/film.mp4 217 20             scene cuts between 217 s and 237 s (to cut clean clips)
  python3 scripts/footage.py clip src/film.mp4 220.6 226.5 clips/truck.mp4

Rights, in short (read references/legal.md):
  OK   US federal government films and photos (FBI, NASA, military, National Archives items with "Use: Unrestricted"),
       Internet Archive items marked Public Domain Mark / CC0 / "no known copyright".
  NO   commercial newsreels marked restricted (Paramount, Fox Movietone, Pathe), TV news, anything you are unsure of.
National Archives (catalog.archives.gov) is often blocked for scripts: search it in the user's browser, check the
"Use" field on the item page, and download the file through the browser into src/.
"""
import sys, os, json, subprocess, urllib.request, urllib.parse, shutil

FF = os.environ.get('FFMPEG') or shutil.which('ffmpeg') or 'ffmpeg'
UA = {'User-Agent': 'heist-dark-history-studio/1.0'}


def fetch(url):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60).read()


def search(q):
    query = (f'(title:({q}) OR subject:({q}) OR description:({q})) AND mediatype:(movies) AND '
             '(licenseurl:*publicdomain* OR licenseurl:*zero* OR collection:(prelinger OR fedflix OR universal_newsreels OR '
             'gov.archives.arc.films OR nasa OR militaryfilms))')
    url = 'https://archive.org/advancedsearch.php?' + urllib.parse.urlencode(
        {'q': query, 'fl[]': ['identifier', 'title', 'year', 'licenseurl', 'rights', 'collection'], 'sort[]': 'downloads desc', 'rows': 30, 'output': 'json'}, doseq=True)
    try: docs = json.loads(fetch(url))['response']['docs']
    except Exception as e: sys.exit(f'Internet Archive could not be reached ({e}). Search https://archive.org in the browser instead.')
    for d in docs:
        lic = (d.get('licenseurl') or '') + ' ' + str(d.get('rights') or '')
        coll = ' '.join(d.get('collection') or []) if isinstance(d.get('collection'), list) else str(d.get('collection') or '')
        free = any(k in (lic + ' ' + coll).lower() for k in ('publicdomain', 'public domain', 'zero', 'no known copyright', 'prelinger', 'fedflix', 'universal_newsreels', 'gov.archives'))
        print(f"{'FREE ' if free else 'check'}  {d['identifier']:45s} {str(d.get('year', ''))[:4]:5s} {d.get('title', '')[:80]}")
    print('\nFREE = marked public domain on the item. "check" = open https://archive.org/details/<id> and read the rights before using.')


def get(ident, out):
    os.makedirs(out, exist_ok=True)
    meta = json.loads(fetch(f'https://archive.org/metadata/{ident}'))
    files = [f for f in meta.get('files', []) if f.get('name', '').lower().endswith(('.mp4', '.mpeg', '.mpg', '.ogv', '.avi', '.mov', '.wmv'))]
    if not files: sys.exit('no video file in this item')
    files.sort(key=lambda f: (not f['name'].lower().endswith('.mp4'), -int(f.get('size', 0) or 0)))
    f = files[0]; dst = os.path.join(out, os.path.basename(f['name']))
    print('downloading', f['name'], f"({int(f.get('size', 0) or 0) / 1e6:.0f} MB)")
    with open(dst, 'wb') as fh: fh.write(fetch(f'https://archive.org/download/{ident}/{urllib.parse.quote(f["name"])}'))
    print('saved', dst, '\nlicence:', meta.get('metadata', {}).get('licenseurl') or meta.get('metadata', {}).get('rights') or 'not stated, check the item page')


def to_mp4(src):
    if src.lower().endswith('.mp4'): return src
    out = os.path.splitext(src)[0] + '.mp4'
    if not os.path.exists(out):
        subprocess.run([FF, '-v', 'error', '-y', '-i', src, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-c:a', 'aac', out], check=True)
    return out


def sheet(src, start, dur, out=None, cols=6):
    src = to_mp4(src); out = out or os.path.splitext(src)[0] + f'_sheet_{int(start)}.jpg'
    rows = (int(dur) + cols - 1) // cols
    subprocess.run([FF, '-v', 'error', '-y', '-ss', str(start), '-t', str(dur), '-i', src, '-vf', f'fps=1,scale=320:-1,tile={cols}x{rows}', '-frames:v', '1', out], check=True)
    print('sheet', out, f'(frame k = {start} + k seconds, left to right)'); return out


def scan(src, words):
    src = to_mp4(src)
    import numpy as np
    from faster_whisper import WhisperModel
    raw = subprocess.run([FF, '-v', 'error', '-i', src, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True).stdout
    a = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    segs, _ = WhisperModel('small', compute_type='int8').transcribe(a)
    hits = []
    for s in segs:
        line = f'{s.start:7.1f}  {s.text.strip()}'
        if any(w.lower() in s.text.lower() for w in words): print('>>', line); hits.append(s.start)
    for h in hits: sheet(src, max(0, h - 5), 30)
    if not hits: print('none of the words were said; look at sheets instead (python3 scripts/footage.py sheet ...)')


def cuts(src, start, dur):
    src = to_mp4(src)
    r = subprocess.run([FF, '-ss', str(start), '-t', str(dur), '-i', src, '-vf', "select='gt(scene,0.25)',showinfo", '-an', '-f', 'null', '-'], capture_output=True, text=True).stderr
    for ln in r.splitlines():
        if 'pts_time:' in ln: print(f"cut at {float(ln.split('pts_time:')[1].split()[0]) + float(start):.2f} s")


def clip(src, a, b, out):
    src = to_mp4(src); os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    subprocess.run([FF, '-v', 'error', '-y', '-ss', str(a), '-to', str(b), '-i', src, '-an', '-c:v', 'libx264', '-crf', '16', '-preset', 'veryfast', out], check=True)
    print('clip', out, f'{float(b) - float(a):.1f} s')


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(0)
    cmd = a[0]
    if cmd == 'search': search(' '.join(a[1:]))
    elif cmd == 'get': get(a[1], a[2] if len(a) > 2 else 'src')
    elif cmd == 'scan': scan(a[1], a[2:])
    elif cmd == 'sheet': sheet(a[1], float(a[2]), float(a[3]) if len(a) > 3 else 30)
    elif cmd == 'cuts': cuts(a[1], a[2], a[3] if len(a) > 3 else 20)
    elif cmd == 'clip': clip(a[1], a[2], a[3], a[4])
    else: print(__doc__)
