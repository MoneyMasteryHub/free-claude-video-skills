---
name: heist-dark-history-studio
description: Makes faceless documentary videos about real heists, crimes, cons, scandals and dark history in a Netflix-documentary style: finds topics people are searching for, researches and fact-checks them, writes the script in a proven viral format, voices it with the channel's house narrator (free), mixes real public-domain archive footage and photos with noir animated scenes, blueprints, maps, newspapers and an FBI-style case board, adds a dark cinematic score, and renders the MP4. Use for "heist video", "crime documentary", "dark history", "how they stole", "the man who…", "true crime explainer", or when someone asks for this skill by name.
---

# Heist & Dark History Studio

Turns a real story into a finished documentary (2 to 30 minutes) that looks like a streaming-service true-crime film:
- **Real archive footage and photos** (free to use, credited) in white evidence frames, and full screen.
- **Noir animated scenes**: muted puppet characters in heavy shadow. The criminals stay faceless (caps, masks, silhouettes); only named, public people get faces and a name tag.
- **Settings that change with the story**, joined by camera moves inside the picture, never a jump: the night street, a front page, a city map, a blueprint of the building, the blueprint filling into the real rooms, the FBI's case board, the interrogation room, the courtroom.
- **Documentary type**: Bebas Neue chapter cards, IBM Plex Mono place/time lines that type themselves on, Oswald numbers and name tags, Special Elite typewritten documents, Stardos Stencil stamps, Playfair Display quotes.
- **Sound**: the house narrator voice, a dark generated score (low strings, sub drone, pulse during the plan, a clock during the crime, a deep hit on each reveal) and quiet effects that always sit under the voice.

The reference film is `examples/brinks/` (the Brink's Robbery, Boston 1950, 90 seconds). Copy its `episode.py` for every new film.

Folder map:
- `engine/board.py` worlds, items, camera, world changes, the documentary type helpers (start here) · `engine/core.py` puppets and drawing kit · `engine/world.py` sets and props (street, office, courtroom, map, newspaper...) · `engine/film.py` cues, render, join · `engine/audio.py` score and effects (mood `noir`).
- `scripts/voice.py` house narrator · `scripts/timestamps.py` word timings · `scripts/footage.py` find, download, scan and cut archive footage · `scripts/photos.py` free photos with credits.
- `references/legal.md` (read before research) · `references/script.md` (read before writing) · `references/board.md` (read before the episode file) · `references/shots.md` (puppets, sets, props) · `references/research.md` (topic finding).

## Credits rule (always)
Before writing or rendering anything long, **ask how many minutes the video should be.** Always render a **60 to 90 second preview first** (the cold open plus one or two key beats, showing footage, photos, text and animation), and render the full film only after the user approves the preview.

## 0. Setup (do it yourself; the user never types commands)
Tell the user in one line: "Setting the studio up now. The first time takes a few minutes." Then run `bash setup.sh` (macOS/Linux) or `powershell -ExecutionPolicy Bypass -File setup.ps1` (Windows) from this folder. It installs the Python packages and ffmpeg and draws `selftest.png`; look at it.
- If Python is missing, give the user the one link the script prints, wait, run it again.
- If word timing fails to install (very new Python), install Python 3.12 from python.org for the user and rerun setup with it, or tell them that one link.
- Make the project folder yourself: `~/HeistStudio/<topic>/` with `src/`, `clips/`, `media/`. Copy `examples/brinks/episode.py` there.

## 1. Mode and topic
Ask once: **heist or dark story?** and whether they have a topic. If not, follow `references/research.md`: 10 ideas built on what people are searching and watching now, each with title, one-line hook, why now, demand proof (real numbers you saw), legal-risk flag. Never invent view counts.

## 2. Research and sources
Follow `references/legal.md` first. Build `sources.md`: every number, time, name and quote with its source. Mark anything unconfirmed. Get the timeline to the minute where sources allow. Note what is still unknown: it often becomes the ending.

## 3. Script
Follow `references/script.md` beat by beat, including the chapter markers (`[CHAPTER: PART ONE | THE PLAN]` on its own line at each act change: the narrator pauses 2 seconds while the chapter card is on screen). About 150 words a minute. Write numbers and times the way they are spoken. Run it through the humanizer skill. Show the script and wait for the user's OK.

## 4. Voice: the house narrator
This niche has one narrator, used for every film so the channel always sounds the same: **Kokoro `am_michael` at speed 0.95, full model** (deep, calm, serious; free and offline).
`python3 scripts/voice.py script.txt vo.wav` (those settings are the defaults; never change them unless the user asks). The first run installs the voice and downloads the model (~350 MB).
If the voice can't be installed on the user's computer, say so plainly and ask for an MP3 (save as `vo.mp3`; tell them to leave a 2-second pause at every chapter marker, `<break time="2s" />` in ElevenLabs). Then: `python3 scripts/timestamps.py vo.wav words.json`.

## 5. Real footage and photos (every film)
- Footage: `python3 scripts/footage.py search "<event>"` (Internet Archive, public-domain collections first). For the National Archives (catalog.archives.gov), search in the user's browser if it is linked, check the item's **Use** field ("Unrestricted" is fine, "Restricted" means no), and download through the browser into `src/`. Then `footage.py scan src/film.mp4 "<keyword>"` to find where the event is in the film, `footage.py cuts` to find clean cut points, `footage.py clip` to cut 2 to 8 second clips into `clips/`.
- Photos: `python3 scripts/photos.py search "..."`, `get "File:..." media/` (free licences only; credit saved).
- Label footage honestly: a government film or newsreel that illustrates the event is credited as that film, never called "footage of that night".

## 6. Episode file
Read `references/board.md`, then write `episode.py` from the Brink's example:
1. Plan the **worlds** for the acts of the script (usually: the desk for the opening and evidence, the blueprint for the plan and the crime, the case board for the investigation, back to the desk for the confession, verdict and ending). Dark history uses the same idea with other surfaces (an old ledger, a town map, letters).
2. Put the items on each world: footage and photos, noir scenes, papers (newspaper marked RECREATION, map, ledger, calendar, chart).
3. Cue everything on the voiceover's words (`T('phrase')`). Something new appears or changes with every sentence.
4. Write the camera: a key per beat, glides between items, dives into footage and scenes, and world changes through a matching item (`portal` for map pin to blueprint, the same clip or scene in both worlds otherwise).
5. Chapter cards appear by themselves in the voice's chapter pauses (`film.chapter_at('THE PLAN')` gives the time; land world changes and big camera moves inside that pause). Place/time lines on new scenes, name tags for named people, stamps only for verdicts.

## 7. Check, render, deliver
1. `python3 episode.py info`, then `python3 episode.py stills 1 5 12 ...` (frames tiled into `build/stills/sheet_*.jpg`). Look at every sheet: overlapping text, empty frames, wrong facts, faces on the criminals. Fix and check again.
2. Preview first (credits rule). `python3 episode.py all 2` renders everything (2 processes), mixes and writes `<episode>_final.mp4` at -14 LUFS. 90 seconds take about 15 minutes; tell the user before starting.
3. The mix prints the levels: the voice must lead; effects should sit 20 dB or more under it, music about 8 to 10 dB under. Pull 10 frames from the final MP4 and look at them before sending, including the moments where the world changes.

Deliver: the MP4, `sources.md`, and `upload.md` (3 titles, a description with footage and photo credits and a short sources line, tags, 3 thumbnail ideas: one big object or face-less figure, 2 to 4 words, one red stamp).

## Extending
New scene: a `draw(c, t)` function on the 1920x1080 frame using `engine/world.py` sets and `draw_char3` puppets (use `NOIR_GANG` for criminals). New paper: `draw(c, t, w, h)`. New world surface: a function `(c, view)` in `SURFACES`. New score mood: a branch in `engine/audio.py`.
