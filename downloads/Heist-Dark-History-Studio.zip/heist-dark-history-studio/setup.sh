#!/usr/bin/env bash
# One-step setup for macOS / Linux. Claude runs this; the user should not have to.
set -e
cd "$(dirname "$0")"
say() { printf '\n▸ %s\n' "$1"; }
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3.10+ is needed. Install it from https://www.python.org/downloads/, then run this again."; exit 1; fi
say "Python packages (drawing, sound, word timing). The first time takes a few minutes."
pipi() { python3 -m pip install --quiet --disable-pip-version-check "$@" 2>/dev/null || python3 -m pip install --quiet --disable-pip-version-check --user "$@" 2>/dev/null || python3 -m pip install --quiet --disable-pip-version-check --break-system-packages "$@" 2>/dev/null; }
for p in skia-python numpy scipy soundfile pillow certifi imageio-ffmpeg; do pipi "$p" || echo "  (could not install $p)"; done
# faster-whisper pulls in onnxruntime, which has no build yet for some new Pythons (e.g. 3.14 on Intel Macs).
# Word timing does not need onnxruntime, so fall back to installing faster-whisper without it.
if ! pipi "faster-whisper>=1.0"; then
  echo "  installing faster-whisper without onnxruntime"
  pipi ctranslate2 tokenizers huggingface_hub av tqdm && pipi --no-deps "faster-whisper>=1.0" || echo "  (word timing could not be installed; see SKILL.md, section 0)"
fi
echo "  (the free voice is installed later, only if you choose it)"
say "ffmpeg"
mkdir -p bin
if command -v ffmpeg >/dev/null 2>&1; then echo "using system ffmpeg"
else ln -sf "$(python3 -c 'import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())')" bin/ffmpeg; echo "ffmpeg installed into ./bin"; fi
say "Test frame"
python3 engine/selftest.py && echo "✓ Setup complete"
